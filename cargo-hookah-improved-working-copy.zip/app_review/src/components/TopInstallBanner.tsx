import React from 'react';

// Yellow installation banner completely removed per user request
export const TopInstallBanner: React.FC<{ forceShowForJoin?: boolean }> = () => {
  return null;
};

