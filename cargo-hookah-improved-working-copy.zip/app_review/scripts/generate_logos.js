import fs from 'fs';
import path from 'path';
import sharp from 'sharp';
import opentype from 'opentype.js';

async function generateAllLogos() {
  const fontBuffer = fs.readFileSync('scripts/Anton-Regular.ttf');
  const font = opentype.parse(
    fontBuffer.buffer.slice(fontBuffer.byteOffset, fontBuffer.byteOffset + fontBuffer.byteLength)
  );

  // 1. Generate exact vector path for CARGO
  const cargoPath = font.getPath('CARGO', 0, 110, 94);
  const cargoPathData = cargoPath.toPathData(2);

  // 2. Generate exact vector path for HOOKAH with nice tracking
  let hookahX = 0;
  const hookahChars = ['H', 'O', 'O', 'K', 'A', 'H'];
  let hookahPathData = '';
  for (const ch of hookahChars) {
    const p = font.getPath(ch, hookahX, 110, 52);
    hookahPathData += ' ' + p.toPathData(2);
    const adv = font.getAdvanceWidth(ch, 52);
    hookahX += adv + 7;
  }

  // 3. Assemble the master SVG with 100% pure vector paths (no external font dependencies)
  const masterSvg = `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <clipPath id="containerLeftFaceClip">
      <polygon points="68,236 216,160 308,268 68,368" />
    </clipPath>
  </defs>

  <!-- 1. Background: Solid Vibrant Brand Orange (#F45100) -->
  <rect width="512" height="512" fill="#F45100" />

  <!-- 2. Main 3D Container Base Shadow -->
  <polygon points="74,372 178,424 452,360 452,352 308,432" fill="#000000" />
  <polygon points="178,424 452,360 438,368 180,432" fill="#000000" />

  <!-- 3. TOP ROOF OF THE CONTAINER (Isometric Top Face) -->
  <polygon points="358,88 216,160 308,268 450,196" fill="#000000" />
  <!-- Inner roof bevel -->
  <polyline points="220,162 358,92 446,198" fill="none" stroke="#F45100" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />

  <!-- 4. RIGHT FACE OF THE CONTAINER (Doors with Grooves & Locks) -->
  <polygon points="308,268 450,196 450,358 308,430" fill="#000000" />
  <polyline points="308,268 450,196 450,358 308,430 308,268" fill="none" stroke="#F45100" stroke-width="4.5" stroke-linejoin="round" />

  <!-- Vertical container grooves / ridges -->
  <line x1="334" y1="281" x2="334" y2="417" stroke="#F45100" stroke-width="3.5" />
  <line x1="360" y1="268" x2="360" y2="404" stroke="#F45100" stroke-width="4" />
  <line x1="392" y1="252" x2="392" y2="388" stroke="#F45100" stroke-width="5" />
  <line x1="422" y1="237" x2="422" y2="373" stroke="#F45100" stroke-width="3.5" />
  <!-- Center door division line -->
  <line x1="392" y1="248" x2="392" y2="390" stroke="#000000" stroke-width="2.5" />

  <!-- Orange Lock Latches / Handles on the right face -->
  <rect x="382" y="278" width="18" height="11" rx="2" fill="#F45100" />
  <rect x="386" y="282" width="10" height="3" fill="#000000" />
  <rect x="412" y="304" width="18" height="11" rx="2" fill="#F45100" />
  <rect x="416" y="308" width="10" height="3" fill="#000000" />

  <!-- 5. LEFT MAIN FACE: Heavy Black Framing -->
  <polygon points="68,236 216,160 308,268 68,368" fill="#F45100" />
  <polyline points="68,236 216,160 308,268" fill="none" stroke="#000000" stroke-width="12" stroke-linecap="round" stroke-linejoin="round" />
  <line x1="68" y1="236" x2="68" y2="368" stroke="#000000" stroke-width="14" stroke-linecap="round" />

  <!-- 6. TYPOGRAPHY "CARGO" in black as pure vector paths -->
  <g transform="matrix(0.98, 0.44, 0, 1.05, 76, 126)">
    <path d="${cargoPathData}" fill="#000000" />
  </g>

  <!-- 7. BOTTOM BLACK BLOCK FOR "HOOKAH" -->
  <polygon points="76,368 308,268 448,358 180,422" fill="#000000" />
  
  <!-- "HOOKAH" in bold orange inside the black bottom container block as pure vector paths -->
  <g transform="matrix(0.98, 0.44, 0, 0.85, 96, 218)">
    <path d="${hookahPathData}" fill="#F45100" />
  </g>
</svg>
`;

  const publicDir = path.resolve('public');
  const assetsDir = path.resolve('src/assets');
  if (!fs.existsSync(publicDir)) fs.mkdirSync(publicDir, { recursive: true });
  if (!fs.existsSync(assetsDir)) fs.mkdirSync(assetsDir, { recursive: true });

  // 1. Save master SVG files
  fs.writeFileSync(path.join(publicDir, 'cargo-hookah-logo.svg'), masterSvg, 'utf-8');
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), masterSvg, 'utf-8');
  fs.writeFileSync(path.join(assetsDir, 'cargo-hookah-logo.svg'), masterSvg, 'utf-8');
  console.log('Saved master SVGs');

  // 2. Generate PNG sizes using Sharp with high quality
  const svgBuffer = Buffer.from(masterSvg);

  // 512x512 PWA & master PNG
  await sharp(svgBuffer)
    .resize(512, 512)
    .png({ quality: 100, compressionLevel: 9 })
    .toFile(path.join(publicDir, 'pwa-512x512.png'));
  
  await sharp(svgBuffer)
    .resize(512, 512)
    .png({ quality: 100, compressionLevel: 9 })
    .toFile(path.join(assetsDir, 'cargo-hookah-logo.png'));
  console.log('Generated 512x512 PNGs');

  // 192x192 PWA Icon
  await sharp(svgBuffer)
    .resize(192, 192)
    .png({ quality: 100, compressionLevel: 9 })
    .toFile(path.join(publicDir, 'pwa-192x192.png'));
  console.log('Generated 192x192 PNG');

  // 180x180 Apple Touch Icon (for iOS Home Screen)
  await sharp(svgBuffer)
    .resize(180, 180)
    .png({ quality: 100, compressionLevel: 9 })
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));
  console.log('Generated apple-touch-icon.png');

  // 64x64 Favicon PNG
  await sharp(svgBuffer)
    .resize(64, 64)
    .png({ quality: 100, compressionLevel: 9 })
    .toFile(path.join(publicDir, 'favicon.png'));
  console.log('Generated favicon.png');
}

generateAllLogos().catch(console.error);
