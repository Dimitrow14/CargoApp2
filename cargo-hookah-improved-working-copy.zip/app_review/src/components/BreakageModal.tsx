import React, { useState } from 'react';
import { AlertOctagon, X, Send } from 'lucide-react';

interface BreakageModalProps {
  isOpen: boolean;
  onClose: () => void;
  venueName: string;
  itemName: string;
  currentCount: number;
  newCount: number;
  onConfirm: (reason: string) => void;
}

export const BreakageModal: React.FC<BreakageModalProps> = ({
  isOpen,
  onClose,
  venueName,
  itemName,
  currentCount,
  newCount,
  onConfirm,
}) => {
  const [reason, setReason] = useState('');
  const diff = currentCount - newCount;

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) {
      alert('Моля въведете причина за бракуването/отписването!');
      return;
    }
    onConfirm(reason.trim());
    setReason('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-rose-500/40 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">Заявка за брак и липси</h3>
              <p className="text-xs text-slate-400">Изисква се одобрение от шеф/администратор</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2 text-xs">
          <div className="flex justify-between text-slate-400">
            <span>Обект:</span>
            <span className="font-bold text-white">{venueName}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Артикул:</span>
            <span className="font-bold text-amber-400">{itemName}</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Текуща наличност:</span>
            <span className="font-bold text-slate-200">{currentCount} бр.</span>
          </div>
          <div className="flex justify-between text-slate-400">
            <span>Заявено намаление:</span>
            <span className="font-black text-rose-400">-{diff} бр. (Нова наличност: {newCount} бр.)</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5">
              Причина за брака / липсата *
            </label>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Напр. Счупена при миене от сервитьор, пукната при работа, дефект..."
              rows={3}
              required
              className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl p-3 text-xs focus:outline-none focus:border-rose-500 placeholder:text-slate-500 font-medium"
            />
          </div>

          <div className="flex items-center justify-end gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl hover:bg-slate-700"
            >
              Отказ
            </button>
            <button
              type="submit"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-black rounded-xl shadow-lg shadow-rose-600/20 active:scale-95 transition-all"
            >
              <Send className="w-4 h-4" />
              <span>Изпрати за одобрение</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
