import React, { useMemo, useState } from 'react';
import { CheckCircle2, Circle, ClipboardList, Clock3, Plus, Trash2 } from 'lucide-react';
import type { StaffTask, TaskPriority, TaskStatus, UserAccount, Venue, Shift } from '../types';

interface Props {
  tasks: StaffTask[];
  users: UserAccount[];
  venues: Venue[];
  shifts: Shift[];
  currentUser: UserAccount;
  onCreate: (task: Omit<StaffTask, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onUpdate: (task: StaffTask) => void;
  onDelete: (taskId: string) => void;
}

const statusLabel: Record<TaskStatus, string> = { todo: 'За изпълнение', in_progress: 'В процес', done: 'Изпълнена', cancelled: 'Отменена' };
const priorityLabel: Record<TaskPriority, string> = { normal: 'Нормален', high: 'Висок', urgent: 'Спешен' };

export const TasksView: React.FC<Props> = ({ tasks, users, venues, shifts, currentUser, onCreate, onUpdate, onDelete }) => {
  const isManager = currentUser.role === 'boss' || currentUser.role === 'admin';
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [target, setTarget] = useState<'employee' | 'venue'>('employee');
  const [assigneeId, setAssigneeId] = useState(() => users.find(user => user.role === 'employee' || user.role === 'admin')?.id || currentUser.id);
  const [venueId, setVenueId] = useState(venues.find(v => v.isActive !== false)?.id || '');
  const [dueAt, setDueAt] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('normal');
  const [filter, setFilter] = useState<'open' | 'all' | 'done'>('open');

  const visibleTasks = useMemo(() => tasks.filter(task => {
    if (!isManager && task.target === 'employee' && task.assigneeId !== currentUser.id) return false;
    if (!isManager && task.target === 'venue' && task.venueId && !shifts.some(shift => shift.staffId === currentUser.id && shift.venueId === task.venueId)) return false;
    if (filter === 'open' && !['todo', 'in_progress'].includes(task.status)) return false;
    if (filter === 'done' && task.status !== 'done') return false;
    return true;
  }).sort((a, b) => {
    const rank: Record<TaskPriority, number> = { urgent: 0, high: 1, normal: 2 };
    return rank[a.priority] - rank[b.priority] || (a.dueAt || '9999').localeCompare(b.dueAt || '9999') || b.createdAt - a.createdAt;
  }), [tasks, isManager, currentUser.id, venues, shifts, filter]);

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!title.trim()) return;
    const assignee = users.find(user => user.id === assigneeId);
    onCreate({
      title: title.trim(), description: description.trim(), target,
      ...(target === 'employee' && assignee ? { assigneeId: assignee.id, assigneeName: assignee.name } : {}),
      ...(venueId ? { venueId } : {}), ...(dueAt ? { dueAt } : {}), priority, status: 'todo',
      createdById: currentUser.id, createdByName: currentUser.name,
    });
    setTitle(''); setDescription(''); setDueAt(''); setPriority('normal'); setShowForm(false);
  };

  return <section className="space-y-5 text-slate-100">
    <div className="rounded-2xl border border-slate-800 bg-slate-900 p-4 sm:p-6 flex items-center justify-between gap-3">
      <div><div className="flex items-center gap-2 text-amber-300"><ClipboardList className="w-5 h-5"/><h2 className="text-xl font-black">Задачи</h2></div><p className="mt-1 text-sm text-slate-400">Възлагане и проследяване на задачи по служител или обект.</p></div>
      {isManager && <button onClick={() => setShowForm(v => !v)} className="rounded-xl bg-amber-400 px-4 py-2 text-sm font-black text-slate-950 flex items-center gap-2"><Plus className="w-4 h-4"/>Нова задача</button>}
    </div>

    {showForm && isManager && <form onSubmit={submit} className="rounded-2xl border border-amber-500/30 bg-slate-900 p-4 sm:p-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
      <label className="text-sm font-semibold">Заглавие *<input required value={title} onChange={e=>setTitle(e.target.value)} maxLength={120} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3 text-white" placeholder="Напр. Провери наличностите"/></label>
      <label className="text-sm font-semibold">За кого е задачата?<select value={target} onChange={e=>setTarget(e.target.value as 'employee'|'venue')} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3 text-white"><option value="employee">Конкретен служител</option><option value="venue">Цял обект</option></select></label>
      {target === 'employee' && <label className="text-sm font-semibold">Служител<select value={assigneeId} onChange={e=>setAssigneeId(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3 text-white">{users.filter(u=>u.role==='employee'||u.role==='admin').map(u=><option key={u.id} value={u.id}>{u.name}</option>)}</select></label>}
      <label className="text-sm font-semibold">Обект<select value={venueId} onChange={e=>setVenueId(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3 text-white">{venues.filter(v=>v.isActive!==false).map(v=><option key={v.id} value={v.id}>{v.name}</option>)}</select></label>
      <label className="text-sm font-semibold">Краен срок<input type="datetime-local" value={dueAt} onChange={e=>setDueAt(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3 text-white"/></label>
      <label className="text-sm font-semibold">Приоритет<select value={priority} onChange={e=>setPriority(e.target.value as TaskPriority)} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3 text-white">{Object.entries(priorityLabel).map(([key,label])=><option key={key} value={key}>{label}</option>)}</select></label>
      <label className="sm:col-span-2 text-sm font-semibold">Описание<textarea value={description} onChange={e=>setDescription(e.target.value)} rows={3} maxLength={2000} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-3 text-white" placeholder="Какво трябва да бъде направено?"/></label>
      <div className="sm:col-span-2 flex justify-end gap-2"><button type="button" onClick={()=>setShowForm(false)} className="rounded-lg px-4 py-2 text-slate-300">Отказ</button><button type="submit" className="rounded-lg bg-amber-400 px-5 py-2 font-black text-slate-950">Възложи задача</button></div>
    </form>}

    <div className="flex flex-wrap gap-2">{([['open','Активни'],['all','Всички'],['done','Изпълнени']] as const).map(([key,label])=><button key={key} onClick={()=>setFilter(key)} className={`rounded-full px-4 py-2 text-sm font-bold ${filter===key?'bg-amber-400 text-slate-950':'bg-slate-900 text-slate-300 border border-slate-800'}`}>{label}</button>)}</div>

    {visibleTasks.length === 0 ? <div className="rounded-2xl border border-dashed border-slate-700 p-10 text-center text-slate-400">Няма задачи в тази категория.</div> : <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">{visibleTasks.map(task=>{
      const venue = venues.find(v=>v.id===task.venueId);
      const canManage = isManager || task.assigneeId === currentUser.id || (task.target==='venue' && task.venueId === undefined);
      return <article key={task.id} className="rounded-2xl border border-slate-800 bg-slate-900 p-4 sm:p-5">
        <div className="flex items-start gap-3"><button aria-label="Промени статус" disabled={!canManage || task.status==='cancelled'} onClick={()=>onUpdate({...task,status:task.status==='todo'?'in_progress':task.status==='in_progress'?'done':'done',updatedAt:Date.now(),...(task.status==='in_progress'?{completedAt:Date.now()}:{})})} className="mt-0.5 text-amber-300 disabled:opacity-40">{task.status==='done'?<CheckCircle2 className="w-6 h-6 text-emerald-400"/>:<Circle className="w-6 h-6"/>}</button>
          <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className={`font-black ${task.status==='done'?'line-through text-slate-400':'text-white'}`}>{task.title}</h3><span className={`rounded-full px-2 py-0.5 text-[10px] font-black ${task.priority==='urgent'?'bg-rose-500/20 text-rose-300':task.priority==='high'?'bg-amber-500/20 text-amber-300':'bg-slate-800 text-slate-300'}`}>{priorityLabel[task.priority]}</span></div>
          {task.description && <p className="mt-2 whitespace-pre-wrap text-sm text-slate-300">{task.description}</p>}
          <div className="mt-3 flex flex-wrap gap-x-3 gap-y-1 text-xs text-slate-400"><span>{task.target==='venue'?'За целия обект':`Отговорник: ${task.assigneeName || 'служител'}`}</span>{venue&&<span>Обект: {venue.name}</span>}<span>{statusLabel[task.status]}</span>{task.dueAt&&<span className="inline-flex items-center gap-1"><Clock3 className="w-3 h-3"/>{new Date(task.dueAt).toLocaleString('bg-BG')}</span>}</div>
          <p className="mt-2 text-[11px] text-slate-500">Възложил: {task.createdByName}</p></div>
          {isManager&&<button onClick={()=>onDelete(task.id)} title="Изтрий задача" className="rounded-lg p-2 text-slate-500 hover:bg-rose-500/10 hover:text-rose-300"><Trash2 className="w-4 h-4"/></button>}
        </div>
      </article>;
    })}</div>}
  </section>;
};
