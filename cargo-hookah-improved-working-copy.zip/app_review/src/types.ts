export type VenueId = string;

export type UserRole = 'boss' | 'admin' | 'employee'; // 'Шеф' / 'Админ' vs 'Служител'

export interface UserPermissions {
  canManageSchedule?: boolean;
  canManageInventory?: boolean;
  canManageReports?: boolean;
  canViewFinances?: boolean;
  canManageFines?: boolean;
}

export interface UserAccount {
  id: string;
  name: string;
  pin: string; // 4-digit or custom password
  role: UserRole;
  phone?: string;
  avatarColor: string;
  customBaseWageEur?: number; // персонализиран надник на смяна за този служител
  customHookahRateEur?: number; // персонализирано заплащане на наргиле за този служител
  permissions?: UserPermissions;
}

export interface Venue {
  id: string;
  name: string;
  tagline: string;
  shortCode: string;
  isActive?: boolean; // Deactivated venues do not appear in daily schedule selection
  inventoryConfig?: VenueInventoryConfig;
  themeColor: {
    bg: string;
    text: string;
    border: string;
    badgeBg: string;
    badgeText: string;
    accent: string;
    lightBg: string;
  };
}

// Venue Selling Price Configuration (Ценообразуване на наргилета по заведения)
export interface VenuePricing {
  venueId: string;
  yellowPriceEur: number; // Цена за Жълто наргиле (в евро)
  blackPriceEur: number;  // Цена за Черно наргиле (в евро)
  officialPriceEur: number; // Цена за Служебно наргиле (в евро, по подразбиране 0)
}

// Hookah Equipment Inventory (Оборудване: Наргилета, Вази, Маркучи, Чашки по видове, HMS)
export interface BowlTypeItem {
  id: string;
  name: string; // e.g. "CosmoBowl", "Bengala", "Oblako", "Вускуримзя", "funnel Cosmo"
  count: number;
}

export interface VenueEquipmentInventory {
  venueId: string;
  hookahsCount: number; // колко стандартни наргилета има
  electricHookahsCount?: number; // електрически наргилета, ако се използват в обекта
  vasesCount: number;   // колко вази има
  hosesCount: number;   // колко маркучи има
  hmsCount: number;
  bowls: BowlTypeItem[];
  lastUpdated: number;
  notes?: string;
  updatedBy?: string;
}

// Hookah Catering Inventory
export interface TobaccoItem {
  id: string;
  brand: string;
  flavor: string;
  lineType: 'yellow' | 'black'; // Жълто или Черно
  grams: number; // e.g. 250, 100, 50
  notes?: string;
  lastUpdated: number;
}

export interface VenueInventory {
  venueId: string;
  charcoalsKg: number; // Наличност на въглени в килограми (или кутии)
  mouthpiecePacksCount: number; // Наличност на мундщуци в брой пакети
  mouthpiecesCount?: number; // обратна съвместимост
  tobaccos: TobaccoItem[];
  lastUpdated: number;
}

// Shifts
export type ShiftType = 'standard' | 'day' | 'night' | 'custom';

export interface Shift {
  id: string;
  venueId: string;
  staffId: string;
  staffName: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  shiftType: ShiftType;
  notes?: string;
  createdById?: string;
  createdAt?: number;
  clockInTimestamp?: number;
  clockInTimeString?: string;
  isClockedIn?: boolean;
  isCompleted?: boolean;
  completedAt?: number;
}

export interface DetectedHookahItem {
  name: string;
  quantity: number;
  lineType: 'yellow' | 'black' | 'other';
  brand?: string; // e.g. "Наргиле Жълто", "Наргиле Черно", "Наргиле ОС", "Наргиле Дарксайд"
  price?: number;
  rawLine?: string;
}

// Hookah End-of-Shift Report (Отчет в края на смяната)
export interface AiVerificationResult {
  status: 'verified' | 'warning' | 'unclear';
  summary: string;
  detectedHookahs?: number;
  detectedYellow?: number;
  detectedBlack?: number;
  detectedRevenue?: number;
  detectedCurrency?: string;
  detectedVenue?: string;
  detectedDate?: string;
  detectedItems?: DetectedHookahItem[];
  matches: string[];
  discrepancies: string[];
  analyzedAt: number;
}

export interface ShiftReport {
  id: string;
  date: string; // YYYY-MM-DD
  venueId: string;
  staffId: string;
  staffName: string;
  
  // Hookah details: Общо, Жълто, Черно, Служебно
  totalHookahs: number; // напр. 4
  yellowHookahs: number; // Жълто - 2
  blackHookahs: number; // Черно - 2
  isOfficialComplimentary: boolean; // Служебно: ДА / НЕ
  officialHookahsCount?: number; // ако има служебни колко са
  
  // Photo attachment (base64 data URL) - Mandatory (задължително)
  photoUrl: string;
  
  // Tax stamp (бандероли/марки) photo attachment - Mandated before finalizing report
  taxStampPhotoUrl?: string;

  // Linked daily revision ID if completed
  revisionId?: string;
  
  // AI verification from report photo
  aiVerification?: AiVerificationResult;

  // Additional notes/comments
  notes?: string;
  
  // Calculated earnings for this shift:
  baseWageEur: number; // 23
  hookahBonusEur: number; // 1 * totalHookahs
  totalEarnedEur: number; // 23 + (1 * totalHookahs)
  
  createdAt: number;
}

export interface TobaccoRevisionDetail {
  tobaccoId: string;
  brand: string;
  flavor: string;
  lineType?: 'yellow' | 'black';
  startGrams: number;
  loadedGrams: number;
  endGrams: number;
  usedGrams: number;
}

// Smart Inventory & Revision (Ревизия и Отчет)
export interface DailyRevision {
  id: string;
  venueId: string;
  date: string; // YYYY-MM-DD
  staffId: string;
  staffName: string;
  startAmountGrams: number; // fetched automatically from previous day's end amount for that specific venue
  loadedAmountGrams: number; // added during the shift
  endAmountGrams: number; // inputted at the end of the shift
  usedTobaccoGrams: number; // (Start Amount + Loaded Amount) - End Amount = Used Tobacco
  totalHookahsMade: number; // Total Hookahs Made from shift/report
  averagePerBowlGrams: number; // Used Tobacco / Total Hookahs Made
  charcoalsStartKg?: number;
  charcoalsLoadedKg?: number;
  charcoalsEndKg?: number;
  charcoalsUsedKg?: number;
  items?: TobaccoRevisionDetail[];
  taxStampPhotoUrl?: string; // photo upload of tax stamps (бандероли/марки)
  notes?: string;
  createdAt: number;
}

// Inventory Approval Workflow (Брак и Липси)
export interface PendingApproval {
  id: string;
  venueId: string;
  staffId: string;
  staffName: string;
  category: 'equipment' | 'tobacco' | 'consumable';
  itemId: string; // e.g. "bowl-cosmo", "hookahsCount", "tob-xxx"
  itemName: string; // e.g. "Чашка CosmoBowl", "Ваза", "Darkside Supernova"
  quantityReduced: number; // e.g. 1
  currentCount: number;
  requestedCount: number;
  reason: string; // e.g. "Счупена при миене"
  status: 'pending' | 'approved' | 'rejected';
  createdAt: number;
  reviewedBy?: string;
  reviewedAt?: number;
  reviewNote?: string;
}

// Shift Notifications & Clock-in System
export interface ClockInRecord {
  id: string;
  shiftId: string;
  venueId: string;
  staffId: string;
  staffName: string;
  date: string; // YYYY-MM-DD
  clockInTimestamp: number;
  clockInTimeString: string;
  createdAt: number;
}

export interface WageSettings {
  baseWageEur: number; // базов надник на смяна (по подразбиране 23)
  hookahRateEur: number; // заплащане на наргиле (по подразбиране 1)
  currency: string; // '€' или 'лв.'
  updatedAt?: number;
  updatedBy?: string;
}

export type TaskStatus = 'todo' | 'in_progress' | 'done' | 'cancelled';
export type TaskPriority = 'normal' | 'high' | 'urgent';

export interface StaffTask {
  id: string;
  title: string;
  description: string;
  venueId?: string;
  assigneeId?: string;
  assigneeName?: string;
  target: 'employee' | 'venue';
  dueAt?: string;
  priority: TaskPriority;
  status: TaskStatus;
  createdById: string;
  createdByName: string;
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
}

export interface VenueInventoryConfig {
  tobacco: boolean;
  charcoals: boolean;
  mouthpieces: boolean;
  hookahs: boolean;
  electricHookahs: boolean;
  vases: boolean;
  hoses: boolean;
  bowls: boolean;
  hms: boolean;
}

export const DEFAULT_VENUE_INVENTORY_CONFIG: VenueInventoryConfig = {
  tobacco: true, charcoals: true, mouthpieces: true, hookahs: true,
  electricHookahs: false, vases: true, hoses: true, bowls: true, hms: true,
};

export type ViewTab = 'inventory' | 'equipment' | 'reports' | 'schedule' | 'tasks' | 'fines' | 'my_profile';

export interface ShiftConflict {
  date: string;
  staffId: string;
  staffName: string;
  shifts: Shift[];
  message: string;
}

export interface EmployeeFine {
  id: string;
  staffId: string;
  staffName: string;
  amountEur: number; // размер на глобата в евро
  date: string; // YYYY-MM-DD
  reason: string; // описание за какво бива глобен
  venueId?: string; // заведение (по избор)
  issuedBy: string; // кой я е наложил (напр. 'boss')
  createdAt: number;
}
