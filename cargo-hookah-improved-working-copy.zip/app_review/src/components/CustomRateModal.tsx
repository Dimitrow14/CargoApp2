import React, { useState, useEffect } from 'react';
import { UserAccount, WageSettings } from '../types';
import { Coins, X, Check, RotateCcw, User, Sparkles } from 'lucide-react';

interface CustomRateModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetUser: UserAccount | null;
  wageSettings?: WageSettings;
  onSaveCustomRate: (userId: string, customBaseWageEur?: number, customHookahRateEur?: number) => void;
  onNotify: (msg: string) => void;
}

export const CustomRateModal: React.FC<CustomRateModalProps> = ({
  isOpen,
  onClose,
  targetUser,
  wageSettings,
  onSaveCustomRate,
  onNotify,
}) => {
  const standardBase = wageSettings?.baseWageEur ?? 23;
  const standardHookah = wageSettings?.hookahRateEur ?? 1;
  const currency = wageSettings?.currency || '€';

  const [hasCustomRates, setHasCustomRates] = useState<boolean>(false);
  const [baseWage, setBaseWage] = useState<number>(standardBase);
  const [hookahRate, setHookahRate] = useState<number>(standardHookah);

  useEffect(() => {
    if (targetUser) {
      const isCustom = targetUser.customBaseWageEur !== undefined || targetUser.customHookahRateEur !== undefined;
      setHasCustomRates(isCustom);
      setBaseWage(targetUser.customBaseWageEur ?? standardBase);
      setHookahRate(targetUser.customHookahRateEur ?? standardHookah);
    }
  }, [targetUser, standardBase, standardHookah]);

  if (!isOpen || !targetUser) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (hasCustomRates) {
      const b = Number(baseWage) >= 0 ? Number(baseWage) : standardBase;
      const h = Number(hookahRate) >= 0 ? Number(hookahRate) : standardHookah;
      onSaveCustomRate(targetUser.id, b, h);
      onNotify(`Индивидуалната ставка за ${targetUser.name} е запазена: ${b}${currency} надник + ${h}${currency} на наргиле`);
    } else {
      // Reset to company default
      onSaveCustomRate(targetUser.id, undefined, undefined);
      onNotify(`Ставката за ${targetUser.name} беше върната към общата фирмена ставка (${standardBase}${currency} + ${standardHookah}${currency}).`);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 w-full max-w-md shadow-2xl relative">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-400">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-base">
                Индивидуална ставка
              </h3>
              <p className="text-xs text-slate-400">
                За служител: <span className="text-amber-400 font-bold">{targetUser.name}</span>
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          {/* Status info */}
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between gap-3">
            <div>
              <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">
                Обща фирмена ставка:
              </span>
              <span className="text-xs text-slate-200 font-semibold">
                {standardBase} {currency} надник + {standardHookah} {currency} на наргиле
              </span>
            </div>
            <div className={`px-2 py-0.5 rounded-lg text-[10px] font-bold border ${
              hasCustomRates
                ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                : 'bg-slate-800 text-slate-400 border-slate-700'
            }`}>
              {hasCustomRates ? 'Персонализирана' : 'По подразбиране'}
            </div>
          </div>

          {/* Toggle Custom vs Standard */}
          <div className="flex items-center gap-2 bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
            <input
              type="checkbox"
              id="enable-custom-rates"
              checked={hasCustomRates}
              onChange={(e) => {
                const checked = e.target.checked;
                setHasCustomRates(checked);
                if (checked && baseWage === standardBase && hookahRate === standardHookah) {
                  // Keep initial
                }
              }}
              className="w-4 h-4 accent-amber-500 rounded cursor-pointer"
            />
            <label htmlFor="enable-custom-rates" className="text-xs font-bold text-white cursor-pointer select-none">
              Задай специална (персонализирана) ставка за {targetUser.name}
            </label>
          </div>

          {hasCustomRates && (
            <div className="space-y-3.5 bg-slate-950/80 p-4 rounded-2xl border border-amber-500/30 animate-fadeIn">
              {/* Custom Base Wage */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Надник за 1 смяна за {targetUser.name} ({currency})
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    required={hasCustomRates}
                    value={baseWage}
                    onChange={(e) => setBaseWage(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-sm font-bold focus:outline-none focus:border-amber-500"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                    {currency} / смяна
                  </span>
                </div>
                <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                  {[20, 23, 25, 30, 35, 40].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setBaseWage(val)}
                      className={`text-[10px] px-2 py-0.5 rounded-md border font-semibold transition-all ${
                        baseWage === val
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {val} {currency}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Hookah Rate */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Пари за направено наргиле за {targetUser.name} ({currency})
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    required={hasCustomRates}
                    value={hookahRate}
                    onChange={(e) => setHookahRate(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-sm font-bold focus:outline-none focus:border-amber-500"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-amber-400">
                    {currency} / наргиле
                  </span>
                </div>
                <div className="flex items-center gap-1 mt-1.5 flex-wrap">
                  {[0.5, 1, 1.2, 1.5, 2, 2.5].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setHookahRate(val)}
                      className={`text-[10px] px-2 py-0.5 rounded-md border font-semibold transition-all ${
                        hookahRate === val
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {val.toFixed(val % 1 === 0 ? 0 : 1)} {currency}
                    </button>
                  ))}
                </div>
              </div>

              {/* Example calculation */}
              <div className="p-2.5 bg-slate-900 rounded-xl border border-slate-800 text-[11px] text-slate-300">
                За 1 смяна с 10 наргилета {targetUser.name} ще получи:{' '}
                <span className="text-amber-400 font-bold">
                  {(baseWage + 10 * hookahRate).toFixed(2)} {currency}
                </span>{' '}
                <span className="text-slate-500">
                  (стандартно: {(standardBase + 10 * standardHookah).toFixed(2)} {currency})
                </span>
              </div>
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold rounded-xl"
            >
              Отказ
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
            >
              Запази ставката
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
