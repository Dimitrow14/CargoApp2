import React, { useState } from 'react';
import { UserAccount, UserRole, WageSettings } from '../types';
import { 
  Users, 
  UserPlus, 
  Trash2, 
  Phone, 
  QrCode,
  RefreshCw,
  Edit2,
  Coins,
  Check,
  X
} from 'lucide-react';

interface TeamManageModalProps {
  isOpen: boolean;
  onClose: () => void;
  users: UserAccount[];
  currentUser: UserAccount;
  wageSettings?: WageSettings;
  onAddUser: (user: Omit<UserAccount, 'id' | 'avatarColor'>) => void;
  onUpdateUser?: (user: UserAccount) => void;
  onDeleteUser: (userId: string) => void;
  onNotify: (msg: string) => void;
  onOpenInviteQr?: () => void;
  onRefreshTeam?: () => void;
}

export const TeamManageModal: React.FC<TeamManageModalProps> = ({
  isOpen,
  onClose,
  users,
  currentUser,
  wageSettings,
  onAddUser,
  onUpdateUser,
  onDeleteUser,
  onNotify,
  onOpenInviteQr,
  onRefreshTeam,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [pin, setPin] = useState('');
  const [role, setRole] = useState<UserRole>('employee');
  const [phone, setPhone] = useState('');
  const [customBaseWage, setCustomBaseWage] = useState<string>('');
  const [customHookahRate, setCustomHookahRate] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Edit employee state
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editRole, setEditRole] = useState<UserRole>('employee');
  const [editPhone, setEditPhone] = useState('');
  const [editBaseWage, setEditBaseWage] = useState<string>('');
  const [editHookahRate, setEditHookahRate] = useState<string>('');

  if (!isOpen) return null;

  const isBoss = currentUser.role === 'boss';
  const defaultBaseWage = wageSettings?.baseWageEur ?? 23;
  const defaultHookahRate = wageSettings?.hookahRateEur ?? 1;
  const currencySymbol = wageSettings?.currency || '€';

  const handleManualRefresh = async () => {
    if (onRefreshTeam) {
      setIsRefreshing(true);
      try {
        await onRefreshTeam();
        onNotify('Списъкът с екипа е синхронизиран със сървъра.');
      } finally {
        setTimeout(() => setIsRefreshing(false), 500);
      }
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !pin.trim()) {
      alert('Моля попълнете име и начален PIN код!');
      return;
    }

    const customBase = customBaseWage.trim() !== '' ? Math.max(0, Number(customBaseWage)) : undefined;
    const customHookah = customHookahRate.trim() !== '' ? Math.max(0, Number(customHookahRate)) : undefined;

    onAddUser({
      name: name.trim(),
      pin: pin.trim(),
      role,
      phone: phone.trim() || undefined,
      customBaseWageEur: customBase,
      customHookahRateEur: customHookah,
    });

    setName('');
    setPin('');
    setPhone('');
    setCustomBaseWage('');
    setCustomHookahRate('');
    setShowAddForm(false);
    onNotify(`Служителят ${name} е добавен с ${customBase !== undefined ? customBase + '€ надник' : 'стандартна ставка'}!`);
  };

  const handleStartEdit = (user: UserAccount) => {
    setEditingUserId(user.id);
    setEditName(user.name);
    setEditRole(user.role);
    setEditPhone(user.phone || '');
    setEditBaseWage(user.customBaseWageEur !== undefined ? String(user.customBaseWageEur) : '');
    setEditHookahRate(user.customHookahRateEur !== undefined ? String(user.customHookahRateEur) : '');
  };

  const handleSaveEdit = (user: UserAccount) => {
    if (!onUpdateUser) return;
    if (!editName.trim()) {
      onNotify('Моля попълнете име!');
      return;
    }

    const customBase = editBaseWage.trim() !== '' ? Math.max(0, Number(editBaseWage)) : undefined;
    const customHookah = editHookahRate.trim() !== '' ? Math.max(0, Number(editHookahRate)) : undefined;

    const updated: UserAccount = {
      ...user,
      name: editName.trim(),
      role: editRole,
      phone: editPhone.trim() || undefined,
      customBaseWageEur: customBase,
      customHookahRateEur: customHookah,
    };

    onUpdateUser(updated);
    setEditingUserId(null);
    onNotify(`Ставките и надникът на ${updated.name} са запаметени веднага.`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-5 sm:p-6 shadow-2xl space-y-5 my-6 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-white">Екип</h3>
                {onRefreshTeam && (
                  <button
                    type="button"
                    onClick={handleManualRefresh}
                    className="p-1 text-slate-400 hover:text-amber-400 rounded-lg hover:bg-slate-800 transition-colors"
                    title="Синхронизирай със сървъра"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : ''}`} />
                  </button>
                )}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
          >
            ✕
          </button>
        </div>

        {/* Scrollable Container */}
        <div className="space-y-4 overflow-y-auto flex-1 pr-1">
          {/* Add user toggle - Boss only */}
          {isBoss && (
            <div>
              {!showAddForm ? (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowAddForm(true)}
                    className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-400 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors"
                  >
                    <UserPlus className="w-4 h-4" />
                    <span>+ Добавяне на нов служител</span>
                  </button>

                  {onOpenInviteQr && (
                    <button
                      onClick={() => {
                        onClose();
                        onOpenInviteQr();
                      }}
                      className="py-2.5 px-4 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-colors shrink-0"
                      title="Покани служител с QR код или директен линк"
                    >
                      <QrCode className="w-4 h-4 text-amber-400" />
                      <span>Покани с QR</span>
                    </button>
                  )}
                </div>
              ) : (
                <form onSubmit={handleAddSubmit} className="bg-slate-950 border border-amber-500/40 rounded-2xl p-4 space-y-3 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <UserPlus className="w-4 h-4 text-amber-400" />
                      <span>Нов член на екипа & Персонализирана ставка</span>
                    </h4>
                    <button
                      type="button"
                      onClick={() => setShowAddForm(false)}
                      className="text-xs text-slate-500 hover:text-white"
                    >
                      Отказ
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-400 mb-1">Име и Фамилия *</label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="напр. Георги Иванов"
                        className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-400 mb-1">Начален PIN / Парола *</label>
                      <input
                        type="password"
                        value={pin}
                        onChange={(e) => setPin(e.target.value)}
                        placeholder="••••"
                        className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs font-mono focus:outline-none focus:border-amber-500"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-400 mb-1">Роля в системата</label>
                      <select
                        value={role}
                        onChange={(e) => setRole(e.target.value as UserRole)}
                        className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
                      >
                        <option value="employee">Служител (Наргиле майстор)</option>
                        <option value="boss">Шеф (Пълен контрол)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-slate-400 mb-1">Телефон</label>
                      <input
                        type="text"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="0888 123 456"
                        className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    {/* Custom Wage Fields */}
                    <div>
                      <label className="block text-[11px] font-semibold text-amber-400 mb-1">
                        Персонализиран надник на смяна ({currencySymbol})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="0.5"
                        value={customBaseWage}
                        onChange={(e) => setCustomBaseWage(e.target.value)}
                        placeholder={`По подразбиране (${defaultBaseWage} ${currencySymbol})`}
                        className="w-full bg-slate-900 border border-slate-700 text-amber-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
                      />
                      <span className="text-[10px] text-slate-500">Оставете празно за общата ставка</span>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-amber-400 mb-1">
                        Персонализирано на наргиле ({currencySymbol})
                      </label>
                      <input
                        type="number"
                        min="0"
                        step="0.1"
                        value={customHookahRate}
                        onChange={(e) => setCustomHookahRate(e.target.value)}
                        placeholder={`По подразбиране (${defaultHookahRate} ${currencySymbol})`}
                        className="w-full bg-slate-900 border border-slate-700 text-amber-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
                      />
                      <span className="text-[10px] text-slate-500">Оставете празно за общата ставка</span>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                    <button
                      type="submit"
                      className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-all"
                    >
                      Запази служителя
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* Users List with Personalized Rates Display and In-place Edit */}
          <div className="space-y-2.5">
            {users.map((u) => {
              const isSelf = u.id === currentUser.id;
              const isEditing = editingUserId === u.id;
              const hasCustomBase = typeof u.customBaseWageEur === 'number' && u.customBaseWageEur >= 0;
              const hasCustomHookah = typeof u.customHookahRateEur === 'number' && u.customHookahRateEur >= 0;
              const userBaseRate = hasCustomBase ? u.customBaseWageEur! : defaultBaseWage;
              const userHookahRate = hasCustomHookah ? u.customHookahRateEur! : defaultHookahRate;

              if (isEditing) {
                return (
                  <div
                    key={u.id}
                    className="bg-slate-950 border border-amber-500/50 rounded-2xl p-4 space-y-3 animate-in fade-in duration-150"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        <Edit2 className="w-4 h-4 text-amber-400" />
                        <span className="text-xs font-bold text-white">Редакция на {u.name}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setEditingUserId(null)}
                        className="text-xs text-slate-400 hover:text-white"
                      >
                        ✕
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-400 mb-1">Име</label>
                        <input
                          type="text"
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-slate-400 mb-1">Роля</label>
                        <select
                          value={editRole}
                          onChange={(e) => setEditRole(e.target.value as UserRole)}
                          className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500"
                        >
                          <option value="employee">Служител</option>
                          <option value="boss">Шеф</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-amber-400 mb-1">
                          Индивидуален надник на смяна ({currencySymbol})
                        </label>
                        <input
                          type="number"
                          min="0"
                          step="0.5"
                          value={editBaseWage}
                          onChange={(e) => setEditBaseWage(e.target.value)}
                          placeholder={`Общ: ${defaultBaseWage} ${currencySymbol}`}
                          className="w-full bg-slate-900 border border-slate-700 text-amber-300 font-bold rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-semibold text-amber-400 mb-1">
                          Индивидуално за наргиле ({currencySymbol})
                        </label>
                        <input
                          type="number"
                          min="0"
                          step="0.1"
                          value={editHookahRate}
                          onChange={(e) => setEditHookahRate(e.target.value)}
                          placeholder={`Общ: ${defaultHookahRate} ${currencySymbol}`}
                          className="w-full bg-slate-900 border border-slate-700 text-amber-300 font-bold rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                      <button
                        type="button"
                        onClick={() => {
                          setEditBaseWage('');
                          setEditHookahRate('');
                        }}
                        className="text-slate-400 hover:text-amber-400 text-[11px]"
                      >
                        Върни стандартни ставки
                      </button>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingUserId(null)}
                          className="px-3 py-1.5 bg-slate-800 text-slate-300 rounded-xl"
                        >
                          Отказ
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveEdit(u)}
                          className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl flex items-center gap-1.5 shadow-sm active:scale-95 transition-all"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Запази веднага</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              }

              return (
                <div
                  key={u.id}
                  className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${u.avatarColor} flex items-center justify-center font-bold text-sm shrink-0 shadow-sm`}>
                      {u.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-white">{u.name}</span>
                        {isSelf && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">
                            (Вие)
                          </span>
                        )}
                        <span className={u.role === 'boss' ? 'text-amber-400 font-bold text-xs' : 'text-slate-400 text-xs'}>
                          {u.role === 'boss' ? '👑 Шеф' : '💨 Служител'}
                        </span>
                      </div>

                      {/* Wage Rate Badges - Confidential: Only visible to Boss or the employee themselves */}
                      <div className="flex items-center gap-2 mt-1 flex-wrap text-xs">
                        {(isBoss || isSelf) && (
                          <div className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] font-bold ${
                            hasCustomBase || hasCustomHookah
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-slate-900 text-slate-400 border border-slate-800'
                          }`}>
                            <Coins className="w-3 h-3 text-amber-400" />
                            <span>
                              {isSelf && !isBoss ? 'Моята ставка: ' : 'Ставка: '}
                              {userBaseRate} {currencySymbol} надник + {userHookahRate} {currencySymbol}/наргиле
                            </span>
                            {(hasCustomBase || hasCustomHookah) && (
                              <span className="text-[9px] bg-amber-400 text-slate-950 font-black px-1 rounded ml-0.5">
                                Персонална
                              </span>
                            )}
                          </div>
                        )}

                        {u.phone && (
                          <span className="text-[11px] text-slate-400">📞 {u.phone}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-end gap-1.5 shrink-0 pt-2 sm:pt-0 border-t sm:border-0 border-slate-800">
                    {isBoss && onUpdateUser && (
                      <button
                        onClick={() => handleStartEdit(u)}
                        className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-amber-200 border border-slate-800 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                        title="Редактирай ставки или профил"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>Ставки & Профил</span>
                      </button>
                    )}

                    {isBoss && !isSelf && (
                      <button
                        onClick={() => {
                          if (confirm(`Премахване на ${u.name} от системата?`)) {
                            onDeleteUser(u.id);
                          }
                        }}
                        className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors"
                        title="Премахни служител"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <span>Общо членове на екипа: {users.length}</span>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl"
          >
            Затвори
          </button>
        </div>
      </div>
    </div>
  );
};
