import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { CargoLogo } from './CargoLogo';
import { 
  Download, 
  Smartphone, 
  Apple, 
  Check, 
  Copy, 
  Share2, 
  Send, 
  QrCode, 
  ExternalLink,
  MessageCircle,
  Sparkles,
  Info,
  CheckCircle2,
  Edit3
} from 'lucide-react';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  bossName?: string;
}

// Fallback public Cloud Run preview URL if on localhost or sandbox iframe
const DEFAULT_PUBLIC_URL = 'https://ais-pre-vukf67gwqvucp32f6kyz2k-667294038303.europe-west1.run.app';

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ 
  isOpen, 
  onClose,
  bossName 
}) => {
  const [activeTab, setActiveTab] = useState<'qr_join' | 'ios' | 'android'>('qr_join');
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [joinUrl, setJoinUrl] = useState<string>('');
  const [isEditingUrl, setIsEditingUrl] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    if (typeof window !== 'undefined') {
      let baseUrl = window.location.origin;

      // If running on localhost or inside local container, mobile phone can't reach localhost
      // Default to public Cloud Run instance URL
      if (
        baseUrl.includes('localhost') || 
        baseUrl.includes('127.0.0.1') || 
        baseUrl.includes('about:blank') ||
        !baseUrl.startsWith('http')
      ) {
        baseUrl = DEFAULT_PUBLIC_URL;
      }

      const cleanJoinUrl = `${baseUrl.replace(/\/$/, '')}/?join=true`;
      setJoinUrl(cleanJoinUrl);
      generateQr(cleanJoinUrl);
    }
  }, [isOpen]);

  const generateQr = (urlToEncode: string) => {
    QRCode.toDataURL(urlToEncode, {
      width: 440,
      margin: 3,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    })
      .then((dataUri) => setQrDataUrl(dataUri))
      .catch((err) => console.error('Error generating QR code:', err));
  };

  const handleUrlChange = (newUrl: string) => {
    setJoinUrl(newUrl);
    generateQr(newUrl);
  };

  if (!isOpen) return null;

  const handleCopyLink = () => {
    if (!joinUrl) return;
    navigator.clipboard.writeText(joinUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    });
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Cargo Hookah - Присъединяване към екипа',
          text: 'Линк за присъединяване към екипа и график за Cargo Hookah:',
          url: joinUrl,
        });
      } catch {
        // Ignored
      }
    } else {
      handleCopyLink();
    }
  };

  const handleDownloadQr = () => {
    if (!qrDataUrl) return;
    const link = document.createElement('a');
    link.download = 'cargo-hookah-invite-qr.png';
    link.href = qrDataUrl;
    link.click();
  };

  const shareText = encodeURIComponent(
    `Здравей! Ето директен линк за присъединяване към екипа на Cargo Hookah (график, смени, наличности на тютюни и инвентар): ${joinUrl}`
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto font-sans">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-5 sm:p-6 shadow-2xl space-y-4 my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <CargoLogo size="sm" />
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-white">
                Свали за телефон & Покани служители
              </h3>
              <p className="text-xs text-slate-400">
                Директен QR код за сканиране с камера & инсталиране на началния екран
              </p>
            </div>
          </div>
          <button 
            onClick={onClose} 
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors text-sm"
          >
            ✕
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="grid grid-cols-3 gap-1.5 bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold">
          <button
            onClick={() => setActiveTab('qr_join')}
            className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'qr_join'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white font-medium'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>QR & Линк за екипа</span>
          </button>
          <button
            onClick={() => setActiveTab('ios')}
            className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'ios'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white font-medium'
            }`}
          >
            <Apple className="w-4 h-4" />
            <span>iPhone (iOS)</span>
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className={`py-2 rounded-xl flex items-center justify-center gap-1.5 transition-all ${
              activeTab === 'android'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white font-medium'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Android</span>
          </button>
        </div>

        {/* TAB 1: QR CODE & DIRECT LINK TO JOIN */}
        {activeTab === 'qr_join' && (
          <div className="space-y-4">
            {/* QR Card Container */}
            <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center gap-5 text-center sm:text-left">
              {/* QR Image */}
              <div className="shrink-0 bg-white p-3 rounded-2xl shadow-xl shadow-amber-500/10 flex flex-col items-center">
                {qrDataUrl ? (
                  <img 
                    src={qrDataUrl} 
                    alt="QR код за директно отваряне на сайта" 
                    className="w-44 h-44 sm:w-48 sm:h-48 object-contain"
                  />
                ) : (
                  <div className="w-44 h-44 flex items-center justify-center text-slate-400 text-xs">
                    Генериране на QR код...
                  </div>
                )}
                <span className="text-[10px] text-slate-900 font-extrabold mt-1.5 uppercase tracking-wider bg-amber-400 px-2 py-0.5 rounded-full">
                  📷 Сканирай с камера
                </span>
              </div>

              {/* Instructions */}
              <div className="space-y-2.5 flex-1">
                <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Директно препращане към сайта</span>
                </div>

                <h4 className="text-sm font-bold text-white leading-snug">
                  Как работи за служителите:
                </h4>

                <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside text-left">
                  <li>Служителят насочва камерата на телефона към QR кода.</li>
                  <li><strong>Сайтът се отваря веднага в Safari или Chrome!</strong></li>
                  <li>Отгоре излиза банер за <strong>инсталиране на екрана</strong> с 1 клик.</li>
                  <li>Въвежда си име и PIN и вече има пълен достъп без сложни стъпки!</li>
                </ol>

                <div className="pt-1 flex items-center gap-2 flex-wrap">
                  <button
                    onClick={handleDownloadQr}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Свали QR като снимка (PNG)</span>
                  </button>

                  <a
                    href={joinUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-amber-400 hover:text-amber-300 hover:underline"
                  >
                    <ExternalLink className="w-3 h-3" />
                    <span>Тествай линка</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Direct Link Box to send to staff */}
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-2.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-300">
                  Линк към сайта за изпращане по WhatsApp / Viber / SMS:
                </label>
                <button
                  type="button"
                  onClick={() => setIsEditingUrl(!isEditingUrl)}
                  className="text-[11px] text-amber-400 hover:underline flex items-center gap-1"
                >
                  <Edit3 className="w-3 h-3" />
                  <span>{isEditingUrl ? 'Запази' : 'Промени адреса'}</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly={!isEditingUrl}
                  value={joinUrl}
                  onChange={(e) => handleUrlChange(e.target.value)}
                  onClick={(e) => (e.target as HTMLInputElement).select()}
                  className={`w-full bg-slate-900 border text-amber-300 text-xs font-mono rounded-xl px-3 py-2.5 select-all focus:outline-none ${
                    isEditingUrl ? 'border-amber-500 ring-1 ring-amber-500' : 'border-slate-700'
                  }`}
                />
                <button
                  onClick={handleCopyLink}
                  id="copy-join-link-btn"
                  className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-1.5 shrink-0 transition-all ${
                    copied
                      ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                      : 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md shadow-amber-500/20'
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Копирано!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Копирай</span>
                    </>
                  )}
                </button>
              </div>

              {/* Instant Messenger Share Buttons */}
              <div className="flex items-center gap-2 pt-1 flex-wrap">
                <span className="text-[11px] text-slate-400 font-semibold mr-1">
                  Изпрати в:
                </span>

                <a
                  href={`https://api.whatsapp.com/send?text=${shareText}`}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-600/40 text-xs font-semibold transition-colors"
                >
                  <MessageCircle className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>

                <a
                  href={`viber://forward?text=${shareText}`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-600/40 text-xs font-semibold transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Viber</span>
                </a>

                {typeof navigator !== 'undefined' && 'share' in navigator && (
                  <button
                    onClick={handleNativeShare}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                  >
                    <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Още опции...</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: iOS INSTALLATION INSTRUCTIONS */}
        {activeTab === 'ios' && (
          <div className="space-y-3 bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-xs text-slate-300">
            <div className="flex items-center gap-2 mb-1 text-white font-bold text-sm">
              <Apple className="w-4 h-4 text-amber-400" />
              <span>Инсталиране на iPhone (Safari):</span>
            </div>
            <div className="space-y-2.5">
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0">1</span>
                <p>Отворете линка или сканирайте QR кода през камерата в <strong>Safari</strong> на вашия iPhone.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0">2</span>
                <p>Натиснете бутона <strong>Сподели (Share) ⎋</strong> в долната лента на Safari.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0">3</span>
                <p>Превъртете надолу и изберете <strong>"Към началния екран" (Add to Home Screen)</strong>.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0">4</span>
                <p>Натиснете <strong>"Добави" (Add)</strong> горе вдясно. Готово — приложението се отваря като native app на цял екран!</p>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: ANDROID INSTALLATION INSTRUCTIONS */}
        {activeTab === 'android' && (
          <div className="space-y-3 bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-xs text-slate-300">
            <div className="flex items-center gap-2 mb-1 text-white font-bold text-sm">
              <Smartphone className="w-4 h-4 text-emerald-400" />
              <span>Инсталиране на Android (Chrome):</span>
            </div>
            <div className="space-y-2.5">
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0">1</span>
                <p>Отворете линка или сканирайте QR кода с камерата на Android телефон.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0">2</span>
                <p>В горната част на екрана ще видите бутона <strong>"Инсталирай (1 клик)"</strong> — натиснете го!</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0">3</span>
                <p>Ако не го виждате, отворете менюто с три точки (<strong>⋮</strong>) и изберете <strong>"Инсталиране на приложението"</strong>.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-slate-800 text-amber-400 font-bold flex items-center justify-center shrink-0">4</span>
                <p>Приложението се инсталира веднага с иконата на Cargo Hookah на началния екран.</p>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
          <span className="text-[11px] text-slate-500">
            Бар хей • Зеро Зеро • Бар Де Руж
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition-colors"
          >
            Затвори
          </button>
        </div>
      </div>
    </div>
  );
};
