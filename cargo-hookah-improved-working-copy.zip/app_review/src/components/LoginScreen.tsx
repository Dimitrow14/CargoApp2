import React, { useState, useEffect } from 'react';
import { UserAccount } from '../types';
import { CargoLogo } from './CargoLogo';
import { apiFetchLogo } from '../utils/storage';
import { 
  KeyRound, 
  ShieldCheck, 
  ShieldAlert,
  LogIn, 
  Sparkles, 
  Smartphone,
  CheckCircle2,
  Check,
  Lock
} from 'lucide-react';

interface LoginScreenProps {
  users: UserAccount[];
  onLogin: (user: UserAccount) => void;
  onOpenInstallModal: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ 
  users, 
  onLogin,
  onOpenInstallModal 
}) => {
  // Login form state
  const [selectedUserId, setSelectedUserId] = useState<string>(users[0]?.id || '');
  const [pinInput, setPinInput] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Cybersecurity: Brute-force protection & rate limiting
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [lockoutRemaining, setLockoutRemaining] = useState<number>(0);

  // Remember password state
  const [rememberPassword, setRememberPassword] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('hookah_remember_pwd_pref');
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  const [isPinRemembered, setIsPinRemembered] = useState<boolean>(false);

  // Logo state (for display only on login screen - only boss can edit after login)
  const [customLogo, setCustomLogo] = useState<string | null>(() => {
    try {
      return localStorage.getItem('hookah_custom_logo');
    } catch {
      return null;
    }
  });

  useEffect(() => {
    apiFetchLogo().then((serverLogo) => {
      if (serverLogo) {
        setCustomLogo(serverLogo);
      }
    });
  }, []);

  // Countdown timer for lockout
  useEffect(() => {
    if (lockoutRemaining <= 0) return;
    const timer = setInterval(() => {
      setLockoutRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setFailedAttempts(0);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [lockoutRemaining]);

  useEffect(() => {
    if (users.length > 0 && !selectedUserId) {
      setSelectedUserId(users[0].id);
    }
  }, [users, selectedUserId]);

  // Load remembered PIN whenever selected user changes
  useEffect(() => {
    if (selectedUserId) {
      try {
        const savedPin = localStorage.getItem(`hookah_saved_pin_${selectedUserId}`);
        if (savedPin) {
          setPinInput(savedPin);
          setIsPinRemembered(true);
        } else {
          setPinInput('');
          setIsPinRemembered(false);
        }
      } catch {
        setPinInput('');
        setIsPinRemembered(false);
      }
    }
  }, [selectedUserId]);

  const selectedUser = users.find((u) => u.id === selectedUserId) || users[0];

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (lockoutRemaining > 0) {
      setErrorMsg(`Системата е временно заключена за още ${lockoutRemaining} сек.`);
      return;
    }

    if (!selectedUser) {
      setErrorMsg('Моля, изберете потребител.');
      return;
    }

    if (pinInput.trim() === selectedUser.pin) {
      setErrorMsg(null);
      setFailedAttempts(0);

      // Save or remove remembered password
      try {
        localStorage.setItem('hookah_remember_pwd_pref', String(rememberPassword));
        if (rememberPassword) {
          localStorage.setItem(`hookah_saved_pin_${selectedUser.id}`, pinInput.trim());
        } else {
          localStorage.removeItem(`hookah_saved_pin_${selectedUser.id}`);
        }
      } catch (err) {
        console.error('Error saving remembered PIN:', err);
      }

      onLogin(selectedUser);
    } else {
      const nextFailures = failedAttempts + 1;
      setFailedAttempts(nextFailures);

      if (nextFailures >= 5) {
        setLockoutRemaining(60);
        setErrorMsg('⚠️ Твърде много грешни опита! Защитата от brute-force заключи входа за 60 секунди.');
      } else {
        setErrorMsg(`Грешен PIN код/парола! Опит ${nextFailures} от 5 преди временно заключване.`);
      }
    }
  };

  const handleClearRememberedPin = () => {
    if (selectedUser) {
      try {
        localStorage.removeItem(`hookah_saved_pin_${selectedUser.id}`);
        setPinInput('');
        setIsPinRemembered(false);
      } catch (err) {
        console.error(err);
      }
    }
  };

  const handleQuickSelect = (user: UserAccount) => {
    setSelectedUserId(user.id);
    setErrorMsg(null);
  };

  const isLocked = lockoutRemaining > 0;

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4 sm:p-6 relative overflow-x-hidden font-sans">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md mx-auto my-auto flex flex-col items-center justify-center relative z-10">
        <div className="w-full bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative z-10">
          
          {/* App Branding */}
          <div className="w-full flex flex-col items-center justify-center text-center mb-6">
            <div className="flex items-center justify-center mx-auto mb-4">
              <CargoLogo size="xl" customLogo={customLogo} className="mx-auto" />
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-wider text-white text-center">
              <span className="bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500 bg-clip-text text-transparent">
                CARGO HOOKAH
              </span>
            </h1>
            <p className="text-xs text-slate-400 mt-1 font-medium tracking-wide uppercase text-center">
              Бар хей • Зеро Зеро • Бар Де Руж
            </p>
            <div className="inline-flex items-center justify-center gap-1.5 mt-2.5 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full text-[11px] font-semibold text-amber-300 mx-auto">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Cargo Hookah • График и отчети</span>
            </div>
          </div>

          {/* User Selector */}
          <div className="mb-5">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Избери профил за вход:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
              {users.map((u) => {
                const isSelected = u.id === selectedUser?.id;
                const isBoss = u.role === 'boss';

                return (
                  <button
                    key={u.id}
                    type="button"
                    onClick={() => handleQuickSelect(u)}
                    className={`p-2.5 rounded-xl border text-left transition-all flex items-center gap-2.5 ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-500 text-white shadow-sm shadow-amber-500/20 ring-1 ring-amber-500'
                        : 'bg-slate-800/60 border-slate-700/70 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg ${u.avatarColor} flex items-center justify-center font-bold text-xs shrink-0`}>
                      {u.name.charAt(0)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold truncate leading-tight">{u.name}</p>
                      <span className={`text-[10px] font-semibold px-1.5 py-0.2 rounded-md ${
                        isBoss 
                          ? 'bg-amber-400/20 text-amber-300' 
                          : 'bg-slate-700 text-slate-300'
                      }`}>
                        {isBoss ? '👑 Шеф' : 'Служител'}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              <span>Регистрирани профили: {users.length}</span>
            </div>
          </div>

          {/* Lockout Banner */}
          {isLocked && (
            <div className="mb-4 p-3 bg-rose-500/15 border border-rose-500/40 rounded-2xl text-xs text-rose-300 flex items-center gap-2.5 animate-pulse">
              <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0" />
              <div>
                <p className="font-bold">Временно заключване (Cybersecurity)</p>
                <p className="text-[11px] text-rose-400/90">
                  5 грешни опита. Моля изчакайте: <strong>{lockoutRemaining} сек.</strong>
                </p>
              </div>
            </div>
          )}

          {/* PIN Login Form */}
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                  <span>Парола / PIN за {selectedUser?.name}:</span>
                </label>
              </div>

              <div className="relative">
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={12}
                  value={pinInput}
                  disabled={isLocked}
                  onChange={(e) => {
                    setPinInput(e.target.value);
                    setIsPinRemembered(false);
                  }}
                  placeholder="Въведи PIN код"
                  className={`w-full bg-slate-950 border text-white rounded-xl px-4 py-3 text-sm font-mono tracking-widest focus:outline-none transition-colors ${
                    isLocked 
                      ? 'border-rose-500/50 bg-rose-950/10 cursor-not-allowed opacity-60' 
                      : 'border-slate-700 focus:border-amber-500'
                  }`}
                  autoFocus
                />
                {isPinRemembered && (
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    Запомнен
                  </span>
                )}
              </div>
            </div>

            {/* Remember password checkbox option */}
            <div className="flex items-center justify-between pt-0.5">
              <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={rememberPassword}
                  onChange={(e) => setRememberPassword(e.target.checked)}
                  className="w-4 h-4 rounded bg-slate-950 border-slate-700 text-amber-500 focus:ring-amber-500 focus:ring-offset-slate-900"
                />
                <span>Запомни паролата на това устройство</span>
              </label>

              {isPinRemembered && (
                <button
                  type="button"
                  onClick={handleClearRememberedPin}
                  className="text-[11px] text-rose-400 hover:text-rose-300 hover:underline"
                >
                  Забрави PIN
                </button>
              )}
            </div>

            {errorMsg && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-rose-400 text-xs text-center font-medium">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              id="login-submit-btn"
              disabled={isLocked}
              className={`w-full py-3.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-[0.99] shadow-lg ${
                isLocked 
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed shadow-none' 
                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 shadow-amber-500/20'
              }`}
            >
              {isLocked ? (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Заключено ({lockoutRemaining} сек)</span>
                </>
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  <span>Влез в профила</span>
                </>
              )}
            </button>
          </form>

          {/* Security & Access Notice */}
          <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Защитена система</span>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
