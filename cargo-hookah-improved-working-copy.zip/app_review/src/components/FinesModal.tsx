import React, { useState, useMemo } from 'react';
import { UserAccount, EmployeeFine, VenueId } from '../types';
import { VENUES } from '../data/initialData';
import { formatDate } from '../utils/dateUtils';
import { 
  AlertOctagon, 
  X, 
  Plus, 
  Trash2, 
  Calendar, 
  User, 
  Coins, 
  FileText, 
  Building2, 
  CheckCircle2,
  AlertTriangle,
  Receipt
} from 'lucide-react';

interface FinesModalProps {
  isOpen: boolean;
  onClose: () => void;
  fines: EmployeeFine[];
  users: UserAccount[];
  currentUser: UserAccount;
  onAddFine: (fineData: Omit<EmployeeFine, 'id' | 'createdAt'>) => void;
  onDeleteFine: (fineId: string) => void;
  onNotify: (msg: string) => void;
}

const PRESET_REASONS = [
  'Закъснение за смяна',
  'Счупена ваза / чашка',
  'Липса в касата / сметката',
  'Непочистени наргилета в края на смяната',
  'Неизвинено отсъствие',
  'Забравен невключен / непочистен котлон',
  'Нарушение на правилника в заведението',
];

export const FinesModal: React.FC<FinesModalProps> = ({
  isOpen,
  onClose,
  fines,
  users,
  currentUser,
  onAddFine,
  onDeleteFine,
  onNotify,
}) => {
  const isBoss = currentUser.role === 'boss';

  // State for new fine form
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedStaffId, setSelectedStaffId] = useState<string>(
    users.find((u) => u.role !== 'boss')?.id || users[0]?.id || ''
  );
  const [fineAmount, setFineAmount] = useState<number>(10);
  const [fineDate, setFineDate] = useState<string>(() => formatDate(new Date()));
  const [fineVenueId, setFineVenueId] = useState<VenueId | ''>('bar-hey');
  const [fineReason, setFineReason] = useState<string>('');

  // Filter state for viewing
  const [filterStaffId, setFilterStaffId] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<string>(''); // e.g. '2026-09'

  // Filtered fines
  const filteredFines = useMemo(() => {
    return fines.filter((f) => {
      // Non-boss only sees their own fines
      if (!isBoss && f.staffId !== currentUser.id) return false;

      if (filterStaffId !== 'all' && f.staffId !== filterStaffId) return false;
      if (filterMonth && !f.date.startsWith(filterMonth)) return false;
      return true;
    });
  }, [fines, isBoss, currentUser.id, filterStaffId, filterMonth]);

  const totalFilteredAmount = useMemo(() => {
    return filteredFines.reduce((sum, f) => sum + (Number(f.amountEur) || 0), 0);
  }, [filteredFines]);

  if (!isOpen) return null;

  const handleSubmitNewFine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStaffId) {
      onNotify('Моля изберете служител!');
      return;
    }
    if (!fineReason.trim()) {
      onNotify('Моля въведете подробно описание / причина за глобата!');
      return;
    }
    if (fineAmount <= 0) {
      onNotify('Размерът на глобата трябва да бъде по-голям от 0!');
      return;
    }

    const staffObj = users.find((u) => u.id === selectedStaffId);
    const staffName = staffObj?.name || 'Служител';

    onAddFine({
      staffId: selectedStaffId,
      staffName,
      amountEur: Number(fineAmount),
      date: fineDate,
      venueId: fineVenueId ? (fineVenueId as VenueId) : undefined,
      reason: fineReason.trim(),
      issuedBy: currentUser.name,
    });

    setFineReason('');
    setFineAmount(10);
    setShowAddForm(false);
    onNotify(`Наложена е глоба от ${fineAmount} € на ${staffName}. Сумата директно ще се удържи от заплатата му.`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-2xl max-h-[92vh] flex flex-col shadow-2xl relative overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-900/90 sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-white text-base sm:text-lg">
                  {isBoss ? 'Глоби & Удръжки' : 'Моите глоби & удръжки'}
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  {filteredFines.length} {filteredFines.length === 1 ? 'глоба' : 'глоби'}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {/* Top Summary & Actions Banner */}
          <div className="bg-slate-950/90 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Общо удръжки по глоби:
              </span>
              <div className="text-xl sm:text-2xl font-black text-rose-400 flex items-baseline gap-1 mt-0.5">
                <span>-{totalFilteredAmount.toFixed(2)} €</span>
              </div>
            </div>

            {isBoss && (
              <button
                type="button"
                onClick={() => setShowAddForm(!showAddForm)}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs transition-all shadow-md active:scale-95 shrink-0 ${
                  showAddForm
                    ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    : 'bg-gradient-to-r from-rose-500 to-rose-600 hover:from-rose-400 text-white'
                }`}
              >
                {showAddForm ? (
                  <>
                    <X className="w-4 h-4" />
                    <span>Затвори формата</span>
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    <span>+ Наложи нова глоба</span>
                  </>
                )}
              </button>
            )}
          </div>

          {/* Form to add fine (Boss only) */}
          {isBoss && showAddForm && (
            <form onSubmit={handleSubmitNewFine} className="bg-slate-950 border border-rose-500/30 rounded-2xl p-4 sm:p-5 space-y-4 animate-fadeIn">
              <div className="flex items-center gap-2 text-rose-400 font-bold text-xs pb-2 border-b border-slate-800">
                <AlertTriangle className="w-4 h-4" />
                <span>Форма за налагане на глоба</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Employee Selection */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Служител *
                  </label>
                  <select
                    value={selectedStaffId}
                    onChange={(e) => setSelectedStaffId(e.target.value)}
                    required
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-rose-500"
                  >
                    {users.map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.name} ({u.role === 'boss' ? 'Шеф' : 'Служител'})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Amount in EUR */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Размер на глобата (€) *
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      min="1"
                      step="1"
                      required
                      value={fineAmount}
                      onChange={(e) => setFineAmount(Math.max(1, parseFloat(e.target.value) || 0))}
                      className="w-full bg-slate-900 border border-slate-700 text-rose-400 font-black rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-rose-500"
                    />
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                      EUR (€)
                    </span>
                  </div>
                  {/* Preset amounts */}
                  <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                    {[5, 10, 15, 20, 30, 50].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setFineAmount(amt)}
                        className={`text-[10px] px-2 py-0.5 rounded-lg border font-semibold transition-all ${
                          fineAmount === amt
                            ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {amt} €
                      </button>
                    ))}
                  </div>
                </div>

                {/* Date */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Дата на инцидента *
                  </label>
                  <input
                    type="date"
                    required
                    value={fineDate}
                    onChange={(e) => setFineDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-rose-500"
                  />
                </div>

                {/* Venue */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Заведение (по избор)
                  </label>
                  <select
                    value={fineVenueId}
                    onChange={(e) => setFineVenueId(e.target.value as VenueId | '')}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs font-semibold focus:outline-none focus:border-rose-500"
                  >
                    <option value="">(Няма / Общо за фирмата)</option>
                    {VENUES.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Reason / Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Подробно описание / За какво бива глобен *
                </label>
                <textarea
                  rows={2}
                  required
                  value={fineReason}
                  onChange={(e) => setFineReason(e.target.value)}
                  placeholder="Опишете точно защо се налага глобата, за да я види служителят..."
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-3 text-xs focus:outline-none focus:border-rose-500 placeholder:text-slate-600"
                />

                {/* Quick preset reason chips */}
                <div className="flex items-center gap-1.5 flex-wrap mt-2">
                  <span className="text-[10px] text-slate-500 font-bold">Чести причини:</span>
                  {PRESET_REASONS.map((reason) => (
                    <button
                      key={reason}
                      type="button"
                      onClick={() => setFineReason(reason)}
                      className="text-[10px] px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition-all text-left"
                    >
                      + {reason}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold rounded-xl"
                >
                  Отказ
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-rose-500 to-rose-600 hover:from-rose-400 text-white font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  Потвърди и удръж от заплатата
                </button>
              </div>
            </form>
          )}

          {/* Filter Bar */}
          <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
            <div className="flex items-center gap-2 flex-wrap">
              {isBoss && (
                <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-800">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <select
                    value={filterStaffId}
                    onChange={(e) => setFilterStaffId(e.target.value)}
                    className="bg-transparent text-white font-semibold focus:outline-none"
                  >
                    <option value="all" className="bg-slate-900 text-white">Всички служители</option>
                    {users.map((u) => (
                      <option key={u.id} value={u.id} className="bg-slate-900 text-white">
                        {u.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex items-center gap-1.5 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-800">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <input
                  type="month"
                  value={filterMonth}
                  onChange={(e) => setFilterMonth(e.target.value)}
                  placeholder="Всички месеци"
                  className="bg-transparent text-white font-semibold focus:outline-none"
                />
                {filterMonth && (
                  <button
                    type="button"
                    onClick={() => setFilterMonth('')}
                    className="text-[10px] text-slate-400 hover:text-white"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            <span className="text-[11px] text-slate-400 font-medium">
              Показване на {filteredFines.length} записа
            </span>
          </div>

          {/* Fines List */}
          <div className="space-y-2.5">
            {filteredFines.length === 0 ? (
              <div className="bg-slate-950/60 border border-slate-800/80 rounded-2xl p-8 text-center">
                <CheckCircle2 className="w-10 h-10 text-emerald-400/80 mx-auto mb-2" />
                <p className="text-sm font-bold text-white">Няма регистрирани глоби</p>
                <p className="text-xs text-slate-400 mt-1">
                  {isBoss
                    ? 'За избрания филтър няма наложени глоби или удръжки.'
                    : 'Нямате наложени глоби за този период. Браво!'}
                </p>
              </div>
            ) : (
              filteredFines.map((fine) => {
                const venueObj = VENUES.find((v) => v.id === fine.venueId);

                return (
                  <div
                    key={fine.id}
                    className="bg-slate-950 border border-slate-800/90 hover:border-rose-500/30 rounded-2xl p-4 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs"
                  >
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-white">
                          {fine.staffName}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          • {fine.date}
                        </span>
                        {venueObj && (
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${venueObj.themeColor.badgeBg}`}>
                            {venueObj.name}
                          </span>
                        )}
                        <span className="text-[10px] text-slate-500">
                          (Наложена от: {fine.issuedBy || 'boss'})
                        </span>
                      </div>

                      {/* Reason Description */}
                      <p className="text-xs text-rose-200 font-medium bg-rose-500/10 border border-rose-500/20 rounded-xl px-3 py-2">
                        "{fine.reason}"
                      </p>
                    </div>

                    <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-0 border-slate-800/60">
                      <div className="text-right">
                        <div className="text-base font-black text-rose-400">
                          -{fine.amountEur.toFixed(2)} €
                        </div>
                      </div>

                      {isBoss && (
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Сигурни ли сте, че искате да отмените глобата от ${fine.amountEur} € за ${fine.staffName}?`)) {
                              onDeleteFine(fine.id);
                            }
                          }}
                          className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors"
                          title="Изтрий / Отмени глобата"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-900/90 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition-colors"
          >
            Затвори
          </button>
        </div>
      </div>
    </div>
  );
};
