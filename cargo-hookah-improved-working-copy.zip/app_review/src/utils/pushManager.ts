import { UserAccount } from '../types';
import { db } from '../firebase';
import { doc, setDoc, deleteDoc } from 'firebase/firestore';

export interface PushSupportStatus {
  isSupported: boolean;
  isIOS: boolean;
  isStandalone: boolean;
  permission: NotificationPermission | 'unsupported';
  isSubscribed: boolean;
  canReceivePush: boolean;
}

// Convert VAPID base64 URL safe string to Uint8Array
function urlBase64ToUint8Array(base64String: string): Uint8Array {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding)
    .replace(/-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}

export function isPushNotificationSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    'serviceWorker' in navigator &&
    'PushManager' in window &&
    'Notification' in window
  );
}

export function isIOS(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
  );
}

export function isStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(display-mode: standalone)').matches ||
    (window.navigator as any).standalone === true ||
    document.referrer.includes('android-app://')
  );
}

export async function checkPushSupportStatus(): Promise<PushSupportStatus> {
  const isSupported = isPushNotificationSupported();
  const ios = isIOS();
  const standalone = isStandalone();

  if (!isSupported) {
    return {
      isSupported: false,
      isIOS: ios,
      isStandalone: standalone,
      permission: 'unsupported',
      isSubscribed: false,
      canReceivePush: false,
    };
  }

  const permission = Notification.permission;
  let isSubscribed = false;

  try {
    const reg = await navigator.serviceWorker.ready;
    const sub = await reg.pushManager.getSubscription();
    isSubscribed = sub !== null;
  } catch (e) {
    console.warn('Could not check push subscription:', e);
  }

  // iOS Safari requires Add-to-Home-Screen (standalone) for Web Push
  const canReceivePush = ios ? (standalone && isSupported) : isSupported;

  return {
    isSupported,
    isIOS: ios,
    isStandalone: standalone,
    permission,
    isSubscribed,
    canReceivePush,
  };
}

export async function subscribeToPushNotifications(currentUser: UserAccount): Promise<{
  success: boolean;
  error?: string;
}> {
  if (!isPushNotificationSupported()) {
    return {
      success: false,
      error: 'Браузърът или устройството не поддържа Push известия.',
    };
  }

  try {
    // 1. Request permission
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') {
      return {
        success: false,
        error: 'Разрешението за известия беше отказано от устройството.',
      };
    }

    // 2. Fetch VAPID public key from backend
    const keyRes = await fetch('/api/push/vapid-public-key');
    if (!keyRes.ok) {
      throw new Error('Неуспешно извличане на VAPID ключ от сървъра');
    }
    const { publicKey } = await keyRes.json();
    if (!publicKey) {
      throw new Error('Липсва VAPID публичен ключ');
    }

    // 3. Ensure Service Worker is ready
    let reg: ServiceWorkerRegistration;
    try {
      reg = await navigator.serviceWorker.ready;
    } catch {
      reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
      await new Promise((r) => setTimeout(r, 400));
    }

    // 4. Subscribe to PushManager
    let subscription = await reg.pushManager.getSubscription();
    if (!subscription) {
      const convertedKey = urlBase64ToUint8Array(publicKey);
      subscription = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: convertedKey as unknown as BufferSource,
      });
    }

    const subJson = subscription.toJSON();
    const endpoint = subscription.endpoint;
    const subId = btoa(endpoint).slice(-32).replace(/[^a-zA-Z0-9]/g, '_');

    // 5. Send subscription to server
    const serverPayload = {
      subscription: subJson,
      userId: currentUser.id,
      userName: currentUser.name,
      userRole: currentUser.role,
      deviceInfo: navigator.userAgent,
    };

    const serverRes = await fetch('/api/push/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(serverPayload),
    });

    if (!serverRes.ok) {
      console.warn('Server push subscribe returned non-200');
    }

    // 6. Also persist in Firestore collection `push_subscriptions`
    try {
      await setDoc(doc(db, 'push_subscriptions', subId), {
        id: subId,
        endpoint,
        keys: subJson.keys || {},
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        deviceInfo: navigator.userAgent,
        updatedAt: Date.now(),
        createdAt: Date.now(),
      });
    } catch (fsErr) {
      console.warn('Firestore push subscription write warning:', fsErr);
    }

    return { success: true };
  } catch (err: any) {
    console.error('Error in subscribeToPushNotifications:', err);
    return {
      success: false,
      error: err.message || 'Грешка при активиране на телефонните известия',
    };
  }
}

export async function unsubscribeFromPushNotifications(currentUser: UserAccount): Promise<boolean> {
  try {
    if (!isPushNotificationSupported()) return false;
    const reg = await navigator.serviceWorker.ready;
    const subscription = await reg.pushManager.getSubscription();
    if (subscription) {
      const endpoint = subscription.endpoint;
      const subId = btoa(endpoint).slice(-32).replace(/[^a-zA-Z0-9]/g, '_');

      await subscription.unsubscribe();

      // Remove from server
      await fetch('/api/push/unsubscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint, userId: currentUser.id }),
      });

      // Remove from Firestore
      try {
        await deleteDoc(doc(db, 'push_subscriptions', subId));
      } catch (e) {
        console.warn('Firestore subscription delete warning:', e);
      }
    }
    return true;
  } catch (err) {
    console.error('Error unsubscribing:', err);
    return false;
  }
}

export async function triggerTestPushNotification(currentUser: UserAccount): Promise<{
  success: boolean;
  message: string;
}> {
  try {
    // Attempt server-sent Web Push
    const res = await fetch('/api/push/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId: currentUser.id,
        userName: currentUser.name,
      }),
    });

    const data = await res.json().catch(() => ({}));

    // In parallel, also show a Service Worker notification locally for instant tactile feedback
    if ('serviceWorker' in navigator && Notification.permission === 'granted') {
      try {
        const reg = await navigator.serviceWorker.ready;
        reg.showNotification('🔥 Cargo Hookah: Тестово известие', {
          body: `Здравей, ${currentUser.name}! Телефонните push известия са активни и работят дори когато приложението е затворено.`,
          icon: '/pwa-192x192.png',
          badge: '/favicon.png',
          tag: 'cargo-test-push',
          vibrate: [200, 100, 200],
          data: { url: '/?tab=schedule' },
        } as any);
      } catch (localErr) {
        console.warn('Local SW notification trigger warning:', localErr);
      }
    }

    if (res.ok && data.success) {
      return {
        success: true,
        message: 'Тестовото известие беше изпратено директно към телефона ви!',
      };
    } else {
      return {
        success: true,
        message: data.message || 'Известието е активирано успешно на вашето устройство!',
      };
    }
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Грешка при изпращане на тестово известие',
    };
  }
}
