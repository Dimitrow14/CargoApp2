# Cargo Hookah – implementation notes

## Changes in this working copy

- Added a Tasks section for managers and staff, including assignment to a staff member or venue, optional deadline, priority, status, description, and persistent task records.
- Added a push-notification attempt when a manager creates a task. Notifications depend on the employee having an active push subscription; venue-wide notifications target staff with shifts at that venue in the server's schedule data.
- Added per-venue inventory configuration for charcoal, mouthpieces, standard hookahs, electric hookahs, vases, hoses, bowls, and HMS. Managers can edit these options in the Equipment & Inventory view.
- Hidden inventory categories from the single-venue interface when disabled for that venue.
- Added a separate electric-hookah quantity, included in the all-venue comparison and approval workflow.
- Added optional charcoal revision fields (opening quantity, loaded quantity, closing quantity, used quantity) when charcoal tracking is enabled for a venue.
- Prevented the report workflow from deducting charcoal a second time if that day's revision already records a closing charcoal quantity.
- Added task persistence to local state, server state, and Firestore state listeners.
- Added server-side merging of tasks by ID/timestamp and manager task deletion synchronization.

## Validation performed

- TypeScript/TSX syntax transpilation passed for all changed source files.
- A full application build/type-check could not be completed in this environment because dependencies were not installed; the package installation attempt timed out. Install dependencies and run `npm run lint` and `npm run build` before deployment.

## Deployment blockers to address before production use

- The existing `firestore.rules` currently allows unrestricted reads and writes. This is a serious security issue. Do not treat the current deployment as production-secure until the app's login is connected to real Firebase Authentication/role claims and Firestore rules are restricted accordingly.
- Several existing API routes trust client-supplied role information. They need proper server-side authentication and authorization before public production use.
- Push notifications require correctly configured VAPID keys and users to enable notifications on their devices.
- AI report analysis and Slack delivery need to be tested with the live API/webhook configuration.
