import React, { useState, useEffect, useMemo, useRef } from 'react';
import { 
  VenueId, 
  Venue,
  VenueInventory, 
  TobaccoItem, 
  UserAccount,
  DailyRevision,
  TobaccoRevisionDetail,
  Shift,
  DEFAULT_VENUE_INVENTORY_CONFIG
} from '../types';
import { formatDate } from '../utils/dateUtils';
import { fetchLatestCompletedRevisionForVenue, saveInventoryToFirestore } from '../firebase';
import { 
  ChevronDown, 
  ChevronUp, 
  Search, 
  Plus, 
  Check, 
  Flame, 
  Boxes, 
  Sparkles, 
  Trash2, 
  Lock, 
  ArrowRight, 
  TrendingDown, 
  AlertOctagon,
  Loader2,
  HelpCircle
} from 'lucide-react';

interface InventoryViewProps {
  inventories: Record<string, VenueInventory>;
  venues: Venue[];
  revisions: DailyRevision[];
  currentUser: UserAccount;
  shifts?: Shift[];
  onUpdateInventory: (venueId: VenueId, updated: VenueInventory) => void;
  onSaveRevision?: (revision: Omit<DailyRevision, 'id' | 'createdAt'>) => Promise<void> | void;
  onNavigateToReports?: () => void;
  onNotify: (msg: string) => void;
}

// Calculate availability percentage based on 250g standard box (or net tare)
export const calculateTobaccoPercentage = (grams: number): number => {
  if (grams <= 0) return 0;
  if (grams <= 50) return 0;
  const percent = ((grams - 50) / 200) * 100;
  return Math.round(Math.max(0, Math.min(100, percent)));
};

export const InventoryView: React.FC<InventoryViewProps> = ({
  inventories,
  venues,
  revisions,
  currentUser,
  shifts = [],
  onUpdateInventory,
  onSaveRevision,
  onNavigateToReports,
  onNotify,
}) => {
  const activeVenues = venues.filter((v) => v.isActive !== false);
  const [selectedVenue, setSelectedVenue] = useState<VenueId>(() => activeVenues[0]?.id || 'bar-hey');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Auto-fetched previous shift data: mapping of tobaccoId -> endAmount from previous shift
  const [startAmounts, setStartAmounts] = useState<Record<string, number>>({});
  const [isLoadingPrevShift, setIsLoadingPrevShift] = useState(false);
  const [hasPreviousShift, setHasPreviousShift] = useState<boolean | null>(null);
  const [prevShiftInfo, setPrevShiftInfo] = useState<{ date?: string; staffName?: string } | null>(null);

  // Loaded amounts entered by user for this shift: [tobaccoId]: string
  const [loadedInputs, setLoadedInputs] = useState<Record<string, string>>({});
  // End amounts entered by user for this shift: [tobaccoId]: string
  const [endInputs, setEndInputs] = useState<Record<string, string>>({});
  const [isSavingRevision, setIsSavingRevision] = useState(false);
  const [justSavedRevision, setJustSavedRevision] = useState(false);

  // Controlled, isolated consumables state (decoupled from parent shift UI toggle re-renders)
  const venueConfig = { ...DEFAULT_VENUE_INVENTORY_CONFIG, ...(venues.find(v => v.id === selectedVenue)?.inventoryConfig || {}) };

  const currentInv: VenueInventory = inventories[selectedVenue] || {
    venueId: selectedVenue,
    charcoalsKg: 0,
    mouthpiecePacksCount: 0,
    tobaccos: [],
    lastUpdated: Date.now(),
  };

  const [charcoalsInput, setCharcoalsInput] = useState<string>(() => (currentInv.charcoalsKg ?? 0).toString());
  const [mouthpiecesInput, setMouthpiecesInput] = useState<string>(() => (currentInv.mouthpiecePacksCount ?? 0).toString());
  const [charcoalLoadedInput, setCharcoalLoadedInput] = useState('0');
  const [charcoalEndInput, setCharcoalEndInput] = useState(() => (currentInv.charcoalsKg ?? 0).toString());
  const lastLoadedVenueRef = useRef<string>(selectedVenue);

  // Re-sync consumables ONLY when the selectedVenue actually changes, preventing parent re-renders from clobbering input
  useEffect(() => {
    if (lastLoadedVenueRef.current !== selectedVenue) {
      lastLoadedVenueRef.current = selectedVenue;
      const targetInv = inventories[selectedVenue];
      setCharcoalsInput((targetInv?.charcoalsKg ?? 0).toString());
      setMouthpiecesInput((targetInv?.mouthpiecePacksCount ?? 0).toString());
      setCharcoalLoadedInput('0');
      setCharcoalEndInput((targetInv?.charcoalsKg ?? 0).toString());
      setLoadedInputs({});
      setEndInputs({});
      setJustSavedRevision(false);
    }
  }, [selectedVenue, inventories]);

  // Add new tobacco modal state
  const [showAddModal, setShowAddModal] = useState(false);
  const [newBrand, setNewBrand] = useState('');
  const [newFlavor, setNewFlavor] = useState('');
  const [newLineType, setNewLineType] = useState<'yellow' | 'black'>('black');
  const [newGrams, setNewGrams] = useState('250');

  const todayStr = formatDate(new Date());

  // Shift Verification: Admin/Boss can view/edit any venue; Employee MUST have an active shift today at this venue
  const isBossOrAdmin = currentUser.role === 'boss' || currentUser.role === 'admin';
  const activeShiftForUser = shifts.find(
    (s) => s.staffId === currentUser.id && s.venueId === selectedVenue && s.date === todayStr
  );
  const isOnShift = isBossOrAdmin || Boolean(activeShiftForUser);

  // 1. AUTO-FETCH PREVIOUS SHIFT DATA (Firestore Query)
  // When user opens/switches venue, query Firestore for the most recent completed revision for this exact venue
  useEffect(() => {
    let isCancelled = false;

    async function loadPreviousShiftData() {
      setIsLoadingPrevShift(true);
      try {
        const prevRev = await fetchLatestCompletedRevisionForVenue(selectedVenue);
        if (isCancelled) return;

        const mapping: Record<string, number> = {};
        if (prevRev?.items && Array.isArray(prevRev.items) && prevRev.items.length > 0) {
          // 2. Map End Amounts to Start Amounts
          // Extract the "End Amount" (Крайно количество) for each tobacco item from that previous shift's data
          // Automatically set these values as the current shift's "Start Amount" (Стартов грамаж)
          prevRev.items.forEach((item) => {
            mapping[item.tobaccoId] = typeof item.endGrams === 'number' ? item.endGrams : 0;
          });
          // Ensure all tobaccos in the current inventory exist in the map
          currentInv.tobaccos.forEach((t) => {
            if (!(t.id in mapping)) {
              mapping[t.id] = 0;
            }
          });
          setHasPreviousShift(true);
          setPrevShiftInfo({ date: prevRev.date, staffName: prevRev.staffName });
        } else {
          // If no previous shift found for this venue (brand new venue), default Start Amounts to 0
          currentInv.tobaccos.forEach((t) => {
            mapping[t.id] = 0;
          });
          setHasPreviousShift(false);
          setPrevShiftInfo(null);
        }
        setStartAmounts(mapping);
      } catch (err) {
        console.warn('Error fetching previous shift from Firestore:', err);
        const mapping: Record<string, number> = {};
        currentInv.tobaccos.forEach((t) => {
          mapping[t.id] = 0;
        });
        setStartAmounts(mapping);
        setHasPreviousShift(false);
      } finally {
        if (!isCancelled) {
          setIsLoadingPrevShift(false);
        }
      }
    }

    loadPreviousShiftData();

    return () => {
      isCancelled = true;
    };
  }, [selectedVenue]);

  // Helper: Get Start Amount for tobacco (Strictly Read-Only, auto-fetched)
  const getStartAmount = (tobacco: TobaccoItem): number => {
    if (tobacco.id in startAmounts) {
      return startAmounts[tobacco.id];
    }
    return 0;
  };

  // Toggle accordion item
  const toggleAccordion = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  // User interacts with "Loaded" (Заредено) field
  const handleLoadedChange = (tobaccoId: string, val: string) => {
    const sanitized = val.replace(/[^\d.]/g, '');
    setLoadedInputs((prev) => ({
      ...prev,
      [tobaccoId]: sanitized,
    }));
  };

  // User interacts with "End Amount" (Крайно количество) field
  const handleEndChange = (tobaccoId: string, val: string) => {
    const sanitized = val.replace(/[^\d.]/g, '');
    setEndInputs((prev) => ({
      ...prev,
      [tobaccoId]: sanitized,
    }));
  };

  // Filtered tobaccos
  const filteredTobaccos = useMemo(() => {
    return currentInv.tobaccos.filter((t) => {
      const query = searchQuery.toLowerCase().trim();
      if (!query) return true;
      return (
        t.brand.toLowerCase().includes(query) ||
        t.flavor.toLowerCase().includes(query)
      );
    });
  }, [currentInv.tobaccos, searchQuery]);

  // Tobacco Math & Real-time Totals:
  // - Start Amount: Strictly read-only, auto-fetched from previous shift
  // - User interacts with Loaded (Заредено) and End Amount (Крайно)
  // - Used = (Start + Loaded) - End
  // - If Loaded not typed but End > Start, Loaded auto-detects difference
  const { totalStart, totalLoaded, totalEnd, totalUsed, detailedItems } = useMemo(() => {
    let startSum = 0;
    let loadedSum = 0;
    let endSum = 0;
    let usedSum = 0;
    const items: TobaccoRevisionDetail[] = [];

    currentInv.tobaccos.forEach((t) => {
      const start = getStartAmount(t);
      const loadedVal = loadedInputs[t.id];
      const hasLoadedInput = loadedVal !== undefined && loadedVal.trim() !== '';
      const explicitLoaded = hasLoadedInput ? (parseFloat(loadedVal) || 0) : 0;

      const endVal = endInputs[t.id];
      const hasEndInput = endVal !== undefined && endVal.trim() !== '';
      const end = hasEndInput ? (parseFloat(endVal) || 0) : (start + explicitLoaded);

      let loaded = explicitLoaded;
      let used = 0;

      if (hasLoadedInput) {
        // User explicitly specified loaded stock
        used = Math.max(0, Number(((start + loaded) - end).toFixed(1)));
      } else if (hasEndInput) {
        // Auto-difference calculation when user only typed End Amount
        const difference = Number((end - start).toFixed(1));
        if (difference > 0) {
          loaded = difference;
          used = 0;
        } else if (difference < 0) {
          used = Math.abs(difference);
          loaded = 0;
        }
      }

      startSum += start;
      loadedSum += loaded;
      endSum += end;
      usedSum += used;

      if (hasEndInput || hasLoadedInput) {
        items.push({
          tobaccoId: t.id,
          brand: t.brand,
          flavor: t.flavor,
          lineType: t.lineType,
          startGrams: start,
          loadedGrams: loaded,
          endGrams: end,
          usedGrams: used,
        });
      }
    });

    return {
      totalStart: Number(startSum.toFixed(1)),
      totalLoaded: Number(loadedSum.toFixed(1)),
      totalEnd: Number(endSum.toFixed(1)),
      totalUsed: Number(usedSum.toFixed(1)),
      detailedItems: items,
    };
  }, [currentInv.tobaccos, endInputs, loadedInputs, startAmounts]);

  // Consumables Blur Handlers - Persists directly to Firestore and local state
  const handleCharcoalsBlur = async () => {
    const val = parseFloat(charcoalsInput) || 0;
    const updated: VenueInventory = {
      ...currentInv,
      charcoalsKg: val,
      lastUpdated: Date.now(),
    };
    await saveInventoryToFirestore(selectedVenue, updated);
    onUpdateInventory(selectedVenue, updated);
  };

  const handleMouthpiecesBlur = async () => {
    const val = parseInt(mouthpiecesInput, 10) || 0;
    const updated: VenueInventory = {
      ...currentInv,
      mouthpiecePacksCount: val,
      lastUpdated: Date.now(),
    };
    await saveInventoryToFirestore(selectedVenue, updated);
    onUpdateInventory(selectedVenue, updated);
  };

  // Add new tobacco
  const handleAddTobacco = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBrand.trim() || !newFlavor.trim()) {
      onNotify('Въведете марка и вкус!');
      return;
    }
    const gramsNum = parseFloat(newGrams) || 250;
    const newId = `tob-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const newTob: TobaccoItem = {
      id: newId,
      brand: newBrand.trim(),
      flavor: newFlavor.trim(),
      lineType: newLineType,
      grams: gramsNum,
      lastUpdated: Date.now(),
    };

    const updatedInv: VenueInventory = {
      ...currentInv,
      tobaccos: [...currentInv.tobaccos, newTob],
      lastUpdated: Date.now(),
    };

    await saveInventoryToFirestore(selectedVenue, updatedInv);
    onUpdateInventory(selectedVenue, updatedInv);

    setShowAddModal(false);
    setNewBrand('');
    setNewFlavor('');
    onNotify(`Добавен: ${newTob.brand} ${newTob.flavor}`);
  };

  // Delete tobacco - Awaits Firestore persistence first (Fix for Ghost Deletes)
  const handleDeleteTobacco = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Сигурни ли сте, че искате да изтриете този тютюн?')) return;
    const updatedTobaccos = currentInv.tobaccos.filter((t) => t.id !== id);
    const updatedInv: VenueInventory = {
      ...currentInv,
      tobaccos: updatedTobaccos,
      lastUpdated: Date.now(),
    };

    await saveInventoryToFirestore(selectedVenue, updatedInv);
    onUpdateInventory(selectedVenue, updatedInv);
    onNotify('Тютюнът беше премахнат.');
  };

  // Step 1: Save Revision Handler ("Запази ревизия") - ONLY saves tobacco data to Firebase
  const handleSaveRevision = async () => {
    if (!isOnShift) {
      onNotify('Нямате активна смяна за този обект днес.');
      return;
    }

    setIsSavingRevision(true);
    try {
      // 1. Update the inventory counts with the entered End Amounts in Firestore
      const updatedTobaccos = currentInv.tobaccos.map((t) => {
        const endVal = endInputs[t.id];
        if (endVal !== undefined && endVal.trim() !== '') {
          const newGrams = parseFloat(endVal);
          return { ...t, grams: isNaN(newGrams) ? t.grams : Math.max(0, newGrams) };
        }
        const loadedVal = loadedInputs[t.id];
        if (loadedVal !== undefined && loadedVal.trim() !== '') {
          const addGrams = parseFloat(loadedVal) || 0;
          return { ...t, grams: Number((t.grams + addGrams).toFixed(1)) };
        }
        return t;
      });

      const charcoalStart = Number(currentInv.charcoalsKg || 0);
      const charcoalLoaded = Math.max(0, Number.parseFloat(charcoalLoadedInput) || 0);
      const charcoalEndParsed = Number.parseFloat(charcoalEndInput);
      const charcoalEnd = Number.isFinite(charcoalEndParsed) ? Math.max(0, charcoalEndParsed) : charcoalStart + charcoalLoaded;
      if (venueConfig.charcoals && charcoalEnd > charcoalStart + charcoalLoaded) {
        onNotify('Крайната наличност на въглените е по-голяма от началната наличност плюс зареденото количество. Провери стойностите.');
        return;
      }
      const updatedInv: VenueInventory = {
        ...currentInv,
        charcoalsKg: venueConfig.charcoals ? charcoalEnd : currentInv.charcoalsKg,
        tobaccos: updatedTobaccos,
        lastUpdated: Date.now(),
      };

      await saveInventoryToFirestore(selectedVenue, updatedInv);
      onUpdateInventory(selectedVenue, updatedInv);

      // 2. Save DailyRevision record to Firebase
      const revisionRecord: Omit<DailyRevision, 'id' | 'createdAt'> = {
        venueId: selectedVenue,
        date: todayStr,
        staffId: currentUser.id,
        staffName: currentUser.name,
        startAmountGrams: totalStart,
        loadedAmountGrams: totalLoaded,
        endAmountGrams: totalEnd,
        usedTobaccoGrams: totalUsed,
        totalHookahsMade: 0,
        averagePerBowlGrams: 0,
        ...(venueConfig.charcoals ? { charcoalsStartKg: charcoalStart, charcoalsLoadedKg: charcoalLoaded, charcoalsEndKg: charcoalEnd, charcoalsUsedKg: Math.max(0, Number((charcoalStart + charcoalLoaded - charcoalEnd).toFixed(2))) } : {}),
        items: detailedItems,
      };

      await onSaveRevision?.(revisionRecord);
      setJustSavedRevision(true);

      const venueObj = activeVenues.find((v) => v.id === selectedVenue);
      const venueName = venueObj?.name || selectedVenue;

      onNotify(`✓ Ревизията за ${venueName} е запазена успешно!`);
    } catch (err: any) {
      console.error('Error saving revision:', err);
      onNotify('Възникна грешка при запазване на ревизията.');
    } finally {
      setIsSavingRevision(false);
    }
  };

  const hasTodayRevision = useMemo(() => {
    return revisions.some((r) => r.venueId === selectedVenue && r.date === todayStr);
  }, [revisions, selectedVenue, todayStr]);

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Shift Lock Warning for Employees */}
      {!isOnShift && (
        <div className="bg-rose-500/10 border-2 border-rose-500/40 rounded-2xl p-4 flex items-center gap-3 text-xs text-rose-300">
          <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />
          <div>
            <strong className="block text-white text-xs font-bold">Нямате активна смяна за този обект днес.</strong>
            <span className="text-[11px] text-rose-300/80">
              По график днес ({todayStr}) нямате разпределена смяна за този обект. Въвеждането на ревизия е заключено.
            </span>
          </div>
        </div>
      )}

      {/* 1. Venue Switcher */}
      <div className="flex items-center justify-between gap-2 overflow-x-auto pb-1 scrollbar-none">
        <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-2xl">
          {activeVenues.map((v) => {
            const isSelected = v.id === selectedVenue;
            return (
              <button
                key={v.id}
                onClick={() => setSelectedVenue(v.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {v.name}
              </button>
            );
          })}
        </div>

        {/* Minimal Add Tobacco button (Managers only) */}
        {isBossOrAdmin && (
          <button
            onClick={() => setShowAddModal(true)}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-amber-400 hover:text-amber-300 border border-slate-800 rounded-2xl transition-all shadow-xs shrink-0 cursor-pointer"
            title="Добави нов тютюн"
          >
            <Plus className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* 2. Consumables configured per venue by the manager */}
      {(venueConfig.charcoals || venueConfig.mouthpieces) && <div className={`grid ${venueConfig.charcoals && venueConfig.mouthpieces ? 'grid-cols-2' : 'grid-cols-1'} gap-2.5`}>
        {venueConfig.charcoals && <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-xs font-bold text-slate-300">Въглени</span>
          </div>
          <div className="flex items-center gap-1">
            <input
              type="text"
              inputMode="decimal"
              disabled={!isOnShift}
              value={charcoalsInput}
              onChange={(e) => setCharcoalsInput(e.target.value)}
              onBlur={handleCharcoalsBlur}
              className="w-14 bg-slate-950 border border-slate-700 text-white text-right text-xs font-bold rounded-lg px-2 py-1 focus:outline-none focus:border-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
            />
            <span className="text-xs text-slate-400">кг</span>
          </div>
        </div>}

        {venueConfig.mouthpieces && <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Boxes className="w-4 h-4 text-cyan-400 shrink-0" />
            <span className="text-xs font-bold text-slate-300">Мундщуци</span>
          </div>
          <div className="flex items-center gap-1">
            <input
              type="text"
              inputMode="numeric"
              disabled={!isOnShift}
              value={mouthpiecesInput}
              onChange={(e) => setMouthpiecesInput(e.target.value)}
              onBlur={handleMouthpiecesBlur}
              className="w-14 bg-slate-950 border border-slate-700 text-white text-right text-xs font-bold rounded-lg px-2 py-1 focus:outline-none focus:border-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed"
            />
            <span className="text-xs text-slate-400">бр.</span>
          </div>
        </div>}
      </div>}

      {/* Previous Shift Auto-Fetch Status Indicator & Read-Only Notice */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-2.5 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          {isLoadingPrevShift ? (
            <span className="flex items-center gap-1.5 text-amber-400 font-medium">
              <Loader2 className="w-3 h-3 animate-spin shrink-0" />
              Зареждане на стартови наличности от предходна смяна...
            </span>
          ) : hasPreviousShift ? (
            <span>
              <strong className="text-slate-200">Автоматичен стартов грамаж:</strong> Зареден от последната приключена смяна{prevShiftInfo?.date ? ` (${prevShiftInfo.date})` : ''}. Полето е <span className="text-amber-300 font-bold">само за четене</span>.
            </span>
          ) : (
            <span>
              <strong className="text-slate-200">Стартов грамаж:</strong> Няма предходна смяна за обекта (зададен на 0g). Попълват се <strong className="text-emerald-400 font-bold">Заредено</strong> и <strong className="text-amber-300 font-bold">Крайно</strong>.
            </span>
          )}
        </div>
        <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full font-bold border border-slate-700 shrink-0 hidden sm:inline-block">
          Старт = Заключено
        </span>
      </div>

      {/* 3. Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Търси тютюн или вкус..."
          className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500 font-medium"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 text-xs cursor-pointer"
          >
            ✕
          </button>
        )}
      </div>

      {/* 4. ACCORDION TOBACCO ITEMS WITH AUTO-CALCULATION */}
      <div className="space-y-2">
        {filteredTobaccos.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 text-center text-slate-400 text-xs">
            Няма намерени тютюни.
          </div>
        ) : (
          filteredTobaccos.map((tobacco) => {
            const isExpanded = expandedId === tobacco.id;
            const startGrams = getStartAmount(tobacco);

            // User-interactive Loaded Amount
            const loadedVal = loadedInputs[tobacco.id] ?? '';
            const hasLoadedInput = loadedVal.trim() !== '';
            const explicitLoaded = hasLoadedInput ? (parseFloat(loadedVal) || 0) : 0;

            // User-interactive End Amount
            const endVal = endInputs[tobacco.id] ?? '';
            const hasEndInput = endVal.trim() !== '';
            const endGrams = hasEndInput ? (parseFloat(endVal) || 0) : (startGrams + explicitLoaded);

            // Math Calculation:
            // - If user enters Loaded, Used = (Start + Loaded) - End
            // - If user only enters End, Difference = End - Start (Difference > 0 ? Loaded = Difference : Used = |Difference|)
            let loaded = explicitLoaded;
            let used = 0;

            if (hasLoadedInput) {
              used = Math.max(0, Number(((startGrams + loaded) - endGrams).toFixed(1)));
            } else if (hasEndInput) {
              const difference = Number((endGrams - startGrams).toFixed(1));
              if (difference > 0) {
                loaded = difference;
                used = 0;
              } else if (difference < 0) {
                used = Math.abs(difference);
                loaded = 0;
              }
            }

            const percent = calculateTobaccoPercentage(hasEndInput ? endGrams : tobacco.grams);

            return (
              <div
                key={tobacco.id}
                className={`bg-slate-900 border rounded-2xl overflow-hidden transition-all shadow-sm ${
                  isExpanded
                    ? 'border-amber-500/60 shadow-amber-500/5'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* MAIN ROW: Name, Current Weight, Percentage Indicator, Chevron */}
                <div
                  onClick={() => toggleAccordion(tobacco.id)}
                  className="p-3.5 flex items-center justify-between gap-3 cursor-pointer select-none"
                >
                  {/* Left: Tobacco Name */}
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span
                      className={`w-2 h-2 rounded-full shrink-0 ${
                        tobacco.lineType === 'yellow' ? 'bg-amber-400' : 'bg-slate-400'
                      }`}
                    />
                    <div className="truncate">
                      <span className="text-xs sm:text-sm font-bold text-white block truncate leading-tight">
                        {tobacco.brand} <span className="font-normal text-slate-300">{tobacco.flavor}</span>
                      </span>
                    </div>
                  </div>

                  {/* Right: Current Weight, Percentage Indicator, Chevron */}
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs sm:text-sm font-black text-white">
                      {hasEndInput ? `${endGrams}g` : `${tobacco.grams}g`}
                    </span>

                    {/* Percentage Indicator */}
                    <div className="flex items-center gap-1.5 w-16 sm:w-20">
                      <div className="flex-1 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            percent > 50
                              ? 'bg-emerald-500'
                              : percent > 20
                              ? 'bg-amber-500'
                              : 'bg-rose-500'
                          }`}
                          style={{ width: `${percent}%` }}
                        />
                      </div>
                      <span className="text-[10px] font-bold text-slate-400 w-7 text-right">
                        {percent}%
                      </span>
                    </div>

                    <button
                      type="button"
                      className="p-1 text-slate-400 hover:text-white rounded-lg transition-transform"
                    >
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4 text-amber-400" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>

                {/* EXPANDED ACCORDION: Strictly Read-Only Start, User-Interactive Loaded & End */}
                {isExpanded && (
                  <div className="p-3.5 bg-slate-950/80 border-t border-slate-800/80 space-y-3 animate-in fade-in duration-150">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                      {/* 1. START AMOUNT: Strictly READ-ONLY (Auto-fetched from previous shift) */}
                      <div className="bg-slate-900 border border-slate-800 rounded-xl p-2.5 flex flex-col justify-between">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                            <Lock className="w-2.5 h-2.5 text-slate-500" />
                            Стартов / Начално
                          </span>
                          <span className="text-[9px] bg-slate-800 text-slate-400 px-1 py-0.2 rounded font-bold border border-slate-700">
                            Само за четене
                          </span>
                        </div>
                        <div className="text-sm font-black text-white mt-1.5 flex items-baseline justify-between">
                          <span className="text-base text-slate-200">{startGrams}g</span>
                          <span className="text-[9px] text-slate-500 font-medium">
                            {hasPreviousShift ? 'от предна смяна' : 'ново: 0g'}
                          </span>
                        </div>
                      </div>

                      {/* 2. LOADED TOBACCO (Заредено): User-Interactive Input */}
                      <div className="bg-slate-900 border border-slate-800 focus-within:border-emerald-500/70 rounded-xl p-2.5 flex flex-col justify-between">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-bold text-emerald-400 block uppercase tracking-wider">
                            Заредено
                          </label>
                          {hasLoadedInput && (
                            <span className="text-[9px] text-emerald-400 font-bold">+{explicitLoaded}g</span>
                          )}
                        </div>
                        <div className="flex items-center gap-1 mt-1">
                          <input
                            type="text"
                            inputMode="decimal"
                            disabled={!isOnShift}
                            value={loadedVal}
                            onChange={(e) => handleLoadedChange(tobacco.id, e.target.value)}
                            placeholder="0"
                            className="w-full bg-slate-950 border border-slate-800 focus:border-emerald-500 text-emerald-300 font-black text-sm rounded-lg px-2 py-0.5 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed"
                          />
                          <span className="text-[11px] text-emerald-400 font-bold">g</span>
                        </div>
                        <span className="text-[9px] text-slate-400 mt-1 block">Нов запас (ако е зареждано)</span>
                      </div>

                      {/* 3. END AMOUNT (Крайно к-во): User-Interactive Input */}
                      <div className="bg-slate-900 border-2 border-amber-500/60 focus-within:border-amber-400 rounded-xl p-2.5 flex flex-col justify-between shadow-xs">
                        <label className="text-[10px] font-bold text-amber-300 block uppercase tracking-wider">
                          Крайно к-во (Въведи) *
                        </label>
                        <div className="flex items-center gap-1 mt-1">
                          <input
                            type="text"
                            inputMode="decimal"
                            disabled={!isOnShift}
                            value={endVal}
                            onChange={(e) => handleEndChange(tobacco.id, e.target.value)}
                            placeholder={(startGrams + explicitLoaded).toString()}
                            className="w-full bg-slate-950 border border-amber-500 text-white font-black text-sm rounded-lg px-2 py-0.5 focus:outline-none focus:border-amber-400 disabled:opacity-50 disabled:cursor-not-allowed"
                          />
                          <span className="text-[11px] text-amber-300 font-bold">g</span>
                        </div>
                        <span className="text-[9px] text-slate-400 mt-1 block">Текущо претеглен остатък</span>
                      </div>
                    </div>

                    {/* Auto Calculation Result & Difference */}
                    <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/60 flex-wrap gap-2">
                      <div className="flex items-center gap-2 text-slate-300 flex-wrap">
                        <div className="flex items-center gap-1.5">
                          <TrendingDown className="w-3.5 h-3.5 text-amber-400" />
                          <span>Изразходвано:</span>
                          <strong className="text-amber-400 font-black">
                            {used > 0 ? `${used}g` : '0g'}
                          </strong>
                        </div>

                        {(hasLoadedInput || hasEndInput) && (
                          <span className="text-[11px] text-slate-400 font-medium">
                            ({startGrams}g стартово {loaded > 0 ? `+ ${loaded}g заредено ` : ''}- {endGrams}g крайно = <strong className="text-amber-300 font-bold">{used}g</strong>)
                          </span>
                        )}
                      </div>

                      {isBossOrAdmin && (
                        <button
                          onClick={(e) => handleDeleteTobacco(tobacco.id, e)}
                          className="text-slate-500 hover:text-rose-400 p-1 rounded-lg transition-colors cursor-pointer"
                          title="Изтрий тютюн"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Charcoal revision is optional per venue and controlled by the manager */}
      {venueConfig.charcoals && <div className="rounded-2xl border border-orange-500/20 bg-slate-900 p-4 space-y-3">
        <h3 className="text-sm font-black text-orange-300">Ревизия на въглените</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <label className="text-xs font-semibold text-slate-300">Начална наличност (кг)<input type="number" min="0" step="0.01" value={currentInv.charcoalsKg ?? 0} readOnly className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-2.5 text-white opacity-80" /></label>
          <label className="text-xs font-semibold text-slate-300">Заредено през смяната (кг)<input type="number" min="0" step="0.01" value={charcoalLoadedInput} onChange={e=>setCharcoalLoadedInput(e.target.value)} disabled={!isOnShift} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-2.5 text-white disabled:opacity-50" /></label>
          <label className="text-xs font-semibold text-slate-300">Крайна наличност (кг)<input type="number" min="0" step="0.01" value={charcoalEndInput} onChange={e=>setCharcoalEndInput(e.target.value)} disabled={!isOnShift} className="mt-1 w-full rounded-lg border border-slate-700 bg-slate-950 p-2.5 text-white disabled:opacity-50" /></label>
        </div>
        <p className="text-[11px] text-slate-400">Използвани: {Math.max(0, Number(((Number(currentInv.charcoalsKg || 0) + (Number.parseFloat(charcoalLoadedInput) || 0)) - (Number.parseFloat(charcoalEndInput) || 0)).toFixed(2)))} кг</p>
      </div>}

      {/* Step 1: Save revision */}
      <div className="space-y-3 pt-2">
        <button
          type="button"
          onClick={handleSaveRevision}
          disabled={!isOnShift || isSavingRevision}
          className={`w-full py-4 rounded-2xl font-black text-xs sm:text-sm shadow-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
            !isOnShift
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
              : hasTodayRevision || justSavedRevision
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20 active:scale-98'
              : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 shadow-amber-500/20 active:scale-98'
          }`}
        >
          {isSavingRevision ? (
            <>
              <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              <span>Запазване на ревизията...</span>
            </>
          ) : !isOnShift ? (
            <>
              <Lock className="w-4 h-4 text-rose-400" />
              <span>Нямате активна смяна за този обект днес.</span>
            </>
          ) : (
            <>
              <Check className="w-4 h-4" />
              <span>{hasTodayRevision || justSavedRevision ? '✓ Ревизията е запазена (Запази отново)' : 'Запази ревизия'}</span>
            </>
          )}
        </button>

        {/* Transition Card to Step 2 (Report Tab) */}
        {(hasTodayRevision || justSavedRevision) && onNavigateToReports && (
          <div className="bg-emerald-950/40 border border-emerald-500/50 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-md animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                <Check className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">
                  ✓ Стъпка 1 е готова: Ревизията е запазена!
                </span>
                <span className="text-[11px] text-emerald-300/90 block">
                  Преминете към Дневен отчет за въвеждане на бройките наргилета и приключване на смяната.
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={onNavigateToReports}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black rounded-xl shadow-sm transition-all active:scale-95 cursor-pointer shrink-0"
            >
              <span>Към Дневен отчет (Стъпка 2)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Add Tobacco Modal (Boss/Admin Only) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleAddTobacco}
            className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl animate-in fade-in zoom-in-95"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="text-sm font-bold text-white">Нов тютюн</h3>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1">Марка *</label>
              <input
                type="text"
                required
                value={newBrand}
                onChange={(e) => setNewBrand(e.target.value)}
                placeholder="напр. Darkside, Tangiers, Musthave"
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-400 mb-1">Вкус *</label>
              <input
                type="text"
                required
                value={newFlavor}
                onChange={(e) => setNewFlavor(e.target.value)}
                placeholder="напр. Supernova, Cane Mint, Pinkman"
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">Линия</label>
                <select
                  value={newLineType}
                  onChange={(e) => setNewLineType(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-2 py-2 text-xs focus:outline-none focus:border-amber-500"
                >
                  <option value="black">Черно</option>
                  <option value="yellow">Жълто</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-400 mb-1">Грамаж (г)</label>
                <input
                  type="number"
                  value={newGrams}
                  onChange={(e) => setNewGrams(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-3 py-2 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl cursor-pointer"
              >
                Отказ
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl shadow-md cursor-pointer"
              >
                Добави
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
