import React, { useState } from 'react';
import { VenueEquipmentInventory, BowlTypeItem, UserAccount, Venue, PendingApproval, DEFAULT_VENUE_INVENTORY_CONFIG, VenueInventoryConfig } from '../types';
import { DEFAULT_BOWL_TYPES } from '../data/initialData';
import { BreakageModal } from './BreakageModal';
import { 
  Boxes, 
  Plus, 
  Minus,
  Trash2, 
  Table,
  AlertOctagon,
  ShieldAlert
} from 'lucide-react';

interface EquipmentInventoryViewProps {
  equipmentInventories: Record<string, VenueEquipmentInventory>;
  venues: Venue[];
  currentUser: UserAccount;
  pendingApprovals?: PendingApproval[];
  onUpdateEquipment: (venueId: string, updated: VenueEquipmentInventory) => void;
  onRequestApproval?: (approval: Omit<PendingApproval, 'id' | 'createdAt' | 'status'>) => void;
  onOpenApprovalsModal?: () => void;
  onNotify: (msg: string) => void;
  onUpdateVenue?: (venue: Venue) => void;
}

export const EquipmentInventoryView: React.FC<EquipmentInventoryViewProps> = ({
  equipmentInventories,
  venues,
  currentUser,
  pendingApprovals = [],
  onUpdateEquipment,
  onRequestApproval,
  onOpenApprovalsModal,
  onNotify,
  onUpdateVenue,
}) => {
  const isBossOrAdmin = currentUser.role === 'boss' || currentUser.role === 'admin';
  const activeVenues = venues.filter((v) => v.isActive !== false);

  const [selectedVenueId, setSelectedVenueId] = useState<string | 'all'>('bar-hey');
  const [newBowlName, setNewBowlName] = useState('');
  const [newBowlCount, setNewBowlCount] = useState<number>(0);
  const [isAddingBowl, setIsAddingBowl] = useState(false);

  // Breakage Modal State
  const [breakageModalOpen, setBreakageModalOpen] = useState(false);
  const [pendingBreakageItem, setPendingBreakageItem] = useState<{
    itemId: string;
    itemName: string;
    currentCount: number;
    newCount: number;
    field?: 'hookahsCount' | 'electricHookahsCount' | 'vasesCount' | 'hosesCount' | 'hmsCount';
    bowlId?: string;
  } | null>(null);

  // Local inputs buffer for monkey-proof, immediate integer typing
  const [fieldInputs, setFieldInputs] = useState<Record<string, string>>({});

  // Helper to ensure valid venue inventory object
  const getVenueInventory = (vId: string): VenueEquipmentInventory => {
    const existing = equipmentInventories[vId];
    if (existing) {
      const bowlMap = new Map<string, BowlTypeItem>();
      (existing.bowls || []).forEach((b) => bowlMap.set(b.name.toLowerCase(), b));

      DEFAULT_BOWL_TYPES.forEach((def) => {
        if (!bowlMap.has(def.name.toLowerCase())) {
          bowlMap.set(def.name.toLowerCase(), { ...def });
        }
      });

      return {
        ...existing,
        bowls: Array.from(bowlMap.values()),
      };
    }

    return {
      venueId: vId,
      hookahsCount: 0,
      electricHookahsCount: 0,
      vasesCount: 0,
      hosesCount: 0,
      hmsCount: 0,
      bowls: [...DEFAULT_BOWL_TYPES],
      lastUpdated: Date.now(),
    };
  };

  const currentInventory = selectedVenueId !== 'all' ? getVenueInventory(selectedVenueId) : null;
  const currentVenue = venues.find((v) => v.id === selectedVenueId) || venues[0];

  const pendingCount = pendingApprovals.filter((a) => a.status === 'pending').length;
  const currentConfig: VenueInventoryConfig = { ...DEFAULT_VENUE_INVENTORY_CONFIG, ...(currentVenue?.inventoryConfig || {}) };
  const configOptions: Array<{ key: keyof VenueInventoryConfig; label: string }> = [
    { key: 'charcoals', label: 'Въглени' }, { key: 'mouthpieces', label: 'Мундщуци' },
    { key: 'hookahs', label: 'Наргилета' }, { key: 'electricHookahs', label: 'Електрически наргилета' }, { key: 'vases', label: 'Вази' },
    { key: 'hoses', label: 'Маркучи' }, { key: 'bowls', label: 'Чашки' }, { key: 'hms', label: 'HMS' },
  ];
  const toggleConfig = (key: keyof VenueInventoryConfig, enabled: boolean) => {
    if (!currentVenue || !onUpdateVenue || !isBossOrAdmin) return;
    onUpdateVenue({ ...currentVenue, inventoryConfig: { ...currentConfig, [key]: enabled } });
    onNotify(`Настройката „${configOptions.find(o => o.key === key)?.label}“ е обновена за ${currentVenue.name}.`);
  };

  // Handlers for equipment fields (hookahs, vases, hoses, hms)
  const handleFieldChange = (field: 'hookahsCount' | 'electricHookahsCount' | 'vasesCount' | 'hosesCount' | 'hmsCount', val: string) => {
    const digitsOnly = val.replace(/\D/g, '');
    setFieldInputs((prev) => ({ ...prev, [field]: digitsOnly }));
  };

  const handleFieldBlur = (field: 'hookahsCount' | 'electricHookahsCount' | 'vasesCount' | 'hosesCount' | 'hmsCount') => {
    if (!currentInventory || selectedVenueId === 'all') return;
    const raw = fieldInputs[field];
    if (raw === undefined || !raw.trim()) {
      setFieldInputs((prev) => ({ ...prev, [field]: (currentInventory[field] ?? 0).toString() }));
      return;
    }

    const parsed = parseInt(raw, 10);
    const safeVal = isNaN(parsed) || parsed < 0 ? 0 : parsed;

    if (safeVal === (currentInventory[field] ?? 0)) return;

    const labelMap = {
      hookahsCount: 'Наргиле',
      electricHookahsCount: 'Електрическо наргиле',
      vasesCount: 'Ваза',
      hosesCount: 'Маркуч',
      hmsCount: 'HMS',
    };

    // If non-admin is trying to reduce count -> trigger Breakage modal!
    if (!isBossOrAdmin && safeVal < (currentInventory[field] ?? 0)) {
      setPendingBreakageItem({
        itemId: field,
        itemName: labelMap[field],
        currentCount: currentInventory[field] ?? 0,
        newCount: safeVal,
        field,
      });
      setBreakageModalOpen(true);
      // Revert input buffer to original
      setFieldInputs((prev) => ({ ...prev, [field]: (currentInventory[field] ?? 0).toString() }));
      return;
    }

    // Boss or increasing count -> save directly
    setFieldInputs((prev) => ({ ...prev, [field]: safeVal.toString() }));
    const updated: VenueEquipmentInventory = {
      ...currentInventory,
      [field]: safeVal,
      lastUpdated: Date.now(),
      updatedBy: currentUser.name,
    };
    onUpdateEquipment(selectedVenueId, updated);
  };

  // Quick plus/minus for main equipment
  const handleAdjustField = (field: 'hookahsCount' | 'electricHookahsCount' | 'vasesCount' | 'hosesCount' | 'hmsCount', delta: number) => {
    if (!currentInventory || selectedVenueId === 'all') return;
    const current = currentInventory[field] ?? 0;
    const nextVal = Math.max(0, current + delta);
    if (nextVal === current) return;

    const labelMap = {
      hookahsCount: 'Наргиле',
      electricHookahsCount: 'Електрическо наргиле',
      vasesCount: 'Ваза',
      hosesCount: 'Маркуч',
      hmsCount: 'HMS',
    };

    if (delta < 0 && !isBossOrAdmin) {
      setPendingBreakageItem({
        itemId: field,
        itemName: labelMap[field],
        currentCount: current,
        newCount: nextVal,
        field,
      });
      setBreakageModalOpen(true);
      return;
    }

    const updated: VenueEquipmentInventory = {
      ...currentInventory,
      [field]: nextVal,
      lastUpdated: Date.now(),
      updatedBy: currentUser.name,
    };
    onUpdateEquipment(selectedVenueId, updated);
  };

  // Handlers for bowls counts
  const handleBowlChange = (bowlId: string, val: string) => {
    const digitsOnly = val.replace(/\D/g, '');
    setFieldInputs((prev) => ({ ...prev, [`bowl-${bowlId}`]: digitsOnly }));
  };

  const handleBowlBlur = (bowlId: string) => {
    if (!currentInventory || selectedVenueId === 'all') return;
    const target = currentInventory.bowls.find((b) => b.id === bowlId);
    if (!target) return;

    const raw = fieldInputs[`bowl-${bowlId}`];
    if (raw === undefined || !raw.trim()) {
      setFieldInputs((prev) => ({ ...prev, [`bowl-${bowlId}`]: target.count.toString() }));
      return;
    }

    const parsed = parseInt(raw, 10);
    const safeVal = isNaN(parsed) || parsed < 0 ? 0 : parsed;

    if (safeVal === target.count) return;

    // If reducing and not boss -> trigger Breakage modal!
    if (!isBossOrAdmin && safeVal < target.count) {
      setPendingBreakageItem({
        itemId: `bowl-${bowlId}`,
        itemName: `Чашка ${target.name}`,
        currentCount: target.count,
        newCount: safeVal,
        bowlId,
      });
      setBreakageModalOpen(true);
      setFieldInputs((prev) => ({ ...prev, [`bowl-${bowlId}`]: target.count.toString() }));
      return;
    }

    setFieldInputs((prev) => ({ ...prev, [`bowl-${bowlId}`]: safeVal.toString() }));
    const updatedBowls = currentInventory.bowls.map((b) =>
      b.id === bowlId ? { ...b, count: safeVal } : b
    );
    const updated: VenueEquipmentInventory = {
      ...currentInventory,
      bowls: updatedBowls,
      lastUpdated: Date.now(),
      updatedBy: currentUser.name,
    };
    onUpdateEquipment(selectedVenueId, updated);
  };

  // Quick plus/minus for bowls
  const handleAdjustBowl = (bowl: BowlTypeItem, delta: number) => {
    if (!currentInventory || selectedVenueId === 'all') return;
    const nextCount = Math.max(0, bowl.count + delta);
    if (nextCount === bowl.count) return;

    if (delta < 0 && !isBossOrAdmin) {
      setPendingBreakageItem({
        itemId: `bowl-${bowl.id}`,
        itemName: `Чашка ${bowl.name}`,
        currentCount: bowl.count,
        newCount: nextCount,
        bowlId: bowl.id,
      });
      setBreakageModalOpen(true);
      return;
    }

    const updatedBowls = currentInventory.bowls.map((b) =>
      b.id === bowl.id ? { ...b, count: nextCount } : b
    );
    const updated: VenueEquipmentInventory = {
      ...currentInventory,
      bowls: updatedBowls,
      lastUpdated: Date.now(),
      updatedBy: currentUser.name,
    };
    onUpdateEquipment(selectedVenueId, updated);
  };

  // Confirm Breakage modal submission
  const handleConfirmBreakage = (reason: string) => {
    if (!pendingBreakageItem || selectedVenueId === 'all') return;
    const diff = pendingBreakageItem.currentCount - pendingBreakageItem.newCount;

    if (onRequestApproval) {
      onRequestApproval({
        venueId: selectedVenueId,
        staffId: currentUser.id,
        staffName: currentUser.name,
        category: 'equipment',
        itemId: pendingBreakageItem.itemId,
        itemName: pendingBreakageItem.itemName,
        quantityReduced: diff,
        currentCount: pendingBreakageItem.currentCount,
        requestedCount: pendingBreakageItem.newCount,
        reason,
      });
      onNotify('Заявката за брак е изпратена за одобрение от шеф!');
    }
    setPendingBreakageItem(null);
  };

  const handleAddCustomBowl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentInventory || selectedVenueId === 'all') return;
    const trimmed = newBowlName.trim();
    if (!trimmed) return;

    const exists = currentInventory.bowls.some(
      (b) => b.name.toLowerCase() === trimmed.toLowerCase()
    );
    if (exists) {
      onNotify(`Чашката "${trimmed}" вече съществува.`);
      return;
    }

    const safeCount = Math.max(0, newBowlCount);
    const newBowl: BowlTypeItem = {
      id: `bowl-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      name: trimmed,
      count: safeCount,
    };

    const updated: VenueEquipmentInventory = {
      ...currentInventory,
      bowls: [...currentInventory.bowls, newBowl],
      lastUpdated: Date.now(),
      updatedBy: currentUser.name,
    };

    onUpdateEquipment(selectedVenueId, updated);
    setNewBowlName('');
    setNewBowlCount(0);
    setIsAddingBowl(false);
    onNotify(`Добавена: ${trimmed}!`);
  };

  const handleDeleteBowlType = (bowlId: string, bowlName: string) => {
    if (!currentInventory || selectedVenueId === 'all') return;
    if (confirm(`Премахване на "${bowlName}"?`)) {
      const updatedBowls = currentInventory.bowls.filter((b) => b.id !== bowlId);
      const updated: VenueEquipmentInventory = {
        ...currentInventory,
        bowls: updatedBowls,
        lastUpdated: Date.now(),
        updatedBy: currentUser.name,
      };
      onUpdateEquipment(selectedVenueId, updated);
      onNotify(`"${bowlName}" е премахната.`);
    }
  };

  // Aggregated totals across all venues
  const allVenuesData = activeVenues.map((v) => ({
    venue: v,
    inventory: getVenueInventory(v.id),
  }));

  const allBowlNames = Array.from(
    new Set(
      allVenuesData.flatMap((item) => (item.inventory.bowls || []).map((b) => b.name))
    )
  );

  return (
    <div className="space-y-6">
      {/* Breakage Modal */}
      {pendingBreakageItem && (
        <BreakageModal
          isOpen={breakageModalOpen}
          onClose={() => {
            setBreakageModalOpen(false);
            setPendingBreakageItem(null);
          }}
          venueName={currentVenue.name}
          itemName={pendingBreakageItem.itemName}
          currentCount={pendingBreakageItem.currentCount}
          newCount={pendingBreakageItem.newCount}
          onConfirm={handleConfirmBreakage}
        />
      )}

      {/* Top Bar & Venue Switcher */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center shrink-0">
            <Boxes className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-black text-white">Инвентар & Оборудване</h2>
            <p className="text-xs text-slate-400">Наргилета, вази, маркучи и чашки</p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Admin Pending Approvals Quick Button */}
          {isBossOrAdmin && onOpenApprovalsModal && (
            <button
              onClick={onOpenApprovalsModal}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 rounded-xl text-xs font-bold border border-amber-500/30 transition-all shadow-xs"
            >
              <ShieldAlert className="w-4 h-4 text-amber-400" />
              <span>Заявки за брак</span>
              {pendingCount > 0 && (
                <span className="bg-rose-500 text-white text-[10px] font-black px-1.5 py-0.2 rounded-full">
                  {pendingCount}
                </span>
              )}
            </button>
          )}

          {/* Venue Switcher Tabs */}
          <div className="grid grid-cols-4 sm:flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-bold gap-1 w-full sm:w-auto">
            {activeVenues.map((v) => {
              const isSelected = selectedVenueId === v.id;
              return (
                <button
                  key={v.id}
                  onClick={() => {
                    setSelectedVenueId(v.id);
                    setFieldInputs({});
                  }}
                  className={`px-3 py-2 rounded-xl transition-all text-center ${
                    isSelected
                      ? `${v.themeColor.bg} text-white shadow-md font-black`
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60 font-semibold'
                  }`}
                >
                  <span className="truncate">{v.name}</span>
                </button>
              );
            })}

            <button
              onClick={() => {
                setSelectedVenueId('all');
                setFieldInputs({});
              }}
              className={`px-3 py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 text-center ${
                selectedVenueId === 'all'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60 font-semibold'
              }`}
            >
              <Table className="w-3.5 h-3.5 shrink-0" />
              <span>Всички</span>
            </button>
          </div>
        </div>
      </div>

      {isBossOrAdmin && selectedVenueId !== 'all' && currentVenue && onUpdateVenue && (
        <div className="rounded-2xl border border-amber-500/25 bg-slate-900 p-4">
          <h3 className="text-sm font-black text-amber-300 mb-3">Настройки на инвентара за {currentVenue.name}</h3>
          <p className="text-xs text-slate-400 mb-3">Изключи категориите, които не се използват в този обект. Те няма да се показват на служителите.</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
            {configOptions.map(option => <label key={option.key} className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-950/70 p-3 text-xs font-semibold text-slate-200">
              <input type="checkbox" checked={!!currentConfig[option.key]} onChange={e => toggleConfig(option.key, e.target.checked)} className="accent-amber-400 h-4 w-4" />
              {option.label}
            </label>)}
          </div>
        </div>
      )}

      {/* SINGLE VENUE VIEW */}
      {selectedVenueId !== 'all' && currentInventory && (
        <div className="space-y-6">
          {/* 1. Основно оборудване - 4 Direct Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Наргилета */}
            {currentConfig.hookahs && <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-md flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">💨</span>
                <span className="text-sm sm:text-base font-bold text-white">Наргилета</span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => handleAdjustField('hookahsCount', -1)}
                  className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-400 flex items-center justify-center font-bold text-xs"
                  title="Отпиши / бракувай 1 бр."
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={fieldInputs['hookahsCount'] ?? currentInventory.hookahsCount.toString()}
                  onChange={(e) => handleFieldChange('hookahsCount', e.target.value)}
                  onBlur={() => handleFieldBlur('hookahsCount')}
                  className="w-12 bg-slate-950 border border-slate-700 focus:border-amber-400 text-white font-black text-lg rounded-lg text-center p-1"
                />
                <button
                  type="button"
                  onClick={() => handleAdjustField('hookahsCount', 1)}
                  className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-emerald-950 text-slate-300 hover:text-emerald-400 flex items-center justify-center font-bold text-xs"
                  title="Добави 1 бр."
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>}

            {currentConfig.electricHookahs && <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-md flex items-center justify-between gap-3">
              <div className="flex items-center gap-2"><span className="text-2xl">⚡</span><span className="text-sm sm:text-base font-bold text-white">Електрически наргилета</span></div>
              <div className="flex items-center gap-1 shrink-0">
                <button type="button" onClick={() => handleAdjustField('electricHookahsCount', -1)} className="w-7 h-7 rounded-lg bg-slate-800 text-slate-300 hover:text-rose-400 flex items-center justify-center"><Minus className="w-3.5 h-3.5"/></button>
                <input type="text" inputMode="numeric" pattern="[0-9]*" value={fieldInputs['electricHookahsCount'] ?? (currentInventory.electricHookahsCount ?? 0).toString()} onChange={e => handleFieldChange('electricHookahsCount', e.target.value)} onBlur={() => handleFieldBlur('electricHookahsCount')} className="w-12 bg-slate-950 border border-slate-700 text-white font-black text-lg rounded-lg text-center p-1"/>
                <button type="button" onClick={() => handleAdjustField('electricHookahsCount', 1)} className="w-7 h-7 rounded-lg bg-slate-800 text-slate-300 hover:text-emerald-400 flex items-center justify-center"><Plus className="w-3.5 h-3.5"/></button>
              </div>
            </div>}

            {/* Вази */}
            {currentConfig.vases && <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-md flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🏺</span>
                <span className="text-sm sm:text-base font-bold text-white">Вази</span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => handleAdjustField('vasesCount', -1)}
                  className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-400 flex items-center justify-center font-bold text-xs"
                  title="Отпиши / бракувай 1 бр."
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={fieldInputs['vasesCount'] ?? currentInventory.vasesCount.toString()}
                  onChange={(e) => handleFieldChange('vasesCount', e.target.value)}
                  onBlur={() => handleFieldBlur('vasesCount')}
                  className="w-12 bg-slate-950 border border-slate-700 focus:border-cyan-400 text-white font-black text-lg rounded-lg text-center p-1"
                />
                <button
                  type="button"
                  onClick={() => handleAdjustField('vasesCount', 1)}
                  className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-emerald-950 text-slate-300 hover:text-emerald-400 flex items-center justify-center font-bold text-xs"
                  title="Добави 1 бр."
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>}

            {/* Маркучи */}
            {currentConfig.hoses && <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-md flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🐍</span>
                <span className="text-sm sm:text-base font-bold text-white">Маркучи</span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => handleAdjustField('hosesCount', -1)}
                  className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-400 flex items-center justify-center font-bold text-xs"
                  title="Отпиши / бракувай 1 бр."
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={fieldInputs['hosesCount'] ?? currentInventory.hosesCount.toString()}
                  onChange={(e) => handleFieldChange('hosesCount', e.target.value)}
                  onBlur={() => handleFieldBlur('hosesCount')}
                  className="w-12 bg-slate-950 border border-slate-700 focus:border-emerald-400 text-white font-black text-lg rounded-lg text-center p-1"
                />
                <button
                  type="button"
                  onClick={() => handleAdjustField('hosesCount', 1)}
                  className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-emerald-950 text-slate-300 hover:text-emerald-400 flex items-center justify-center font-bold text-xs"
                  title="Добави 1 бр."
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>}

            {/* HMS */}
            {currentConfig.hms && <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-md flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">🔥</span>
                <span className="text-sm sm:text-base font-bold text-white">HMS</span>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => handleAdjustField('hmsCount', -1)}
                  className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-400 flex items-center justify-center font-bold text-xs"
                  title="Отпиши / бракувай 1 бр."
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <input
                  type="text"
                  inputMode="numeric"
                  pattern="[0-9]*"
                  value={fieldInputs['hmsCount'] ?? currentInventory.hmsCount.toString()}
                  onChange={(e) => handleFieldChange('hmsCount', e.target.value)}
                  onBlur={() => handleFieldBlur('hmsCount')}
                  className="w-12 bg-slate-950 border border-slate-700 focus:border-orange-400 text-white font-black text-lg rounded-lg text-center p-1"
                />
                <button
                  type="button"
                  onClick={() => handleAdjustField('hmsCount', 1)}
                  className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-emerald-950 text-slate-300 hover:text-emerald-400 flex items-center justify-center font-bold text-xs"
                  title="Добави 1 бр."
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>}
          </div>

          {/* 2. Чашки по модели */}
          {currentConfig.bowls && <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <span>🥣 Чашки по видове ({currentVenue.name})</span>
                </h3>
                <p className="text-xs text-slate-400">
                  При намаляване на бройка (счупване) се отваря заявка за брак за одобрение от шеф
                </p>
              </div>

              <button
                onClick={() => setIsAddingBowl(!isAddingBowl)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{isAddingBowl ? 'Отказ' : 'Нов модел чашка'}</span>
              </button>
            </div>

            {/* Inline add form */}
            {isAddingBowl && (
              <form onSubmit={handleAddCustomBowl} className="p-4 bg-slate-950 rounded-2xl border border-amber-500/40 space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Име / Модел *</label>
                    <input
                      type="text"
                      value={newBowlName}
                      onChange={(e) => setNewBowlName(e.target.value)}
                      placeholder="напр. Alpaca Huacaya"
                      required
                      className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-2.5 font-bold focus:outline-none focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Начален брой</label>
                    <input
                      type="number"
                      min="0"
                      value={newBowlCount}
                      onChange={(e) => setNewBowlCount(parseInt(e.target.value, 10) || 0)}
                      className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-2.5 font-bold focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsAddingBowl(false)}
                    className="px-3 py-1.5 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl"
                  >
                    Отказ
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-amber-500 text-slate-950 text-xs font-black rounded-xl hover:bg-amber-400"
                  >
                    Запази модела
                  </button>
                </div>
              </form>
            )}

            {/* Bowls list */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {currentInventory.bowls.map((bowl) => (
                <div
                  key={bowl.id}
                  className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-2xl p-3.5 flex items-center justify-between gap-3 shadow-xs"
                >
                  <div className="min-w-0">
                    <span className="text-sm font-extrabold text-white block truncate">{bowl.name}</span>
                    <span className="text-[10px] text-slate-400">Чашка</span>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleAdjustBowl(bowl, -1)}
                      className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-400 flex items-center justify-center font-bold text-xs"
                      title="Бракувай / намали бройка"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <input
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={fieldInputs[`bowl-${bowl.id}`] ?? bowl.count.toString()}
                      onChange={(e) => handleBowlChange(bowl.id, e.target.value)}
                      onBlur={() => handleBowlBlur(bowl.id)}
                      className="w-12 bg-slate-900 border border-slate-700 focus:border-amber-400 text-white font-black text-base rounded-lg text-center p-1"
                    />
                    <button
                      type="button"
                      onClick={() => handleAdjustBowl(bowl, 1)}
                      className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-emerald-950 text-slate-300 hover:text-emerald-400 flex items-center justify-center font-bold text-xs"
                      title="Добави бройка"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>

                    {isBossOrAdmin && (
                      <button
                        type="button"
                        onClick={() => handleDeleteBowlType(bowl.id, bowl.name)}
                        className="p-1 text-slate-600 hover:text-rose-400 rounded-lg ml-1"
                        title="Изтрий модела"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>}
        </div>
      )}

      {/* ALL VENUES COMPARISON TABLE */}
      {selectedVenueId === 'all' && (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4 overflow-x-auto">
          <h3 className="text-base font-extrabold text-white flex items-center gap-2">
            <Table className="w-5 h-5 text-amber-400" />
            <span>Сравнителна таблица на оборудването по обекти</span>
          </h3>

          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 font-bold">
                <th className="pb-3 pr-4">Артикул</th>
                {allVenuesData.map((d) => (
                  <th key={d.venue.id} className="pb-3 px-3 text-center">
                    <span className="font-extrabold text-white">{d.venue.name}</span>
                  </th>
                ))}
                <th className="pb-3 pl-3 text-right text-amber-400 font-black">ОБЩО</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-semibold">
              <tr>
                <td className="py-2.5 pr-4 text-white font-bold">💨 Наргилета</td>
                {allVenuesData.map((d) => (
                  <td key={d.venue.id} className="py-2.5 px-3 text-center text-slate-200">
                    {d.inventory.hookahsCount}
                  </td>
                ))}
                <td className="py-2.5 pl-3 text-right text-amber-400 font-black">
                  {allVenuesData.reduce((acc, d) => acc + d.inventory.hookahsCount, 0)}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-4 text-white font-bold">⚡ Електрически наргилета</td>
                {allVenuesData.map((d) => (
                  <td key={d.venue.id} className="py-2.5 px-3 text-center text-slate-200">
                    {({ ...DEFAULT_VENUE_INVENTORY_CONFIG, ...(d.venue.inventoryConfig || {}) }).electricHookahs ? (d.inventory.electricHookahsCount || 0) : '—'}
                  </td>
                ))}
                <td className="py-2.5 pl-3 text-right text-cyan-300 font-black">
                  {allVenuesData.reduce((acc, d) => acc + (({ ...DEFAULT_VENUE_INVENTORY_CONFIG, ...(d.venue.inventoryConfig || {}) }).electricHookahs ? (d.inventory.electricHookahsCount || 0) : 0), 0)}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-4 text-white font-bold">🏺 Вази</td>
                {allVenuesData.map((d) => (
                  <td key={d.venue.id} className="py-2.5 px-3 text-center text-slate-200">
                    {d.inventory.vasesCount}
                  </td>
                ))}
                <td className="py-2.5 pl-3 text-right text-cyan-400 font-black">
                  {allVenuesData.reduce((acc, d) => acc + d.inventory.vasesCount, 0)}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-4 text-white font-bold">🐍 Маркучи</td>
                {allVenuesData.map((d) => (
                  <td key={d.venue.id} className="py-2.5 px-3 text-center text-slate-200">
                    {d.inventory.hosesCount}
                  </td>
                ))}
                <td className="py-2.5 pl-3 text-right text-emerald-400 font-black">
                  {allVenuesData.reduce((acc, d) => acc + d.inventory.hosesCount, 0)}
                </td>
              </tr>
              <tr>
                <td className="py-2.5 pr-4 text-white font-bold">🔥 HMS</td>
                {allVenuesData.map((d) => (
                  <td key={d.venue.id} className="py-2.5 px-3 text-center text-slate-200">
                    {d.inventory.hmsCount}
                  </td>
                ))}
                <td className="py-2.5 pl-3 text-right text-orange-400 font-black">
                  {allVenuesData.reduce((acc, d) => acc + d.inventory.hmsCount, 0)}
                </td>
              </tr>

              {/* Bowls list */}
              {allBowlNames.map((bName) => {
                const total = allVenuesData.reduce((acc, d) => {
                  const bowl = (d.inventory.bowls || []).find(
                    (b) => b.name.toLowerCase() === bName.toLowerCase()
                  );
                  return acc + (bowl?.count || 0);
                }, 0);

                return (
                  <tr key={bName}>
                    <td className="py-2 pr-4 text-slate-300">🥣 {bName}</td>
                    {allVenuesData.map((d) => {
                      const bowl = (d.inventory.bowls || []).find(
                        (b) => b.name.toLowerCase() === bName.toLowerCase()
                      );
                      return (
                        <td key={d.venue.id} className="py-2 px-3 text-center text-slate-400">
                          {bowl?.count || 0}
                        </td>
                      );
                    })}
                    <td className="py-2 pl-3 text-right text-white font-black">{total}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
