import { Venue, UserAccount, VenueInventory, VenueEquipmentInventory, Shift, ShiftReport, VenuePricing, VenueId, WageSettings, BowlTypeItem } from '../types';
import { getMonday, formatDate } from '../utils/dateUtils';

export const DEFAULT_WAGE_SETTINGS: WageSettings = {
  baseWageEur: 23,
  hookahRateEur: 1,
  currency: '€',
  updatedAt: Date.now(),
};

export const VENUES: Venue[] = [
  {
    id: 'bar-hey',
    name: 'Бар хей',
    tagline: 'Парти бар & наргиле лаундж',
    shortCode: 'BH',
    isActive: true,
    themeColor: {
      bg: 'bg-amber-600',
      text: 'text-amber-700',
      border: 'border-amber-500',
      badgeBg: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
      badgeText: 'text-amber-400',
      accent: '#d97706',
      lightBg: 'bg-amber-950/20',
    },
  },
  {
    id: 'zero-zero',
    name: 'Зеро Зеро',
    tagline: 'Коктейли & наргилета',
    shortCode: 'ZZ',
    isActive: true,
    themeColor: {
      bg: 'bg-emerald-600',
      text: 'text-emerald-700',
      border: 'border-emerald-500',
      badgeBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      badgeText: 'text-emerald-400',
      accent: '#059669',
      lightBg: 'bg-emerald-950/20',
    },
  },
  {
    id: 'de-rouge',
    name: 'Бар Де Руж',
    tagline: 'Елегантен вино бар & клуб наргилета',
    shortCode: 'DR',
    isActive: true,
    themeColor: {
      bg: 'bg-rose-700',
      text: 'text-rose-700',
      border: 'border-rose-500',
      badgeBg: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
      badgeText: 'text-rose-400',
      accent: '#be123c',
      lightBg: 'bg-rose-950/20',
    },
  },
];

// Default selling prices per venue (ценоразпис за продажба на наргилета)
export const DEFAULT_VENUE_PRICING: Record<VenueId, VenuePricing> = {
  'bar-hey': {
    venueId: 'bar-hey',
    yellowPriceEur: 15,
    blackPriceEur: 18,
    officialPriceEur: 0,
  },
  'zero-zero': {
    venueId: 'zero-zero',
    yellowPriceEur: 15,
    blackPriceEur: 18,
    officialPriceEur: 0,
  },
  'de-rouge': {
    venueId: 'de-rouge',
    yellowPriceEur: 16,
    blackPriceEur: 20,
    officialPriceEur: 0,
  },
};

// Predefined initial boss account for initial access (default name 'boss', editable by boss)
export const INITIAL_USERS: UserAccount[] = [
  {
    id: 'usr-boss-1',
    name: 'boss',
    pin: '1234',
    role: 'boss',
    phone: '',
    avatarColor: 'bg-amber-500 text-slate-950',
  },
];

// Initial blank inventories for each venue - will be filled manually by staff and bosses
export const INITIAL_INVENTORIES: Record<string, VenueInventory> = {
  'bar-hey': {
    venueId: 'bar-hey',
    charcoalsKg: 0,
    mouthpiecePacksCount: 0,
    lastUpdated: Date.now(),
    tobaccos: [],
  },
  'zero-zero': {
    venueId: 'zero-zero',
    charcoalsKg: 0,
    mouthpiecePacksCount: 0,
    lastUpdated: Date.now(),
    tobaccos: [],
  },
  'de-rouge': {
    venueId: 'de-rouge',
    charcoalsKg: 0,
    mouthpiecePacksCount: 0,
    lastUpdated: Date.now(),
    tobaccos: [],
  },
};

// Standard default bowl types
export const DEFAULT_BOWL_TYPES: BowlTypeItem[] = [
  { id: 'bowl-cosmo', name: 'CosmoBowl', count: 0 },
  { id: 'bowl-bengala', name: 'Bengala', count: 0 },
  { id: 'bowl-oblako', name: 'Oblako', count: 0 },
  { id: 'bowl-voskurimsya', name: 'Вускуримзя', count: 0 },
  { id: 'bowl-funnel-cosmo', name: 'funnel Cosmo', count: 0 },
];

export const INITIAL_EQUIPMENT_INVENTORIES: Record<string, VenueEquipmentInventory> = {
  'bar-hey': {
    venueId: 'bar-hey',
    hookahsCount: 0,
    electricHookahsCount: 0,
    vasesCount: 0,
    hosesCount: 0,
    hmsCount: 0,
    bowls: [
      { id: 'bowl-cosmo', name: 'CosmoBowl', count: 0 },
      { id: 'bowl-bengala', name: 'Bengala', count: 0 },
      { id: 'bowl-oblako', name: 'Oblako', count: 0 },
      { id: 'bowl-voskurimsya', name: 'Вускуримзя', count: 0 },
      { id: 'bowl-funnel-cosmo', name: 'funnel Cosmo', count: 0 },
    ],
    lastUpdated: Date.now(),
  },
  'zero-zero': {
    venueId: 'zero-zero',
    hookahsCount: 0,
    electricHookahsCount: 0,
    vasesCount: 0,
    hosesCount: 0,
    hmsCount: 0,
    bowls: [
      { id: 'bowl-cosmo', name: 'CosmoBowl', count: 0 },
      { id: 'bowl-bengala', name: 'Bengala', count: 0 },
      { id: 'bowl-oblako', name: 'Oblako', count: 0 },
      { id: 'bowl-voskurimsya', name: 'Вускуримзя', count: 0 },
      { id: 'bowl-funnel-cosmo', name: 'funnel Cosmo', count: 0 },
    ],
    lastUpdated: Date.now(),
  },
  'de-rouge': {
    venueId: 'de-rouge',
    hookahsCount: 0,
    electricHookahsCount: 0,
    vasesCount: 0,
    hosesCount: 0,
    hmsCount: 0,
    bowls: [
      { id: 'bowl-cosmo', name: 'CosmoBowl', count: 0 },
      { id: 'bowl-bengala', name: 'Bengala', count: 0 },
      { id: 'bowl-oblako', name: 'Oblako', count: 0 },
      { id: 'bowl-voskurimsya', name: 'Вускуримзя', count: 0 },
      { id: 'bowl-funnel-cosmo', name: 'funnel Cosmo', count: 0 },
    ],
    lastUpdated: Date.now(),
  },
};

// Initial shifts - blank schedule, to be manually entered by staff and bosses
export function generateSeedShifts(_monday?: Date): Shift[] {
  return [];
}

// Initial reports - blank, to be manually submitted at shift end
export function generateSeedReports(_monday?: Date): ShiftReport[] {
  return [];
}

