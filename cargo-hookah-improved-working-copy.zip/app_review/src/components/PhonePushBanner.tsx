import React, { useState, useEffect } from 'react';
import { UserAccount } from '../types';
import { 
  checkPushSupportStatus, 
  subscribeToPushNotifications, 
  triggerTestPushNotification,
  PushSupportStatus 
} from '../utils/pushManager';
import { 
  Bell, 
  BellRing, 
  Share2, 
  PlusSquare, 
  CheckCircle2, 
  X, 
  Send,
  Loader2
} from 'lucide-react';

interface PhonePushBannerProps {
  currentUser: UserAccount;
  onNotify: (msg: string) => void;
}

export const PhonePushBanner: React.FC<PhonePushBannerProps> = ({
  currentUser,
  onNotify,
}) => {
  const [status, setStatus] = useState<PushSupportStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);
  const [isDismissed, setIsDismissed] = useState<boolean>(() => {
    return localStorage.getItem('cargo_push_banner_dismissed') === 'true';
  });

  const refreshStatus = async () => {
    try {
      const s = await checkPushSupportStatus();
      setStatus(s);
    } catch (e) {
      console.warn('Failed to check push status:', e);
    }
  };

  useEffect(() => {
    refreshStatus();
  }, [currentUser]);

  if (!status || !status.isSupported || isDismissed) {
    return null;
  }

  const handleEnablePush = async () => {
    setLoading(true);
    try {
      const res = await subscribeToPushNotifications(currentUser);
      if (res.success) {
        onNotify('🔔 Известията на телефона са включени успешно!');
        await refreshStatus();
      } else {
        onNotify(res.error || 'Неуспешно включване на известията.');
      }
    } catch (err: any) {
      onNotify(err.message || 'Грешка при активиране на известията.');
    } finally {
      setLoading(false);
    }
  };

  const handleTestNotification = async () => {
    setTesting(true);
    try {
      const res = await triggerTestPushNotification(currentUser);
      onNotify(res.message);
    } catch (err: any) {
      onNotify('Грешка при тестване: ' + err.message);
    } finally {
      setTesting(false);
    }
  };

  const handleDismiss = () => {
    setIsDismissed(true);
    localStorage.setItem('cargo_push_banner_dismissed', 'true');
  };

  // 1. If notifications are already granted - Slim minimal bar
  if (status.permission === 'granted') {
    return (
      <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl px-3 py-2 flex items-center justify-between gap-2.5 text-xs shadow-xs animate-in fade-in duration-200">
        <div className="flex items-center gap-2 min-w-0">
          <BellRing className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <span className="text-emerald-300 font-bold truncate text-[11px] sm:text-xs">
            Телефонните известия са активни (напомняния за смени & чекиране)
          </span>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={handleTestNotification}
            disabled={testing}
            className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-200 border border-emerald-500/40 rounded-lg text-[11px] font-bold transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            {testing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Send className="w-3 h-3" />}
            <span className="hidden xs:inline">{testing ? 'Изпращане...' : 'Тест'}</span>
          </button>
          <button
            type="button"
            onClick={handleDismiss}
            className="text-slate-400 hover:text-slate-200 p-1"
            title="Затвори"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  // 2. If on iOS Safari outside standalone mode - Slim guidance bar
  if (status.isIOS && !status.isStandalone) {
    return (
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-3 py-2 flex items-center justify-between gap-2.5 text-xs shadow-xs animate-in fade-in duration-200">
        <div className="flex items-center gap-2 min-w-0">
          <Share2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span className="text-amber-200 font-medium text-[11px] sm:text-xs truncate">
            <strong>iPhone известия:</strong> Тапнете <strong>Сподели</strong> в Safari → <strong>„Към началния екран“</strong>
          </span>
        </div>

        <button
          type="button"
          onClick={handleDismiss}
          className="text-slate-400 hover:text-white p-1 shrink-0"
          title="Затвори"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  // 3. Android / Desktop / iOS Standalone: Sleek, slim, unobtrusive prompt bar
  return (
    <div className="bg-amber-500/10 border border-amber-500/40 rounded-xl px-3 py-2 flex items-center justify-between gap-2.5 text-xs shadow-xs animate-in fade-in duration-200">
      <div className="flex items-center gap-2 min-w-0">
        <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
          <Bell className="w-3.5 h-3.5" />
        </div>
        <div className="min-w-0">
          <span className="text-white font-bold text-[11px] sm:text-xs block truncate">
            Включете известия на телефона
          </span>
          <span className="text-amber-300/80 text-[10px] hidden sm:block truncate">
            Звукови напомняния за смени, чекиране и брак директно на заключен екран
          </span>
        </div>
      </div>

      <div className="flex items-center gap-1.5 shrink-0">
        <button
          type="button"
          onClick={handleEnablePush}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 text-[11px] sm:text-xs font-black rounded-lg shadow-sm active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
        >
          {loading ? (
            <Loader2 className="w-3 h-3 animate-spin" />
          ) : (
            <BellRing className="w-3 h-3" />
          )}
          <span>{loading ? 'Активиране...' : 'Включи'}</span>
        </button>

        <button
          type="button"
          onClick={handleDismiss}
          className="text-slate-400 hover:text-white p-1"
          title="Затвори"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
