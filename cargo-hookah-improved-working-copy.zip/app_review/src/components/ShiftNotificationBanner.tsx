import React, { useState, useEffect } from 'react';
import { Shift, Venue, UserAccount } from '../types';
import { formatDate } from '../utils/dateUtils';
import { Clock, CheckCircle2, Scale, ArrowRight, ShieldCheck, FileText } from 'lucide-react';

interface ShiftNotificationBannerProps {
  shifts: Shift[];
  venues: Venue[];
  currentUser: UserAccount;
  onClockIn: (shiftId: string, venueId: string) => void;
  onNavigateToRevision?: () => void;
  onNavigateToReports?: () => void;
}

export const ShiftNotificationBanner: React.FC<ShiftNotificationBannerProps> = ({
  shifts,
  venues,
  currentUser,
  onClockIn,
  onNavigateToRevision,
  onNavigateToReports,
}) => {
  const [now, setNow] = useState<Date>(new Date());

  // Update clock every 30 seconds
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(timer);
  }, []);

  const todayStr = formatDate(now);

  // Find shift assigned to currentUser today
  const todayShift = shifts.find(
    (s) => s.staffId === currentUser.id && s.date === todayStr
  );

  if (!todayShift) return null;

  const venue = venues.find((v) => v.id === todayShift.venueId);
  const venueName = venue?.name || todayShift.venueId;

  // Parse shift start and end time
  const [startH, startM] = (todayShift.startTime || '16:00').split(':').map(Number);
  const shiftStartDate = new Date(now);
  shiftStartDate.setHours(startH, startM, 0, 0);

  const [endH, endM] = (todayShift.endTime || '00:00').split(':').map(Number);
  const shiftEndDate = new Date(now);
  shiftEndDate.setHours(endH, endM, 0, 0);
  if (endH < startH) {
    shiftEndDate.setDate(shiftEndDate.getDate() + 1);
  }

  const diffMs = shiftStartDate.getTime() - now.getTime();
  const diffMinutes = Math.round(diffMs / (60 * 1000));

  const hasClockedIn = Boolean(todayShift.isClockedIn) || Boolean(todayShift.clockInTimestamp);
  const isShiftEnded = now.getTime() >= shiftEndDate.getTime() - 30 * 60 * 1000;

  const isOneHourBefore = diffMinutes > 0 && diffMinutes <= 60 && !hasClockedIn;
  const isClockInTime = diffMinutes <= 15 && !hasClockedIn && !isShiftEnded;

  if (!isOneHourBefore && !isClockInTime && !hasClockedIn && !isShiftEnded) {
    return null;
  }

  return (
    <div className="space-y-2">
      {/* 1 Hour Before Shift Alert - Sleek Slim Banner */}
      {isOneHourBefore && !hasClockedIn && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-3.5 py-2.5 flex items-center justify-between gap-3 text-xs shadow-xs animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5 min-w-0">
            <Clock className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
            <span className="text-white font-bold truncate">
              Смяната в {venueName} започва в {todayShift.startTime} ч. (след ~{diffMinutes} мин.)
            </span>
          </div>
          <span className="text-[11px] text-amber-300 font-bold shrink-0">
            {todayShift.staffName}
          </span>
        </div>
      )}

      {/* Clock In Prompt - Sleek, Unobtrusive Emerald Banner */}
      {isClockInTime && (
        <div className="bg-gradient-to-r from-emerald-950/80 to-slate-900 border border-emerald-500/60 rounded-xl px-3.5 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-md animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-7 h-7 rounded-lg bg-emerald-500 text-slate-950 flex items-center justify-center font-black shrink-0">
              <Clock className="w-4 h-4 animate-spin duration-1000" />
            </div>
            <div>
              <span className="text-white font-bold block text-xs">
                Смяната в {venueName} започна ({todayShift.startTime} ч.)
              </span>
              <span className="text-emerald-300/80 text-[11px]">
                Моля отбележете присъствието си
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onClockIn(todayShift.id, todayShift.venueId)}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black rounded-lg shadow-sm active:scale-95 transition-all shrink-0 cursor-pointer"
          >
            <CheckCircle2 className="w-4 h-4 text-slate-950" />
            <span>На работа съм (Clock In)</span>
          </button>
        </div>
      )}

      {/* Clocked In Confirmation Badge - Slim and Discrete */}
      {hasClockedIn && !isShiftEnded && (
        <div className="bg-slate-900/80 border border-emerald-500/30 rounded-xl px-3 py-1.5 flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2 text-emerald-400 font-medium text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="truncate">
              Чекиран в {venueName} ({todayShift.clockInTimeString || 'начало на смяна'})
            </span>
          </div>
          <span className="text-[10px] text-slate-400 shrink-0">
            {todayShift.startTime} - {todayShift.endTime}
          </span>
        </div>
      )}

      {/* Shift End Time Reminder - Sleek Slim Action Bar */}
      {isShiftEnded && (
        <div className="bg-amber-500/10 border border-amber-500/40 rounded-xl px-3.5 py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 text-xs shadow-xs animate-in fade-in duration-200">
          <div className="flex items-center gap-2.5 min-w-0">
            <Scale className="w-4 h-4 text-amber-400 shrink-0" />
            <div>
              <span className="text-white font-bold block text-xs">
                Край на смяната в {venueName}!
              </span>
              <span className="text-amber-200/80 text-[11px]">
                Попълнете Ревизия на тютюните и подайте Дневен отчет
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {onNavigateToRevision && (
              <button
                type="button"
                onClick={onNavigateToRevision}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold text-[11px] rounded-lg shadow-xs transition-all active:scale-95 cursor-pointer"
              >
                <Scale className="w-3.5 h-3.5 text-amber-400" />
                <span>1. Ревизия</span>
              </button>
            )}
            {onNavigateToReports && (
              <button
                type="button"
                onClick={onNavigateToReports}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[11px] rounded-lg shadow-sm transition-all active:scale-95 cursor-pointer"
              >
                <FileText className="w-3.5 h-3.5 text-slate-950" />
                <span>2. Дневен отчет</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
