import { 
  UserAccount, 
  Venue,
  VenueInventory, 
  VenueEquipmentInventory,
  Shift, 
  ShiftReport, 
  DailyRevision,
  PendingApproval,
  ClockInRecord,
  ShiftConflict,
  VenuePricing,
  VenueId,
  WageSettings,
  EmployeeFine,
  StaffTask
} from '../types';
import { 
  INITIAL_USERS, 
  VENUES,
  INITIAL_INVENTORIES, 
  INITIAL_EQUIPMENT_INVENTORIES,
  DEFAULT_VENUE_PRICING,
  DEFAULT_WAGE_SETTINGS,
  generateSeedShifts, 
  generateSeedReports 
} from '../data/initialData';
import { getMonday, formatDate } from './dateUtils';

const STORAGE_KEY = 'hookah_catering_app_state_v9_advanced';
const CURRENT_USER_KEY = 'hookah_catering_current_user_v9_advanced';

export interface AppState {
  users: UserAccount[];
  venues: Venue[];
  inventories: Record<string, VenueInventory>;
  equipmentInventories: Record<string, VenueEquipmentInventory>;
  shifts: Shift[];
  reports: ShiftReport[];
  revisions: DailyRevision[];
  pendingApprovals: PendingApproval[];
  clockIns: ClockInRecord[];
  fines: EmployeeFine[];
  tasks: StaffTask[];
  pricing: Record<string, VenuePricing>;
  wageSettings: WageSettings;
  customLogo?: string | null;
}

export function loadAppState(): AppState {
  try {
    let raw = localStorage.getItem(STORAGE_KEY);
    // Backward compatibility load from previous key
    if (!raw) {
      raw = localStorage.getItem('hookah_catering_app_state_v8_equipment') ||
            localStorage.getItem('hookah_catering_app_state_v7_boss_only') || 
            localStorage.getItem('hookah_catering_app_state_v5_blank');
    }

    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed.inventories && parsed.shifts && parsed.reports) {
        // Ensure pricing exists
        const pricing = parsed.pricing || DEFAULT_VENUE_PRICING;
        const wageSettings = parsed.wageSettings || DEFAULT_WAGE_SETTINGS;
        const fines = Array.isArray(parsed.fines) ? parsed.fines : [];
        const tasks = Array.isArray(parsed.tasks) ? parsed.tasks : [];
        const equipmentInventories = parsed.equipmentInventories || INITIAL_EQUIPMENT_INVENTORIES;
        const venues = Array.isArray(parsed.venues) && parsed.venues.length > 0 ? parsed.venues : VENUES;
        const revisions = Array.isArray(parsed.revisions) ? parsed.revisions : [];
        const pendingApprovals = Array.isArray(parsed.pendingApprovals) ? parsed.pendingApprovals : [];
        const clockIns = Array.isArray(parsed.clockIns) ? parsed.clockIns : [];

        // Ensure mouthpieces are in packs
        const inventories = { ...parsed.inventories };
        Object.keys(inventories).forEach((vId) => {
          const inv = inventories[vId];
          if (inv.mouthpiecePacksCount === undefined) {
            inv.mouthpiecePacksCount = inv.mouthpiecesCount ?? 0;
          }
        });

        // Keep ALL registered and added employees and boss profiles
        let cleanedUsers: UserAccount[] = [];
        if (Array.isArray(parsed.users) && parsed.users.length > 0) {
          cleanedUsers = parsed.users;
        } else {
          cleanedUsers = INITIAL_USERS;
        }

        // Ensure at least one boss profile exists
        if (!cleanedUsers.some((u) => u.role === 'boss' || u.role === 'admin')) {
          cleanedUsers = [...INITIAL_USERS, ...cleanedUsers];
        }

        const state: AppState = {
          users: cleanedUsers,
          venues,
          inventories,
          equipmentInventories,
          shifts: parsed.shifts,
          reports: parsed.reports,
          revisions,
          pendingApprovals,
          clockIns,
          fines,
          tasks,
          pricing,
          wageSettings,
          customLogo: parsed.customLogo || (typeof window !== 'undefined' ? localStorage.getItem('hookah_custom_logo') : null) || null,
        };
        saveAppState(state);
        return state;
      }
    }
  } catch (err) {
    console.error('Error loading hookah catering state:', err);
  }

  // Blank initial default state
  const defaultState: AppState = {
    users: INITIAL_USERS,
    venues: VENUES,
    inventories: INITIAL_INVENTORIES,
    equipmentInventories: INITIAL_EQUIPMENT_INVENTORIES,
    shifts: [],
    reports: [],
    revisions: [],
    pendingApprovals: [],
    clockIns: [],
    fines: [],
    tasks: [],
    pricing: DEFAULT_VENUE_PRICING,
    wageSettings: DEFAULT_WAGE_SETTINGS,
    customLogo: typeof window !== 'undefined' ? localStorage.getItem('hookah_custom_logo') || null : null,
  };

  saveAppState(defaultState);
  return defaultState;
}

export function resetAppStateToBlank(): AppState {
  const blankState: AppState = {
    users: INITIAL_USERS,
    venues: VENUES,
    inventories: {
      'bar-hey': { venueId: 'bar-hey', charcoalsKg: 0, mouthpiecePacksCount: 0, lastUpdated: Date.now(), tobaccos: [] },
      'zero-zero': { venueId: 'zero-zero', charcoalsKg: 0, mouthpiecePacksCount: 0, lastUpdated: Date.now(), tobaccos: [] },
      'de-rouge': { venueId: 'de-rouge', charcoalsKg: 0, mouthpiecePacksCount: 0, lastUpdated: Date.now(), tobaccos: [] },
    },
    equipmentInventories: INITIAL_EQUIPMENT_INVENTORIES,
    shifts: [],
    reports: [],
    revisions: [],
    pendingApprovals: [],
    clockIns: [],
    fines: [],
    tasks: [],
    pricing: DEFAULT_VENUE_PRICING,
    wageSettings: DEFAULT_WAGE_SETTINGS,
    customLogo: typeof window !== 'undefined' ? localStorage.getItem('hookah_custom_logo') || null : null,
  };
  saveAppState(blankState);
  return blankState;
}

export function saveAppState(state: AppState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    if (state.customLogo) {
      localStorage.setItem('hookah_custom_logo', state.customLogo);
    }
  } catch (err) {
    console.error('Error saving app state:', err);
  }
}

export function getSavedCurrentUser(users: UserAccount[]): UserAccount | null {
  try {
    const savedId = localStorage.getItem(CURRENT_USER_KEY);
    if (savedId) {
      const found = users.find((u) => u.id === savedId);
      if (found) return found;
    }
  } catch (err) {
    console.error(err);
  }
  return null;
}

export function saveCurrentUser(user: UserAccount | null): void {
  try {
    if (user) {
      localStorage.setItem(CURRENT_USER_KEY, user.id);
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  } catch (err) {
    console.error(err);
  }
}

// Conflict detector
export function detectConflicts(shifts: Shift[]): ShiftConflict[] {
  const map = new Map<string, Shift[]>(); // `${date}_${staffId}`

  shifts.forEach((shift) => {
    const key = `${shift.date}_${shift.staffId}`;
    const list = map.get(key) || [];
    list.push(shift);
    map.set(key, list);
  });

  const conflicts: ShiftConflict[] = [];
  map.forEach((list) => {
    if (list.length > 1) {
      conflicts.push({
        date: list[0].date,
        staffId: list[0].staffId,
        staffName: list[0].staffName,
        shifts: list,
        message: `${list[0].staffName} има ${list.length} смени на една и съща дата!`,
      });
    }
  });

  return conflicts;
}

// Copy shifts from one week to another
export function copyWeekShifts(
  existingShifts: Shift[],
  sourceMonday: Date,
  targetMonday: Date,
  createdById: string
): Shift[] {
  const sourceMondayStr = formatDate(sourceMonday);
  const sourceSunday = new Date(sourceMonday);
  sourceSunday.setDate(sourceMonday.getDate() + 6);
  const sourceSundayStr = formatDate(sourceSunday);

  const targetMondayStr = formatDate(targetMonday);
  const targetSunday = new Date(targetMonday);
  targetSunday.setDate(targetMonday.getDate() + 6);
  const targetSundayStr = formatDate(targetSunday);

  const weekShifts = existingShifts.filter(
    (s) => s.date >= sourceMondayStr && s.date <= sourceSundayStr
  );

  const otherShifts = existingShifts.filter(
    (s) => s.date < targetMondayStr || s.date > targetSundayStr
  );

  const diffDays = Math.round(
    (targetMonday.getTime() - sourceMonday.getTime()) / (1000 * 60 * 60 * 24)
  );

  const copiedShifts: Shift[] = weekShifts.map((shift) => {
    const shiftDate = new Date(shift.date);
    shiftDate.setDate(shiftDate.getDate() + diffDays);
    return {
      ...shift,
      id: `sh-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      date: formatDate(shiftDate),
      createdById,
      createdAt: Date.now(),
    };
  });

  return [...otherShifts, ...copiedShifts];
}

// Server-side synchronization for multi-device support
export async function fetchServerState(): Promise<AppState | null> {
  try {
    const res = await fetch('/api/state', { cache: 'no-store' });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.state && Array.isArray(data.state.users)) {
      return data.state as AppState;
    }
  } catch (e) {
    console.warn('Could not fetch server state:', e);
  }
  return null;
}

export async function apiSaveInventory(venueId: VenueId, inventory: VenueInventory): Promise<boolean> {
  try {
    const res = await fetch(`/api/inventory/${encodeURIComponent(venueId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ inventory }),
    });
    return res.ok;
  } catch (e) {
    console.error('Error saving inventory to server:', e);
    return false;
  }
}

export async function apiSaveEquipment(venueId: VenueId, equipment: VenueEquipmentInventory): Promise<boolean> {
  try {
    const res = await fetch(`/api/equipment/${encodeURIComponent(venueId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ equipment }),
    });
    return res.ok;
  } catch (e) {
    console.error('Error saving equipment to server:', e);
    return false;
  }
}

export async function apiSaveShift(shift: Shift): Promise<boolean> {
  try {
    const res = await fetch('/api/shifts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ shift }),
    });
    return res.ok;
  } catch (e) {
    console.error('Error saving shift to server:', e);
    return false;
  }
}

export async function apiDeleteShift(shiftId: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/shifts/${encodeURIComponent(shiftId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch (e) {
    console.error('Error deleting shift from server:', e);
    return false;
  }
}

export async function apiSaveReport(report: ShiftReport): Promise<boolean> {
  try {
    const res = await fetch('/api/reports', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ report }),
    });
    return res.ok;
  } catch (e) {
    console.error('Error saving report to server:', e);
    return false;
  }
}

export async function apiDeleteReport(reportId: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/reports/${encodeURIComponent(reportId)}`, {
      method: 'DELETE',
    });
    return res.ok;
  } catch (e) {
    console.error('Error deleting report from server:', e);
    return false;
  }
}

export async function apiSavePricing(pricing: Record<VenueId, VenuePricing>, requesterRole = 'boss'): Promise<boolean> {
  try {
    const res = await fetch('/api/pricing', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-user-role': requesterRole,
      },
      body: JSON.stringify({ pricing, requesterRole }),
    });
    return res.ok;
  } catch (e) {
    console.error('Error saving pricing to server:', e);
    return false;
  }
}

export async function apiSaveUser(user: UserAccount, requesterRole = 'boss'): Promise<{ success: boolean; users?: UserAccount[] }> {
  try {
    const res = await fetch('/api/users', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'x-user-role': requesterRole,
      },
      body: JSON.stringify({ user, requesterRole }),
    });
    if (!res.ok) return { success: false };
    const data = await res.json();
    return { success: !!data.success, users: data.users };
  } catch (e) {
    console.error('Error saving user to server:', e);
    return { success: false };
  }
}

export async function apiDeleteUser(userId: string, requesterRole = 'boss'): Promise<{ success: boolean; users?: UserAccount[] }> {
  try {
    const res = await fetch(`/api/users/${encodeURIComponent(userId)}`, {
      method: 'DELETE',
      headers: {
        'x-user-role': requesterRole,
      },
    });
    if (!res.ok) return { success: false };
    const data = await res.json();
    return { success: !!data.success, users: data.users };
  } catch (e) {
    console.error('Error deleting user from server:', e);
    return { success: false };
  }
}

export async function apiSyncState(clientState: Partial<AppState>): Promise<AppState | null> {
  try {
    const res = await fetch('/api/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(clientState),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.state) {
      return data.state as AppState;
    }
  } catch (e) {
    console.warn('Error syncing state with server:', e);
  }
  return null;
}

export async function saveStateToServer(state: AppState): Promise<boolean> {
  try {
    const res = await fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(state),
    });
    return res.ok;
  } catch (e) {
    console.warn('Could not sync state to server:', e);
    return false;
  }
}

export async function apiSaveWageSettings(
  wageSettings: WageSettings, 
  requesterRole = 'boss',
  users?: UserAccount[]
): Promise<{ success: boolean; wageSettings?: WageSettings; users?: UserAccount[] }> {
  try {
    const res = await fetch('/api/wage-settings', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'x-user-role': requesterRole,
      },
      body: JSON.stringify({ ...wageSettings, requesterRole, users }),
    });
    if (!res.ok) return { success: false };
    const data = await res.json();
    return { success: !!data.success, wageSettings: data.wageSettings, users: data.users };
  } catch (e) {
    console.error('Error saving wage settings to server:', e);
    return { success: false };
  }
}

export async function apiFetchWageSettings(): Promise<WageSettings | null> {
  try {
    const res = await fetch('/api/wage-settings');
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.wageSettings) {
      return data.wageSettings as WageSettings;
    }
  } catch (e) {
    console.warn('Could not fetch wage settings:', e);
  }
  return null;
}

export async function apiSaveFine(fine: EmployeeFine): Promise<{ success: boolean; fines?: EmployeeFine[] }> {
  try {
    const res = await fetch('/api/fines', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fine }),
    });
    if (!res.ok) return { success: false };
    const data = await res.json();
    return { success: !!data.success, fines: data.fines };
  } catch (e) {
    console.error('Error saving fine to server:', e);
    return { success: false };
  }
}

export async function apiDeleteFine(fineId: string): Promise<{ success: boolean; fines?: EmployeeFine[] }> {
  try {
    const res = await fetch(`/api/fines/${encodeURIComponent(fineId)}`, {
      method: 'DELETE',
    });
    if (!res.ok) return { success: false };
    const data = await res.json();
    return { success: !!data.success, fines: data.fines };
  } catch (e) {
    console.error('Error deleting fine from server:', e);
    return { success: false };
  }
}

export async function apiFetchFines(): Promise<EmployeeFine[]> {
  try {
    const res = await fetch('/api/fines');
    if (!res.ok) return [];
    const data = await res.json();
    if (data.success && Array.isArray(data.fines)) {
      return data.fines as EmployeeFine[];
    }
  } catch (e) {
    console.warn('Could not fetch fines:', e);
  }
  return [];
}

export async function apiUploadLogo(logoDataUrl: string): Promise<{ success: boolean; customLogo?: string }> {
  try {
    const res = await fetch('/api/logo', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ logoDataUrl }),
    });
    if (!res.ok) return { success: false };
    const data = await res.json();
    if (data.success && data.customLogo) {
      try {
        localStorage.setItem('hookah_custom_logo', data.customLogo);
      } catch {}
      return { success: true, customLogo: data.customLogo };
    }
  } catch (e) {
    console.error('Error uploading logo:', e);
  }
  return { success: false };
}

export async function apiFetchLogo(): Promise<string | null> {
  try {
    const res = await fetch('/api/logo');
    if (!res.ok) return null;
    const data = await res.json();
    if (data.success && data.customLogo) {
      try {
        localStorage.setItem('hookah_custom_logo', data.customLogo);
      } catch {}
      return data.customLogo;
    }
  } catch (e) {
    console.warn('Could not fetch logo:', e);
  }
  return null;
}

export async function apiSavePendingApproval(approval: PendingApproval): Promise<boolean> {
  try {
    const res = await fetch('/api/pending-approvals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ approval }),
    });
    return res.ok;
  } catch (e) {
    console.warn('Could not post pending approval to server:', e);
    return false;
  }
}

export async function apiReviewPendingApproval(
  approvalId: string, 
  status: 'approved' | 'rejected', 
  reviewedBy: string,
  reviewNote?: string
): Promise<boolean> {
  try {
    const res = await fetch(`/api/pending-approvals/${encodeURIComponent(approvalId)}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, reviewedBy, reviewNote }),
    });
    return res.ok;
  } catch (e) {
    console.warn('Could not review pending approval:', e);
    return false;
  }
}

export async function apiSaveRevision(revision: DailyRevision): Promise<boolean> {
  try {
    const res = await fetch('/api/revisions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ revision }),
    });
    return res.ok;
  } catch (e) {
    console.warn('Could not save revision to server:', e);
    return false;
  }
}

export async function apiSaveClockIn(clockIn: ClockInRecord): Promise<boolean> {
  try {
    const res = await fetch('/api/clock-ins', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clockIn }),
    });
    return res.ok;
  } catch (e) {
    console.warn('Could not save clock-in to server:', e);
    return false;
  }
}

export async function apiSaveVenues(venues: Venue[]): Promise<boolean> {
  try {
    const res = await fetch('/api/venues', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ venues }),
    });
    return res.ok;
  } catch (e) {
    console.warn('Could not save venues to server:', e);
    return false;
  }
}



