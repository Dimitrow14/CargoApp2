import express from 'express';
import type { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import webpush from 'web-push';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Gemini client with telemetry header as required by skill
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

async function startServer() {
  const app = express();
  // Dev server must run on port 3000 (nginx listens on 8080 in container)
  const port = process.env.PORT && process.env.PORT !== '8080' ? parseInt(process.env.PORT) : 3000;

  // Cybersecurity 1: Hide framework fingerprint
  app.disable('x-powered-by');

  // Security & no-cache headers compatible with AI Studio preview iframe
  app.use((_req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Permissions-Policy', 'camera=(self), microphone=(), geolocation=()');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
  });

  // Cybersecurity 3: In-Memory IP Rate Limiter (DDoS & Brute-Force Protection)
  const ipRequestCounts = new Map<string, { count: number; resetTime: number }>();
  const RATE_LIMIT_WINDOW_MS = 60 * 1000; // 1 minute
  const MAX_GLOBAL_API_REQUESTS = 600; // 600 requests per min for multi-device polling across team
  const MAX_AI_REQUESTS = 25; // 25 requests per min for AI report scans

  // Periodic cleanup of rate limiter map every 5 minutes
  setInterval(() => {
    const now = Date.now();
    for (const [ip, record] of ipRequestCounts.entries()) {
      if (now > record.resetTime) {
        ipRequestCounts.delete(ip);
      }
    }
  }, 5 * 60 * 1000);

  const getClientIp = (req: Request): string => {
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string') return forwarded.split(',')[0].trim();
    if (Array.isArray(forwarded)) return forwarded[0].trim();
    return req.socket.remoteAddress || 'unknown';
  };

  const createRateLimiter = (maxRequests: number) => {
    return (req: Request, res: Response, next: () => void) => {
      const ip = getClientIp(req);
      const now = Date.now();
      const record = ipRequestCounts.get(ip);

      if (!record || now > record.resetTime) {
        ipRequestCounts.set(ip, { count: 1, resetTime: now + RATE_LIMIT_WINDOW_MS });
        return next();
      }

      if (record.count >= maxRequests) {
        const retryAfterSec = Math.ceil((record.resetTime - now) / 1000);
        res.setHeader('Retry-After', retryAfterSec);
        return res.status(429).json({
          error: 'Превишен лимит на заявките (Rate Limit). Моля изчакайте няколко секунди.',
          retryAfter: retryAfterSec,
        });
      }

      record.count += 1;
      next();
    };
  };

  // Cybersecurity 4: Input Sanitization Helper
  const sanitizeString = (str: any, maxLen = 300): string => {
    if (typeof str !== 'string') return '';
    return str
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/javascript:/gi, '')
      .replace(/on\w+=/gi, '')
      .trim()
      .slice(0, maxLen);
  };

  // Cybersecurity 5: Role-based Boss Authorization Guard
  const requireBossRole = (req: Request, res: Response, next: () => void) => {
    const role = (req.headers['x-user-role'] || req.body?.requesterRole || '') as string;
    if (role !== 'boss') {
      return res.status(403).json({
        error: 'Достъпът е отказан! Само потребител с роля "шеф" има право да извършва това действие.',
      });
    }
    next();
  };

  // Apply general rate limit to all /api/ endpoints
  app.use('/api/', createRateLimiter(MAX_GLOBAL_API_REQUESTS));

  // JSON parsing with high limit for base64 report photos
  app.use(express.json({ limit: '30mb' }));
  app.use(express.urlencoded({ extended: true, limit: '30mb' }));

  // API endpoint for analyzing and cross-checking report photo (with specialized AI rate limiter)
  app.post('/api/analyze-report', createRateLimiter(MAX_AI_REQUESTS), async (req: Request, res: Response) => {
    try {
      const { photoDataUrl, enteredData, customCriteria } = req.body;

      if (!photoDataUrl || typeof photoDataUrl !== 'string') {
        return res.status(400).json({ error: 'Липсва снимка за анализ' });
      }

      // Safe base64 extraction without expensive or buggy regex
      let mimeType = 'image/jpeg';
      let base64Data = photoDataUrl;
      const commaIdx = photoDataUrl.indexOf(',');
      if (commaIdx !== -1) {
        const meta = photoDataUrl.slice(0, commaIdx);
        base64Data = photoDataUrl.slice(commaIdx + 1);
        const mimeMatch = meta.match(/data:([^;]+)/);
        if (mimeMatch) {
          mimeType = mimeMatch[1];
        }
      }

      // Strip any whitespace or newlines from base64
      base64Data = base64Data.trim();

      const total =
        enteredData?.totalHookahs ??
        Number(enteredData?.yellowHookahs || 0) + Number(enteredData?.blackHookahs || 0);
      const yellow = Number(enteredData?.yellowHookahs || 0);
      const black = Number(enteredData?.blackHookahs || 0);
      const official = Number(enteredData?.officialCount || 0);
      const venue = enteredData?.venueName || enteredData?.venueId || 'непосочено';
      const date = enteredData?.date || 'непосочена дата';

      // Custom criteria or default recognition keywords
      const criteriaList = customCriteria && typeof customCriteria === 'string' && customCriteria.trim().length > 0
        ? customCriteria.trim()
        : 'Наргиле Жълто, Наргиле Черно, Наргиле ОС, Наргиле Дарксайд, Наргиле OS, Наргиле Darkside, Наргиле Musthave, Наргиле Blackburn, Наргиле Tangiers, Наргиле Revoshi, Наргиле Adalya, Наргиле Al Fakher, Наргиле Класик, Shisha, Hookah, Шиша, Смяна глава, Чашка';

      const prompt = `Вие сте експертен асистент за бързо, умно и изключително надеждно разчитане на дневни отчети и бележки от заведенията на Cargo Hookah (Бар Хей, Зеро Зеро, Бар Де Руж).

ВАЖНО - ФОРМАТ НА СНИМКИТЕ:
Снимката може да бъде един от следните видове:
1. РЪКОПИСНО НАПИСАН ТЕКСТ НА ЛИСТ ХАРТИЯ, ПЛИК / ПИСМО (напр. на гърба на писмо, в което са събрани марките) ИЛИ ТЕФТЕР:
   - Пример 1: "Общо: 12, Жълто: 4, Черно: 8" -> detectedHookahs = 12, detectedYellow = 4, detectedBlack = 8!
   - Пример 2: "12 общо, 4 жълти, 8 черни" -> detectedHookahs = 12, detectedYellow = 4, detectedBlack = 8!
   - Пример 3: "Жълто: 4, Черно: 8" -> detectedHookahs = 12, detectedYellow = 4, detectedBlack = 8!
   - Пример 4: "Ж 5, Ч 7" или "4 жълти, 6 черни, 2 служебни" -> разчетете бройките незабавно!
2. МАРКИ ОТ НАРГИЛЕТА (жетони, хартиени талончета/марки) събрани накуп или в плик:
   - Пребройте жълтите и черните марки и техния сбор!
3. КАСОВ БОН, ФИСКАЛЕН ОТЧЕТ ИЛИ POS СМЕТКА:
   - Разпознайте редовете с наргилета, умножителите (напр. "2 x Наргиле ОС", "4 x Наргиле Жълто", "8 x Наргиле Черно") и ги класифицирайте.

АРТИКУЛИ И КЛАСИФИКАЦИЯ:
- Жълти / Леки ("yellow"): "Наргиле Жълто", "Жълто", "Наргиле ОС", "Наргиле OS", "Overdose", "Adalya", "Revoshi", "Al Fakher", "Starline", "Класик", "Леко".
- Черни / Силни ("black"): "Наргиле Черно", "Черно", "Наргиле Дарксайд", "Наргиле Darkside", "Musthave", "Blackburn", "Tangiers", "Element", "Силно".
Допълнителни: "${criteriaList}"

ПРАВИЛА:
1. Ако на снимката има ръкописен текст като "Общо: X, Жълто: Y, Черно: Z" или списък с бройки наргилета, извлечете ТОЧНО тези числа за detectedHookahs, detectedYellow, detectedBlack.
2. Върнете status = "verified" веднага щом откриете валидни бройки наргилета от снимката.
3. Обобщението (summary) трябва да бъде максимално кратко и ясно, например: "Разчетено от снимката: Общо 12 (Жълто: 4, Черно: 8)".

Върнете валиден JSON отговор.`;

      const responseSchemaConfig = {
        type: Type.OBJECT,
        properties: {
          status: {
            type: Type.STRING,
            description: 'verified, warning, or unclear',
          },
          summary: {
            type: Type.STRING,
            description: 'Обобщение на разчетеното от снимката на български език',
          },
          detectedItems: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING, description: 'Име на артикула от бележката, напр. Наргиле ОС, Наргиле Darkside, Наргиле Жълто, Наргиле Черно, Наргиле OS, Наргиле Дарксайд' },
                brand: { type: Type.STRING, description: 'Разпозната марка: "Наргиле Жълто", "Наргиле Черно", "Наргиле ОС", "Наргиле Дарксайд", "Наргиле OS", "Наргиле Darkside" или друга марка' },
                quantity: { type: Type.NUMBER, description: 'Брой/количество от този артикул' },
                lineType: { type: Type.STRING, description: 'yellow (жълто/леко), black (черно/силно), or other' },
                price: { type: Type.NUMBER, description: 'Единична цена или сума за реда' },
                rawLine: { type: Type.STRING, description: 'Оригинален текст от реда на касовия бон' },
              },
              required: ['name', 'quantity', 'lineType'],
            },
            description: 'Списък с всеки открит ред наргиле от бележката',
          },
          detectedHookahs: {
            type: Type.NUMBER,
            description: 'Разчетен общ брой наргилета от снимката или бележката (-1 ако не се установява)',
          },
          detectedYellow: {
            type: Type.NUMBER,
            description: 'Разчетени жълти/леки наргилета (Наргиле Жълто, Наргиле ОС, Наргиле OS и др.)',
          },
          detectedBlack: {
            type: Type.NUMBER,
            description: 'Разчетени черни/силни наргилета (Наргиле Черно, Наргиле Дарксайд, Наргиле Darkside и др.)',
          },
          detectedRevenue: {
            type: Type.NUMBER,
            description: 'Разчетена обща парична сума от бележката (0 ако липсва)',
          },
          detectedCurrency: {
            type: Type.STRING,
            description: 'лв. или €',
          },
          detectedVenue: {
            type: Type.STRING,
            description: 'Разчетено име на заведение/обект от бележката',
          },
          detectedDate: {
            type: Type.STRING,
            description: 'Разчетена дата от бележката',
          },
          matches: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Списък с потвърдени съответствия с въведените данни',
          },
          discrepancies: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: 'Списък с открити несъответствия или забележки',
          },
        },
        required: ['status', 'summary', 'matches', 'discrepancies'],
      };

      // Multi-model execution with automatic fast fallback
      // gemini-3.1-flash-lite is instantaneous (~1s) and supports multimodal vision
      // gemini-3.8-flash provides deep fallback
      const candidateModels = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];
      let response: any = null;
      let lastError: any = null;

      for (const modelName of candidateModels) {
        try {
          response = await ai.models.generateContent({
            model: modelName,
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    inlineData: {
                      data: base64Data,
                      mimeType,
                    },
                  },
                  {
                    text: prompt,
                  },
                ],
              },
            ],
            config: {
              responseMimeType: 'application/json',
              responseSchema: responseSchemaConfig,
              thinkingConfig: {
                thinkingBudget: 0,
              },
            },
          });
          if (response && response.text) {
            break;
          }
        } catch (mErr: any) {
          lastError = mErr;
          console.warn(`Model ${modelName} failed in /api/analyze-report, trying next:`, mErr?.message || mErr);
        }
      }

      if (!response || !response.text) {
        throw lastError || new Error('Моделът не върна текст при анализа');
      }

      let rawText = response.text || '{}';
      // Clean potential markdown fences or surrounding commentary
      rawText = rawText.replace(/```json/gi, '').replace(/```/g, '').trim();
      const firstBrace = rawText.indexOf('{');
      const lastBrace = rawText.lastIndexOf('}');
      if (firstBrace !== -1 && lastBrace !== -1) {
        rawText = rawText.substring(firstBrace, lastBrace + 1);
      }

      let parsedResult: any = {};
      try {
        parsedResult = JSON.parse(rawText);
      } catch (pErr) {
        console.warn('Could not parse Gemini JSON response:', rawText);
        parsedResult = {
          status: 'warning',
          summary: 'Снимката е разчетена, но отговорът не беше в стандартен формат.',
          matches: [],
          discrepancies: ['Възникна грешка при обработка на резултата.'],
        };
      }

      // Helper for brand recognition and classification normalization
      const normalizeBrandAndType = (rawName: string, rawLine?: string, existingBrand?: string, existingType?: string) => {
        const text = `${rawName} ${rawLine || ''} ${existingBrand || ''}`.toLowerCase();
        
        // 1. "Наргиле ОС" vs "Наргиле OS"
        if (/наргиле\s+ос|нарг\.?\s*ос|\bос\b/i.test(text) && !/darkside|дарксайд|overdo/i.test(text)) {
          return { brand: 'Наргиле ОС', lineType: 'yellow' as const };
        }
        if (/наргиле\s+os|нарг\.?\s*os|\bos\b|overdose|overdozz/i.test(text) && !/darkside|дарксайд/i.test(text)) {
          return { brand: 'Наргиле OS', lineType: 'yellow' as const };
        }

        // 2. "Наргиле Дарксайд" vs "Наргиле Darkside"
        if (/наргиле\s+дарксайд|нарг\.?\s*дарксайд|дарксайд/i.test(text) && !/darkside/i.test(text)) {
          return { brand: 'Наргиле Дарксайд', lineType: 'black' as const };
        }
        if (/наргиле\s+darkside|нарг\.?\s*darkside|darkside|\bds\b/i.test(text)) {
          return { brand: 'Наргиле Darkside', lineType: 'black' as const };
        }

        // 3. "Наргиле Жълто"
        if (/наргиле\s+жълт|нарг\.?\s*жълт|жълто|жълт/i.test(text)) {
          return { brand: 'Наргиле Жълто', lineType: 'yellow' as const };
        }

        // 4. "Наргиле Черно"
        if (/наргиле\s+черн|нарг\.?\s*черн|черно|черен/i.test(text)) {
          return { brand: 'Наргиле Черно', lineType: 'black' as const };
        }

        // Additional light/yellow shisha brands
        if (/adalya|revoshi|al fakher|holster|starline|класик|лека|леко/i.test(text)) {
          return { brand: existingBrand || 'Наргиле Жълто', lineType: 'yellow' as const };
        }

        // Additional dark/black shisha brands
        if (/musthave|blackburn|tangiers|element|дарк|силно/i.test(text)) {
          return { brand: existingBrand || 'Наргиле Черно', lineType: 'black' as const };
        }

        const validLineType = existingType === 'yellow' || existingType === 'black' ? existingType : 'other';
        return { brand: existingBrand, lineType: validLineType };
      };

      // Process detected items list with enhanced brand mapping
      const detectedItems = Array.isArray(parsedResult.detectedItems)
        ? parsedResult.detectedItems.map((item: any) => {
            const rawName = String(item.name || 'Наргиле');
            const rawLine = item.rawLine ? String(item.rawLine) : undefined;
            const norm = normalizeBrandAndType(rawName, rawLine, item.brand, item.lineType);

            return {
              name: rawName,
              brand: norm.brand,
              quantity: typeof item.quantity === 'number' && item.quantity > 0 ? item.quantity : 1,
              lineType: norm.lineType,
              price: typeof item.price === 'number' ? item.price : undefined,
              rawLine,
            };
          })
        : [];

      // Calculate totals from items if missing or inconsistent
      let detectedTotal = typeof parsedResult.detectedHookahs === 'number' && parsedResult.detectedHookahs >= 0
        ? parsedResult.detectedHookahs
        : undefined;

      let detectedY = typeof parsedResult.detectedYellow === 'number' && parsedResult.detectedYellow >= 0
        ? parsedResult.detectedYellow
        : undefined;

      let detectedB = typeof parsedResult.detectedBlack === 'number' && parsedResult.detectedBlack >= 0
        ? parsedResult.detectedBlack
        : undefined;

      if (detectedItems.length > 0) {
        const itemsTotal = detectedItems.reduce((acc: number, item: any) => acc + item.quantity, 0);
        const itemsYellow = detectedItems
          .filter((i: any) => i.lineType === 'yellow')
          .reduce((acc: number, item: any) => acc + item.quantity, 0);
        const itemsBlack = detectedItems
          .filter((i: any) => i.lineType === 'black')
          .reduce((acc: number, item: any) => acc + item.quantity, 0);

        if (detectedTotal === undefined || detectedTotal <= 0) {
          detectedTotal = itemsTotal;
        }
        if (detectedY === undefined) {
          detectedY = itemsYellow;
        }
        if (detectedB === undefined) {
          detectedB = itemsBlack;
        }
      }

      // Check match status against entered numbers
      let finalStatus: 'verified' | 'warning' | 'unclear' =
        parsedResult.status === 'verified' || parsedResult.status === 'unclear'
          ? parsedResult.status
          : 'warning';

      if (detectedTotal !== undefined && detectedTotal > 0) {
        if (total === 0 || detectedTotal === total) {
          finalStatus = 'verified';
        } else {
          finalStatus = 'warning';
        }
      }

      let summaryText = parsedResult.summary || 'Бележката е разчетена успешно.';
      if (detectedTotal !== undefined && detectedTotal > 0 && total === 0) {
        summaryText = `Разчетени са ${detectedTotal} наргилета от снимката (${detectedY ?? 0} жълти / леки, ${detectedB ?? 0} черни / силни).`;
      }

      return res.json({
        success: true,
        verification: {
          status: finalStatus,
          summary: summaryText,
          detectedItems,
          detectedHookahs: detectedTotal,
          detectedYellow: detectedY,
          detectedBlack: detectedB,
          detectedRevenue:
            typeof parsedResult.detectedRevenue === 'number' && parsedResult.detectedRevenue > 0
              ? parsedResult.detectedRevenue
              : undefined,
          detectedCurrency: parsedResult.detectedCurrency || 'лв.',
          detectedVenue: parsedResult.detectedVenue || undefined,
          detectedDate: parsedResult.detectedDate || undefined,
          matches: Array.isArray(parsedResult.matches) ? parsedResult.matches : [],
          discrepancies: Array.isArray(parsedResult.discrepancies) ? parsedResult.discrepancies : [],
          analyzedAt: Date.now(),
        },
      });
    } catch (err: any) {
      console.error('Gemini API Error in /api/analyze-report:', err);
      return res.status(500).json({
        error: 'Грешка при AI анализа на снимката',
        message: err?.message || 'Неуспешна комуникация с AI модела',
      });
    }
  });

  // Shared persistent store file on server with atomic write & auto-recovery backup
  const dataStoreDir = path.resolve(__dirname, 'data_store');
  const dataStoreFile = path.resolve(dataStoreDir, 'app_state.json');
  const dataStoreTmpFile = path.resolve(dataStoreDir, 'app_state.json.tmp');
  const dataStoreBackupFile = path.resolve(dataStoreDir, 'app_state_backup.json');

  if (!fs.existsSync(dataStoreDir)) {
    try {
      fs.mkdirSync(dataStoreDir, { recursive: true });
    } catch (e) {
      console.warn('Could not create data_store dir:', e);
    }
  }

  const defaultInitialState = {
    users: [
      {
        id: 'usr-boss-1',
        name: 'boss',
        pin: '1234',
        role: 'boss',
        phone: '',
        avatarColor: 'bg-amber-500 text-slate-950',
      },
    ],
    inventories: {
      'bar-hey': { venueId: 'bar-hey', charcoalsKg: 0, mouthpiecePacksCount: 0, lastUpdated: Date.now(), tobaccos: [] },
      'zero-zero': { venueId: 'zero-zero', charcoalsKg: 0, mouthpiecePacksCount: 0, lastUpdated: Date.now(), tobaccos: [] },
      'de-rouge': { venueId: 'de-rouge', charcoalsKg: 0, mouthpiecePacksCount: 0, lastUpdated: Date.now(), tobaccos: [] },
    },
    equipmentInventories: {
      'bar-hey': {
        venueId: 'bar-hey',
        hookahsCount: 0,
        vasesCount: 0,
        hosesCount: 0,
        hmsCount: 0,
        bowls: [
          { id: 'bowl-cosmo', name: 'CosmoBowl', count: 0 },
          { id: 'bowl-bengala', name: 'Bengala', count: 0 },
          { id: 'bowl-oblako', name: 'Oblako', count: 0 },
          { id: 'bowl-voskurimsya', name: 'Вускуримзя', count: 0 },
          { id: 'bowl-funnel-cosmo', name: 'funnel Cosmo', count: 0 },
        ],
        lastUpdated: Date.now(),
      },
      'zero-zero': {
        venueId: 'zero-zero',
        hookahsCount: 0,
        vasesCount: 0,
        hosesCount: 0,
        hmsCount: 0,
        bowls: [
          { id: 'bowl-cosmo', name: 'CosmoBowl', count: 0 },
          { id: 'bowl-bengala', name: 'Bengala', count: 0 },
          { id: 'bowl-oblako', name: 'Oblako', count: 0 },
          { id: 'bowl-voskurimsya', name: 'Вускуримзя', count: 0 },
          { id: 'bowl-funnel-cosmo', name: 'funnel Cosmo', count: 0 },
        ],
        lastUpdated: Date.now(),
      },
      'de-rouge': {
        venueId: 'de-rouge',
        hookahsCount: 0,
        vasesCount: 0,
        hosesCount: 0,
        hmsCount: 0,
        bowls: [
          { id: 'bowl-cosmo', name: 'CosmoBowl', count: 0 },
          { id: 'bowl-bengala', name: 'Bengala', count: 0 },
          { id: 'bowl-oblako', name: 'Oblako', count: 0 },
          { id: 'bowl-voskurimsya', name: 'Вускуримзя', count: 0 },
          { id: 'bowl-funnel-cosmo', name: 'funnel Cosmo', count: 0 },
        ],
        lastUpdated: Date.now(),
      },
    },
    venues: [
      {
        id: 'bar-hey',
        name: 'Бар хей',
        tagline: 'Парти бар & наргиле лаундж',
        shortCode: 'BH',
        isActive: true,
        themeColor: {
          bg: 'bg-amber-600',
          text: 'text-amber-700',
          border: 'border-amber-500',
          badgeBg: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
          badgeText: 'text-amber-400',
          accent: '#d97706',
          lightBg: 'bg-amber-950/20',
        },
      },
      {
        id: 'zero-zero',
        name: 'Зеро Зеро',
        tagline: 'Модерен шиша бар',
        shortCode: 'ZZ',
        isActive: true,
        themeColor: {
          bg: 'bg-emerald-600',
          text: 'text-emerald-700',
          border: 'border-emerald-500',
          badgeBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
          badgeText: 'text-emerald-400',
          accent: '#059669',
          lightBg: 'bg-emerald-950/20',
        },
      },
      {
        id: 'de-rouge',
        name: 'Бар Де Руж',
        tagline: 'Премиум наргиле атмосфера',
        shortCode: 'BDR',
        isActive: true,
        themeColor: {
          bg: 'bg-rose-700',
          text: 'text-rose-700',
          border: 'border-rose-500',
          badgeBg: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
          badgeText: 'text-rose-400',
          accent: '#be123c',
          lightBg: 'bg-rose-950/20',
        },
      },
    ],
    shifts: [],
    reports: [],
    revisions: [],
    pendingApprovals: [],
    clockIns: [],
    fines: [],
    tasks: [],
    pricing: {
      'bar-hey': { venueId: 'bar-hey', yellowPriceEur: 15, blackPriceEur: 18, officialPriceEur: 0 },
      'zero-zero': { venueId: 'zero-zero', yellowPriceEur: 15, blackPriceEur: 18, officialPriceEur: 0 },
      'de-rouge': { venueId: 'de-rouge', yellowPriceEur: 16, blackPriceEur: 20, officialPriceEur: 0 },
    },
    wageSettings: {
      baseWageEur: 23,
      hookahRateEur: 1,
      currency: '€',
      updatedAt: Date.now(),
    },
    customLogo: null,
    lastModified: Date.now(),
  };

  const sanitizeAndNormalizeState = (parsed: any) => {
    if (!parsed || typeof parsed !== 'object') return { ...defaultInitialState };
    const state = { ...defaultInitialState, ...parsed };

    if (!Array.isArray(state.users) || state.users.length === 0) {
      state.users = defaultInitialState.users;
    } else {
      // Guarantee at least one boss profile exists
      if (!state.users.some((u: any) => u.role === 'boss')) {
        state.users = [...defaultInitialState.users, ...state.users];
      }
    }

    if (!state.inventories || typeof state.inventories !== 'object') {
      state.inventories = defaultInitialState.inventories;
    }
    if (!state.equipmentInventories || typeof state.equipmentInventories !== 'object') {
      state.equipmentInventories = defaultInitialState.equipmentInventories;
    }
    if (!Array.isArray(state.venues) || state.venues.length === 0) state.venues = defaultInitialState.venues;
    if (!Array.isArray(state.shifts)) state.shifts = [];
    if (!Array.isArray(state.reports)) state.reports = [];
    if (!Array.isArray(state.revisions)) state.revisions = [];
    if (!Array.isArray(state.pendingApprovals)) state.pendingApprovals = [];
    if (!Array.isArray(state.clockIns)) state.clockIns = [];
    if (!Array.isArray(state.fines)) state.fines = [];
    if (!Array.isArray(state.tasks)) state.tasks = [];
    if (!state.pricing || typeof state.pricing !== 'object') state.pricing = defaultInitialState.pricing;
    if (!state.wageSettings || typeof state.wageSettings !== 'object') state.wageSettings = defaultInitialState.wageSettings;

    return state;
  };

  const loadInitialStateFromDisk = () => {
    if (fs.existsSync(dataStoreFile)) {
      try {
        const raw = fs.readFileSync(dataStoreFile, 'utf-8');
        if (raw && raw.trim().length > 0) {
          const parsed = JSON.parse(raw);
          return sanitizeAndNormalizeState(parsed);
        }
      } catch (err) {
        console.error('Error reading primary app_state.json:', err);
      }
    }

    if (fs.existsSync(dataStoreBackupFile)) {
      try {
        const raw = fs.readFileSync(dataStoreBackupFile, 'utf-8');
        if (raw && raw.trim().length > 0) {
          const parsed = JSON.parse(raw);
          console.warn('Recovered app state from backup file!');
          return sanitizeAndNormalizeState(parsed);
        }
      } catch (err) {
        console.error('Error reading backup app_state_backup.json:', err);
      }
    }

    return { ...defaultInitialState };
  };

  // In-Memory Single Source of Truth
  let inMemoryState = loadInitialStateFromDisk();

  let isWriting = false;
  let pendingWrite = false;

  const persistStateToDisk = (): boolean => {
    inMemoryState.lastModified = Date.now();

    if (isWriting) {
      pendingWrite = true;
      return true;
    }

    isWriting = true;
    try {
      if (!fs.existsSync(dataStoreDir)) {
        fs.mkdirSync(dataStoreDir, { recursive: true });
      }

      const json = JSON.stringify(inMemoryState, null, 2);
      // Atomic write: write to temp file then rename
      fs.writeFileSync(dataStoreTmpFile, json, 'utf-8');
      fs.renameSync(dataStoreTmpFile, dataStoreFile);

      // Periodically update backup file
      try {
        fs.writeFileSync(dataStoreBackupFile, json, 'utf-8');
      } catch {}

      return true;
    } catch (err) {
      console.error('Error in atomic write of app_state.json:', err);
      return false;
    } finally {
      isWriting = false;
      if (pendingWrite) {
        pendingWrite = false;
        persistStateToDisk();
      }
    }
  };

  // ==========================================
  // Web Push Notifications & Background Dispatcher
  // ==========================================
  const VAPID_FILE = path.resolve(__dirname, 'vapid-keys.json');
  let vapidKeys: { publicKey: string; privateKey: string };

  if (fs.existsSync(VAPID_FILE)) {
    try {
      vapidKeys = JSON.parse(fs.readFileSync(VAPID_FILE, 'utf-8'));
    } catch (e) {
      vapidKeys = webpush.generateVAPIDKeys();
      fs.writeFileSync(VAPID_FILE, JSON.stringify(vapidKeys, null, 2), 'utf-8');
    }
  } else {
    vapidKeys = webpush.generateVAPIDKeys();
    try {
      fs.writeFileSync(VAPID_FILE, JSON.stringify(vapidKeys, null, 2), 'utf-8');
    } catch (e) {
      console.error('Could not write vapid-keys.json:', e);
    }
  }

  try {
    webpush.setVapidDetails(
      'mailto:support@cargohookah.bg',
      vapidKeys.publicKey,
      vapidKeys.privateKey
    );
  } catch (err) {
    console.error('Error setting VAPID details:', err);
  }

  interface ServerPushSubscription {
    endpoint: string;
    keys: { auth: string; p256dh: string };
    userId: string;
    userName: string;
    userRole: string;
    deviceInfo?: string;
    createdAt: number;
    updatedAt: number;
  }

  const SUBSCRIPTIONS_FILE = path.resolve(__dirname, 'push_subscriptions.json');
  let pushSubscriptions: ServerPushSubscription[] = [];

  if (fs.existsSync(SUBSCRIPTIONS_FILE)) {
    try {
      const raw = fs.readFileSync(SUBSCRIPTIONS_FILE, 'utf-8');
      if (raw && raw.trim().length > 0) {
        pushSubscriptions = JSON.parse(raw);
      }
    } catch {
      pushSubscriptions = [];
    }
  }

  const persistPushSubscriptions = () => {
    try {
      fs.writeFileSync(SUBSCRIPTIONS_FILE, JSON.stringify(pushSubscriptions, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to persist push subscriptions:', e);
    }
  };

  const sendPushToSubscription = async (sub: ServerPushSubscription, payload: any) => {
    try {
      await webpush.sendNotification(
        { endpoint: sub.endpoint, keys: sub.keys },
        JSON.stringify(payload)
      );
      return true;
    } catch (err: any) {
      if (err.statusCode === 404 || err.statusCode === 410) {
        pushSubscriptions = pushSubscriptions.filter((s) => s.endpoint !== sub.endpoint);
        persistPushSubscriptions();
      } else {
        console.warn(`Could not send push notification to ${sub.userName}:`, err.message || err);
      }
      return false;
    }
  };

  const sendPushToUser = async (userId: string, payload: any) => {
    const userSubs = pushSubscriptions.filter((s) => s.userId === userId);
    if (userSubs.length === 0) return false;
    const results = await Promise.all(userSubs.map((s) => sendPushToSubscription(s, payload)));
    return results.some(Boolean);
  };

  const sendPushToRoles = async (roles: string[], payload: any) => {
    const roleSubs = pushSubscriptions.filter((s) => roles.includes(s.userRole));
    if (roleSubs.length === 0) return false;
    const results = await Promise.all(roleSubs.map((s) => sendPushToSubscription(s, payload)));
    return results.some(Boolean);
  };

  const notifyUserMultiChannel = async (userId: string, payload: any) => {
    await sendPushToUser(userId, payload);
  };

  const notifyRolesMultiChannel = async (roles: string[], payload: any) => {
    await sendPushToRoles(roles, payload);
  };

  // Background Shift Check Cron (Runs every 45 seconds to notify users even when app is closed)
  const sentShiftNotifications = new Set<string>();

  setInterval(async () => {
    try {
      const now = new Date();
      const year = now.getFullYear();
      const month = String(now.getMonth() + 1).padStart(2, '0');
      const day = String(now.getDate()).padStart(2, '0');
      const todayStr = `${year}-${month}-${day}`;

      const currentMinutes = now.getHours() * 60 + now.getMinutes();

      // Reset old tracking keys daily
      if (now.getHours() === 0 && now.getMinutes() === 0 && sentShiftNotifications.size > 200) {
        sentShiftNotifications.clear();
      }

      if (!Array.isArray(inMemoryState.shifts)) return;

      const todayShifts = inMemoryState.shifts.filter((s: any) => s.date === todayStr);

      for (const shift of todayShifts) {
        if (!shift.staffId || !shift.startTime) continue;
        const [startH, startM] = shift.startTime.split(':').map(Number);
        const shiftStartMinutes = startH * 60 + startM;
        const diffStart = shiftStartMinutes - currentMinutes;

        const venueObj = inMemoryState.venues?.find((v: any) => v.id === shift.venueId);
        const venueName = venueObj?.name || shift.venueId;

        // 1. Alert 1 hour before scheduled shift (55-65 mins before start)
        const key1h = `shift_1h_${shift.id}_${todayStr}`;
        if (diffStart >= 55 && diffStart <= 65 && !sentShiftNotifications.has(key1h)) {
          sentShiftNotifications.add(key1h);
          await notifyUserMultiChannel(shift.staffId, {
            title: `🔔 1 час до смяната в ${venueName}!`,
            body: `Здравей ${shift.staffName}, смяната ти започва в ${shift.startTime} ч.`,
            url: '/?tab=schedule',
            tag: key1h,
          });
        }

        // 2. Exact shift start prompt (0 to 15 mins after start) if not clocked in yet
        const keyStart = `shift_start_${shift.id}_${todayStr}`;
        if (diffStart <= 0 && diffStart >= -15 && !shift.clockInTimestamp && !sentShiftNotifications.has(keyStart)) {
          sentShiftNotifications.add(keyStart);
          await notifyUserMultiChannel(shift.staffId, {
            title: `⏰ Смяната ти в ${venueName} започна!`,
            body: `Натисни тук за чекиране (На работа съм).`,
            url: '/?tab=schedule',
            tag: keyStart,
          });
        }

        // 3. Shift end prompt (0 to 20 mins after end time)
        if (shift.endTime) {
          const [endH, endM] = shift.endTime.split(':').map(Number);
          let shiftEndMinutes = endH * 60 + endM;
          if (shiftEndMinutes < shiftStartMinutes) {
            shiftEndMinutes += 24 * 60; // Crosses midnight
          }
          let adjustedCurrentMinutes = currentMinutes;
          if (endH < startH && now.getHours() < startH) {
            adjustedCurrentMinutes += 24 * 60;
          }

          const diffEnd = adjustedCurrentMinutes - shiftEndMinutes;
          const keyEnd = `shift_end_${shift.id}_${todayStr}`;
          if (diffEnd >= 0 && diffEnd <= 20 && !sentShiftNotifications.has(keyEnd)) {
            sentShiftNotifications.add(keyEnd);
            await notifyUserMultiChannel(shift.staffId, {
              title: `📋 Край на смяната в ${venueName}!`,
              body: `Не забравяй да попълниш ревизията и да снимаш бандеролите преди финализиране на отчета.`,
              url: '/?tab=revision',
              tag: keyEnd,
            });
          }
        }
      }
    } catch (cronErr) {
      console.error('Error in background shift notification checker:', cronErr);
    }
  }, 45 * 1000);

  // Notify the assigned employee, or staff scheduled at the selected venue, about a new task.
  app.post('/api/tasks/notify', async (req: Request, res: Response) => {
    try {
      const task = req.body?.task;
      if (!task || typeof task.title !== 'string' || !task.title.trim()) {
        return res.status(400).json({ error: 'Невалидна задача' });
      }
      const actor = (inMemoryState.users || []).find((user: any) => user.id === task.createdById);
      if (!actor || !['boss', 'admin'].includes(actor.role)) {
        return res.status(403).json({ error: 'Само шеф или администратор може да възлага задачи' });
      }
      const payload = {
        title: 'Нова задача · Cargo Hookah',
        body: task.title + (task.dueAt ? ` · Срок: ${new Date(task.dueAt).toLocaleString('bg-BG')}` : ''),
        url: '/?tab=tasks',
        tag: `task-${task.id || Date.now()}`,
      };
      let notified = false;
      if (task.target === 'employee' && task.assigneeId) {
        notified = await sendPushToUser(String(task.assigneeId), payload);
      } else if (task.target === 'venue' && task.venueId) {
        const venueStaffIds = new Set<string>((inMemoryState.shifts || [])
          .filter((shift: any) => shift.venueId === task.venueId && shift.staffId)
          .map((shift: any) => String(shift.staffId)));
        const subs = pushSubscriptions.filter(sub => venueStaffIds.has(sub.userId));
        const results = await Promise.all(subs.map(sub => sendPushToSubscription(sub, payload)));
        notified = results.some(Boolean);
      }
      return res.json({ success: true, notified });
    } catch (err) {
      console.error('Task notification failed:', err);
      return res.status(500).json({ error: 'Неуспешно изпращане на известие за задача' });
    }
  });

  // GET VAPID public key
  app.get('/api/push/vapid-public-key', (_req: Request, res: Response) => {
    return res.json({ publicKey: vapidKeys.publicKey });
  });

  // POST save or update push subscription
  app.post('/api/push/subscribe', (req: Request, res: Response) => {
    try {
      const { subscription, userId, userName, userRole, deviceInfo } = req.body;
      if (!subscription || !subscription.endpoint || !subscription.keys) {
        return res.status(400).json({ error: 'Невалиден абонамент за известия' });
      }

      const existingIdx = pushSubscriptions.findIndex((s) => s.endpoint === subscription.endpoint);
      const subItem: ServerPushSubscription = {
        endpoint: subscription.endpoint,
        keys: subscription.keys,
        userId: userId || 'unknown',
        userName: userName || 'Колега',
        userRole: userRole || 'staff',
        deviceInfo: deviceInfo || '',
        createdAt: existingIdx >= 0 ? pushSubscriptions[existingIdx].createdAt : Date.now(),
        updatedAt: Date.now(),
      };

      if (existingIdx >= 0) {
        pushSubscriptions[existingIdx] = subItem;
      } else {
        pushSubscriptions.push(subItem);
      }

      persistPushSubscriptions();
      console.log(`Registered push subscription for ${subItem.userName} (${subItem.userRole})`);
      return res.json({ success: true, count: pushSubscriptions.length });
    } catch (err: any) {
      console.error('Error in POST /api/push/subscribe:', err);
      return res.status(500).json({ error: 'Грешка при запис на абонамент' });
    }
  });

  // POST unsubscribe
  app.post('/api/push/unsubscribe', (req: Request, res: Response) => {
    try {
      const { endpoint } = req.body;
      if (endpoint) {
        pushSubscriptions = pushSubscriptions.filter((s) => s.endpoint !== endpoint);
        persistPushSubscriptions();
      }
      return res.json({ success: true });
    } catch (err: any) {
      return res.status(500).json({ error: 'Грешка при отписване' });
    }
  });

  // POST trigger test push notification directly to user's phone
  app.post('/api/push/test', async (req: Request, res: Response) => {
    try {
      const { userId, userName } = req.body;
      if (!userId) {
        return res.status(400).json({ error: 'Липсва userId' });
      }

      const sent = await sendPushToUser(userId, {
        title: '🔥 Cargo Hookah: Тестово известие',
        body: `Здравей, ${userName || 'колега'}! Телефонните известия работят перфектно, дори когато приложението е напълно затворено.`,
        url: '/?tab=schedule',
        tag: 'cargo-test-' + Date.now(),
      });

      return res.json({ 
        success: true, 
        delivered: sent,
        message: sent 
          ? 'Тестовото известие беше изпратено директно към телефона ви!' 
          : 'Абонаментът е активиран успешно!'
      });
    } catch (err: any) {
      console.error('Error in POST /api/push/test:', err);
      return res.status(500).json({ error: 'Грешка при изпращане на тестово известие' });
    }
  });

  // POST /api/slack-webhook: Dispatches shift end report to Slack Webhook
  app.post('/api/slack-webhook', async (req: Request, res: Response) => {
    try {
      const { webhookUrl, payload } = req.body;
      const targetUrl = webhookUrl || process.env.SLACK_WEBHOOK_URL || inMemoryState.settings?.slackWebhookUrl;

      if (!targetUrl) {
        console.log('Slack webhook delivered (simulated, no URL configured):', JSON.stringify(payload));
        return res.json({ success: true, simulated: true });
      }

      const slackRes = await fetch(targetUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      return res.json({ success: slackRes.ok });
    } catch (err: any) {
      console.error('Error forwarding to Slack webhook:', err);
      return res.status(500).json({ error: err.message || 'Slack webhook error' });
    }
  });

  // GET shared app state (Instant in-memory read, multi-device cross-IP sync)
  app.get('/api/state', (_req: Request, res: Response) => {
    return res.json({ success: true, state: inMemoryState });
  });

  // GET logo endpoint
  app.get('/api/logo', (_req: Request, res: Response) => {
    return res.json({ success: true, customLogo: inMemoryState.customLogo || null });
  });

  // POST logo endpoint - BOSS ONLY
  app.post('/api/logo', requireBossRole, async (req: Request, res: Response) => {
    try {
      const { logoDataUrl } = req.body;
      if (!logoDataUrl || typeof logoDataUrl !== 'string') {
        return res.status(400).json({ error: 'Липсват данни за каченото лого' });
      }

      inMemoryState.customLogo = logoDataUrl;
      persistStateToDisk();

      // Extract raw buffer
      const commaIdx = logoDataUrl.indexOf(',');
      let base64Data = logoDataUrl;
      let mimeType = 'image/png';
      if (commaIdx !== -1) {
        const meta = logoDataUrl.slice(0, commaIdx);
        base64Data = logoDataUrl.slice(commaIdx + 1);
        const match = meta.match(/data:([^;]+)/);
        if (match) mimeType = match[1];
      }

      const fileBuffer = Buffer.from(base64Data, 'base64');
      const publicDir = path.resolve(__dirname, 'public');
      const assetsDir = path.resolve(__dirname, 'src/assets');

      if (mimeType.includes('svg')) {
        fs.writeFileSync(path.join(publicDir, 'cargo-hookah-logo.svg'), fileBuffer);
        fs.writeFileSync(path.join(publicDir, 'icon.svg'), fileBuffer);
        fs.writeFileSync(path.join(assetsDir, 'cargo-hookah-logo.svg'), fileBuffer);
      }

      try {
        const sharpModule = await import('sharp');
        const sharp = sharpModule.default;
        await sharp(fileBuffer).resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toFile(path.join(publicDir, 'pwa-512x512.png'));
        await sharp(fileBuffer).resize(512, 512, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toFile(path.join(assetsDir, 'cargo-hookah-logo.png'));
        await sharp(fileBuffer).resize(192, 192, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toFile(path.join(publicDir, 'pwa-192x192.png'));
        await sharp(fileBuffer).resize(180, 180, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toFile(path.join(publicDir, 'apple-touch-icon.png'));
        await sharp(fileBuffer).resize(64, 64, { fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toFile(path.join(publicDir, 'favicon.png'));
      } catch (sharpErr) {
        console.warn('Sharp resize fallback:', sharpErr);
        fs.writeFileSync(path.join(publicDir, 'cargo-hookah-logo.png'), fileBuffer);
        fs.writeFileSync(path.join(assetsDir, 'cargo-hookah-logo.png'), fileBuffer);
      }

      return res.json({ success: true, customLogo: logoDataUrl });
    } catch (err: any) {
      console.error('Error saving logo in /api/logo:', err);
      return res.status(500).json({ error: 'Грешка при запис на логото' });
    }
  });

  // GET wage settings
  app.get('/api/wage-settings', (_req: Request, res: Response) => {
    return res.json({ success: true, wageSettings: inMemoryState.wageSettings || defaultInitialState.wageSettings });
  });

  // POST update wage settings - BOSS ONLY
  app.post('/api/wage-settings', requireBossRole, (req: Request, res: Response) => {
    try {
      const { baseWageEur, hookahRateEur, currency, updatedBy, users: incomingUsers } = req.body;
      const newBase = typeof baseWageEur === 'number' && baseWageEur >= 0 ? baseWageEur : (Number(baseWageEur) >= 0 ? Number(baseWageEur) : 23);
      const newRate = typeof hookahRateEur === 'number' && hookahRateEur >= 0 ? hookahRateEur : (Number(hookahRateEur) >= 0 ? Number(hookahRateEur) : 1);
      const newCurrency = currency === 'лв.' ? 'лв.' : '€';

      inMemoryState.wageSettings = {
        baseWageEur: newBase,
        hookahRateEur: newRate,
        currency: newCurrency,
        updatedAt: Date.now(),
        updatedBy: sanitizeString(updatedBy || 'boss'),
      };

      // Also update personalized employee rates atomically if provided
      if (Array.isArray(incomingUsers)) {
        incomingUsers.forEach((u: any) => {
          if (!u || !u.id) return;
          const idx = inMemoryState.users.findIndex((ex: any) => ex.id === u.id);
          if (idx >= 0) {
            inMemoryState.users[idx] = {
              ...inMemoryState.users[idx],
              customBaseWageEur: typeof u.customBaseWageEur === 'number' && u.customBaseWageEur >= 0 ? u.customBaseWageEur : undefined,
              customHookahRateEur: typeof u.customHookahRateEur === 'number' && u.customHookahRateEur >= 0 ? u.customHookahRateEur : undefined,
            };
          }
        });
      }

      persistStateToDisk();
      return res.json({ success: true, wageSettings: inMemoryState.wageSettings, users: inMemoryState.users });
    } catch (err: any) {
      console.error('Error in /api/wage-settings:', err);
      return res.status(500).json({ error: 'Грешка при запис на ставките' });
    }
  });

  // POST update pricing - BOSS ONLY
  app.post('/api/pricing', requireBossRole, (req: Request, res: Response) => {
    try {
      const pricing = req.body?.pricing;
      if (!pricing || typeof pricing !== 'object') {
        return res.status(400).json({ error: 'Невалидни данни за цени' });
      }

      inMemoryState.pricing = { ...inMemoryState.pricing, ...pricing };
      persistStateToDisk();
      return res.json({ success: true, pricing: inMemoryState.pricing });
    } catch (err: any) {
      console.error('Error in /api/pricing:', err);
      return res.status(500).json({ error: 'Грешка при запис на цени' });
    }
  });

  // GET all users
  app.get('/api/users', (_req: Request, res: Response) => {
    return res.json({ success: true, users: inMemoryState.users });
  });

  // POST add or update a user - BOSS ONLY (CYBERSECURITY: Employees CANNOT add/edit users!)
  app.post('/api/users', requireBossRole, (req: Request, res: Response) => {
    try {
      const user = req.body?.user;
      if (!user || !user.name || !user.pin) {
        return res.status(400).json({ error: 'Невалидни данни за потребител. Име и PIN код са задължителни.' });
      }

      const cleanUser = {
        id: user.id || `usr-${Date.now().toString(36)}`,
        name: sanitizeString(user.name, 100),
        pin: String(user.pin).trim(),
        role: user.role === 'boss' ? 'boss' : 'employee',
        phone: user.phone ? sanitizeString(user.phone, 30) : undefined,
        avatarColor: user.avatarColor || 'bg-amber-500 text-slate-950',
        customBaseWageEur: typeof user.customBaseWageEur === 'number' && user.customBaseWageEur >= 0 ? user.customBaseWageEur : undefined,
        customHookahRateEur: typeof user.customHookahRateEur === 'number' && user.customHookahRateEur >= 0 ? user.customHookahRateEur : undefined,
        permissions: user.permissions && typeof user.permissions === 'object' ? user.permissions : undefined,
      };

      const existingIndex = inMemoryState.users.findIndex(
        (u: any) => u.id === cleanUser.id || u.name.toLowerCase() === cleanUser.name.toLowerCase()
      );

      if (existingIndex >= 0) {
        inMemoryState.users[existingIndex] = { ...inMemoryState.users[existingIndex], ...cleanUser };
      } else {
        inMemoryState.users.push(cleanUser);
      }

      persistStateToDisk();
      return res.json({ success: true, user: cleanUser, users: inMemoryState.users });
    } catch (err: any) {
      console.error('Error in /api/users:', err);
      return res.status(500).json({ error: 'Грешка при запис на потребител' });
    }
  });

  // DELETE user - BOSS ONLY
  app.delete('/api/users/:id', requireBossRole, (req: Request, res: Response) => {
    try {
      const userId = req.params.id;

      // Don't delete if it's the only boss
      const targetUser = inMemoryState.users.find((u: any) => u.id === userId);
      if (targetUser?.role === 'boss') {
        const bossCount = inMemoryState.users.filter((u: any) => u.role === 'boss').length;
        if (bossCount <= 1) {
          return res.status(400).json({ error: 'Не можете да изтриете последния шефски профил' });
        }
      }

      inMemoryState.users = inMemoryState.users.filter((u: any) => u.id !== userId);
      persistStateToDisk();
      return res.json({ success: true, users: inMemoryState.users });
    } catch (err: any) {
      console.error('Error in DELETE /api/users/:id:', err);
      return res.status(500).json({ error: 'Грешка при изтриване на потребител' });
    }
  });

  // POST venue inventory update (tobacco, charcoal, mouthpieces)
  app.post('/api/inventory/:venueId', (req: Request, res: Response) => {
    try {
      const venueId = req.params.venueId;
      const inventory = req.body?.inventory;
      if (!inventory || typeof inventory !== 'object') {
        return res.status(400).json({ error: 'Невалидни инвентарни данни' });
      }

      const current = inMemoryState.inventories[venueId] || { venueId, charcoalsKg: 0, mouthpiecePacksCount: 0, tobaccos: [] };
      inMemoryState.inventories[venueId] = {
        ...current,
        ...inventory,
        venueId,
        lastUpdated: Date.now(),
      };

      persistStateToDisk();
      return res.json({ success: true, inventory: inMemoryState.inventories[venueId] });
    } catch (err: any) {
      console.error('Error in POST /api/inventory/:venueId:', err);
      return res.status(500).json({ error: 'Грешка при запис на инвентар' });
    }
  });

  // POST venue equipment update (hookahs, vases, hoses, bowls, HMS)
  app.post('/api/equipment/:venueId', (req: Request, res: Response) => {
    try {
      const venueId = req.params.venueId;
      const equipment = req.body?.equipment;
      if (!equipment || typeof equipment !== 'object') {
        return res.status(400).json({ error: 'Невалидни данни за оборудване' });
      }

      const current = inMemoryState.equipmentInventories[venueId] || { venueId, hookahsCount: 0, vasesCount: 0, hosesCount: 0, hmsCount: 0, bowls: [] };
      inMemoryState.equipmentInventories[venueId] = {
        ...current,
        ...equipment,
        venueId,
        lastUpdated: Date.now(),
      };

      persistStateToDisk();
      return res.json({ success: true, equipment: inMemoryState.equipmentInventories[venueId] });
    } catch (err: any) {
      console.error('Error in POST /api/equipment/:venueId:', err);
      return res.status(500).json({ error: 'Грешка при запис на оборудване' });
    }
  });

  // POST add or update shift in schedule
  app.post('/api/shifts', (req: Request, res: Response) => {
    try {
      const shift = req.body?.shift;
      if (!shift || !shift.date || !shift.venueId || !shift.staffId) {
        return res.status(400).json({ error: 'Невалидни данни за смяна' });
      }

      const cleanShift = {
        ...shift,
        id: shift.id || `sh-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
        staffName: sanitizeString(shift.staffName || '', 100),
        notes: shift.notes ? sanitizeString(shift.notes, 300) : undefined,
        createdAt: shift.createdAt || Date.now(),
      };

      const existingIndex = inMemoryState.shifts.findIndex((s: any) => s.id === cleanShift.id);
      if (existingIndex >= 0) {
        inMemoryState.shifts[existingIndex] = cleanShift;
      } else {
        inMemoryState.shifts.push(cleanShift);
      }

      persistStateToDisk();
      return res.json({ success: true, shift: cleanShift, shifts: inMemoryState.shifts });
    } catch (err: any) {
      console.error('Error in POST /api/shifts:', err);
      return res.status(500).json({ error: 'Грешка при запис на смяна' });
    }
  });

  // DELETE shift
  app.delete('/api/shifts/:id', (req: Request, res: Response) => {
    try {
      const shiftId = req.params.id;
      inMemoryState.shifts = inMemoryState.shifts.filter((s: any) => s.id !== shiftId);
      persistStateToDisk();
      return res.json({ success: true, shifts: inMemoryState.shifts });
    } catch (err: any) {
      console.error('Error in DELETE /api/shifts/:id:', err);
      return res.status(500).json({ error: 'Грешка при изтриване на смяна' });
    }
  });

  // POST add or update shift report
  app.post('/api/reports', (req: Request, res: Response) => {
    try {
      const report = req.body?.report;
      if (!report || !report.venueId || !report.staffId || !report.date) {
        return res.status(400).json({ error: 'Невалидни данни за отчет' });
      }

      const cleanReport = {
        ...report,
        id: report.id || `rep-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
        staffName: sanitizeString(report.staffName || '', 100),
        notes: report.notes ? sanitizeString(report.notes, 500) : undefined,
        createdAt: report.createdAt || Date.now(),
      };

      const existingIndex = inMemoryState.reports.findIndex((r: any) => r.id === cleanReport.id);
      if (existingIndex >= 0) {
        inMemoryState.reports[existingIndex] = cleanReport;
      } else {
        inMemoryState.reports.unshift(cleanReport);
      }

      // Deduct charcoals automatically if new report
      if (existingIndex < 0 && cleanReport.totalHookahs > 0) {
        const inv = inMemoryState.inventories[cleanReport.venueId];
        if (inv) {
          const charcoalsUsed = Number((cleanReport.totalHookahs * 0.06).toFixed(2));
          inv.charcoalsKg = Math.max(0, Number((inv.charcoalsKg - charcoalsUsed).toFixed(1)));
          inv.lastUpdated = Date.now();
        }
      }

      persistStateToDisk();
      return res.json({ success: true, report: cleanReport, reports: inMemoryState.reports, inventories: inMemoryState.inventories });
    } catch (err: any) {
      console.error('Error in POST /api/reports:', err);
      return res.status(500).json({ error: 'Грешка при запис на отчет' });
    }
  });

  // DELETE report
  app.delete('/api/reports/:id', (req: Request, res: Response) => {
    try {
      const reportId = req.params.id;
      inMemoryState.reports = inMemoryState.reports.filter((r: any) => r.id !== reportId);
      persistStateToDisk();
      return res.json({ success: true, reports: inMemoryState.reports });
    } catch (err: any) {
      console.error('Error in DELETE /api/reports/:id:', err);
      return res.status(500).json({ error: 'Грешка при изтриване на отчет' });
    }
  });

  // GET all employee fines
  app.get('/api/fines', (_req: Request, res: Response) => {
    return res.json({ success: true, fines: inMemoryState.fines || [] });
  });

  // POST add or update fine
  app.post('/api/fines', (req: Request, res: Response) => {
    try {
      const fine = req.body?.fine;
      if (!fine || !fine.staffId || typeof fine.amountEur !== 'number') {
        return res.status(400).json({ error: 'Невалидни данни за глоба' });
      }

      const cleanFine = {
        ...fine,
        id: fine.id || `fine-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
        staffName: sanitizeString(fine.staffName || '', 100),
        reason: sanitizeString(fine.reason || '', 300),
        createdAt: fine.createdAt || Date.now(),
      };

      const existingIndex = inMemoryState.fines.findIndex((f: any) => f.id === cleanFine.id);
      if (existingIndex >= 0) {
        inMemoryState.fines[existingIndex] = cleanFine;
      } else {
        inMemoryState.fines.unshift(cleanFine);
      }

      persistStateToDisk();
      return res.json({ success: true, fine: cleanFine, fines: inMemoryState.fines });
    } catch (err: any) {
      console.error('Error in POST /api/fines:', err);
      return res.status(500).json({ error: 'Грешка при запис на глоба' });
    }
  });

  // DELETE fine
  app.delete('/api/fines/:id', (req: Request, res: Response) => {
    try {
      const fineId = req.params.id;
      inMemoryState.fines = inMemoryState.fines.filter((f: any) => f.id !== fineId);
      persistStateToDisk();
      return res.json({ success: true, fines: inMemoryState.fines || [] });
    } catch (err: any) {
      console.error('Error in DELETE /api/fines/:id:', err);
      return res.status(500).json({ error: 'Грешка при изтриване на глоба' });
    }
  });

  // POST add or update venues (Admin / Boss only)
  app.post('/api/venues', (req: Request, res: Response) => {
    try {
      const venues = req.body?.venues;
      if (!Array.isArray(venues) || venues.length === 0) {
        return res.status(400).json({ error: 'Невалиден списък заведения' });
      }
      inMemoryState.venues = venues;
      persistStateToDisk();
      return res.json({ success: true, venues: inMemoryState.venues });
    } catch (err: any) {
      console.error('Error in POST /api/venues:', err);
      return res.status(500).json({ error: 'Грешка при запис на заведения' });
    }
  });

  // POST create pending breakage/loss approval request
  app.post('/api/pending-approvals', (req: Request, res: Response) => {
    try {
      const approval = req.body?.approval;
      if (!approval || !approval.venueId || !approval.staffId || !approval.reason) {
        return res.status(400).json({ error: 'Невалидна заявка за брак' });
      }
      const cleanApproval = {
        ...approval,
        id: approval.id || `appr-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
        status: approval.status || 'pending',
        createdAt: approval.createdAt || Date.now(),
      };
      if (!Array.isArray(inMemoryState.pendingApprovals)) inMemoryState.pendingApprovals = [];
      const idx = inMemoryState.pendingApprovals.findIndex((a: any) => a.id === cleanApproval.id);
      if (idx >= 0) {
        inMemoryState.pendingApprovals[idx] = cleanApproval;
      } else {
        inMemoryState.pendingApprovals.unshift(cleanApproval);
      }
      persistStateToDisk();

      // Send real-time multi-channel notification to all Bosses & Admins (Phone Push + Telegram)
      const venueObj = inMemoryState.venues?.find((v: any) => v.id === cleanApproval.venueId);
      const venueName = venueObj?.name || cleanApproval.venueId;
      notifyRolesMultiChannel(['boss', 'admin'], {
        title: `⚠️ Заявка за брак: ${cleanApproval.itemName}`,
        body: `${cleanApproval.staffName} заяви отписване на ${cleanApproval.quantityReduced} бр. в ${venueName} (Причина: ${cleanApproval.reason}).`,
        url: '/?tab=equipment',
        tag: `approval-${cleanApproval.id}`,
      }).catch((e) => console.warn('Push alert error for approval:', e));

      return res.json({ success: true, approval: cleanApproval, pendingApprovals: inMemoryState.pendingApprovals });
    } catch (err: any) {
      console.error('Error in POST /api/pending-approvals:', err);
      return res.status(500).json({ error: 'Грешка при запис на заявка за брак' });
    }
  });

  // PATCH review pending approval (approve or reject by admin)
  app.patch('/api/pending-approvals/:id', (req: Request, res: Response) => {
    try {
      const approvalId = req.params.id;
      const { status, reviewedBy, reviewNote } = req.body;
      if (!['approved', 'rejected'].includes(status)) {
        return res.status(400).json({ error: 'Невалиден статус за преглед' });
      }
      if (!Array.isArray(inMemoryState.pendingApprovals)) inMemoryState.pendingApprovals = [];
      const item = inMemoryState.pendingApprovals.find((a: any) => a.id === approvalId);
      if (!item) {
        return res.status(404).json({ error: 'Заявката не е намерена' });
      }

      item.status = status;
      item.reviewedBy = reviewedBy || 'Admin';
      item.reviewedAt = Date.now();
      if (reviewNote) item.reviewNote = reviewNote;

      // If approved, update main equipment inventory count
      if (status === 'approved' && item.category === 'equipment') {
        const eqInv = inMemoryState.equipmentInventories?.[item.venueId];
        if (eqInv) {
          if (item.itemId.startsWith('bowl-')) {
            const bId = item.itemId.replace('bowl-', '');
            eqInv.bowls = (eqInv.bowls || []).map((b: any) =>
              b.id === bId ? { ...b, count: Math.max(0, item.requestedCount) } : b
            );
          } else if (['hookahsCount', 'vasesCount', 'hosesCount', 'hmsCount'].includes(item.itemId)) {
            eqInv[item.itemId] = Math.max(0, item.requestedCount);
          }
          eqInv.lastUpdated = Date.now();
        }
      }

      persistStateToDisk();

      // Send multi-channel notification back to the employee who submitted the request
      const statusText = status === 'approved' ? 'одобрена ✅' : 'отхвърлена ❌';
      notifyUserMultiChannel(item.staffId, {
        title: status === 'approved' ? `✅ Одобрен брак: ${item.itemName}` : `❌ Отхвърлен брак: ${item.itemName}`,
        body: `Заявката ви за ${item.itemName} беше ${statusText} от ${reviewedBy || 'шефа'}.${reviewNote ? ` Бележка: ${reviewNote}` : ''}`,
        url: '/?tab=equipment',
        tag: `review-${item.id}`,
      }).catch((e) => console.warn('Push alert error for review:', e));

      return res.json({ 
        success: true, 
        approval: item, 
        pendingApprovals: inMemoryState.pendingApprovals,
        equipmentInventories: inMemoryState.equipmentInventories 
      });
    } catch (err: any) {
      console.error('Error in PATCH /api/pending-approvals/:id:', err);
      return res.status(500).json({ error: 'Грешка при преглед на заявка' });
    }
  });

  // POST save daily revision
  app.post('/api/revisions', (req: Request, res: Response) => {
    try {
      const revision = req.body?.revision;
      if (!revision || !revision.venueId || !revision.date) {
        return res.status(400).json({ error: 'Невалидна ревизия' });
      }
      const cleanRev = {
        ...revision,
        id: revision.id || `rev-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
        createdAt: revision.createdAt || Date.now(),
      };
      if (!Array.isArray(inMemoryState.revisions)) inMemoryState.revisions = [];
      const idx = inMemoryState.revisions.findIndex((r: any) => r.id === cleanRev.id);
      if (idx >= 0) {
        inMemoryState.revisions[idx] = cleanRev;
      } else {
        inMemoryState.revisions.unshift(cleanRev);
      }
      persistStateToDisk();
      return res.json({ success: true, revision: cleanRev, revisions: inMemoryState.revisions });
    } catch (err: any) {
      console.error('Error in POST /api/revisions:', err);
      return res.status(500).json({ error: 'Грешка при запис на ревизия' });
    }
  });

  // POST save clock-in record
  app.post('/api/clock-ins', (req: Request, res: Response) => {
    try {
      const clockIn = req.body?.clockIn;
      if (!clockIn || !clockIn.shiftId || !clockIn.staffId) {
        return res.status(400).json({ error: 'Невалиден запис за присъствие' });
      }
      const cleanClockIn = {
        ...clockIn,
        id: clockIn.id || `clock-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
        createdAt: clockIn.createdAt || Date.now(),
      };
      if (!Array.isArray(inMemoryState.clockIns)) inMemoryState.clockIns = [];
      inMemoryState.clockIns.unshift(cleanClockIn);

      // Also stamp the shift in shifts
      if (Array.isArray(inMemoryState.shifts)) {
        const sh = inMemoryState.shifts.find((s: any) => s.id === cleanClockIn.shiftId);
        if (sh) {
          sh.clockInTimestamp = cleanClockIn.clockInTimestamp;
          sh.clockInTimeString = cleanClockIn.clockInTimeString;
        }
      }

      persistStateToDisk();
      return res.json({ success: true, clockIn: cleanClockIn, clockIns: inMemoryState.clockIns, shifts: inMemoryState.shifts });
    } catch (err: any) {
      console.error('Error in POST /api/clock-ins:', err);
      return res.status(500).json({ error: 'Грешка при запис на присъствие' });
    }
  });

  // POST /api/sync: Intelligently merge client state with authoritative server state
  // Cybersecurity: Only Boss role can modify users, wageSettings, or pricing in sync!
  app.post('/api/sync', (req: Request, res: Response) => {
    try {
      const client = req.body || {};
      const isBoss = (req.headers['x-user-role'] || client.requesterRole) === 'boss';

      // 1. Users: ONLY boss can sync user additions/modifications!
      if (isBoss && Array.isArray(client.users) && client.users.length > 0) {
        const userMap = new Map<string, any>();
        inMemoryState.users.forEach((u: any) => userMap.set(u.id, u));
        client.users.forEach((u: any) => {
          if (u && u.id && u.name) {
            userMap.set(u.id, { ...(userMap.get(u.id) || {}), ...u });
          }
        });
        inMemoryState.users = Array.from(userMap.values());
      }

      // 2. Wage Settings: ONLY boss
      if (isBoss && client.wageSettings && typeof client.wageSettings === 'object') {
        const clientUpdated = client.wageSettings.updatedAt || 0;
        const serverUpdated = inMemoryState.wageSettings?.updatedAt || 0;
        if (clientUpdated >= serverUpdated) {
          inMemoryState.wageSettings = client.wageSettings;
        }
      }

      // 3. Pricing: ONLY boss
      if (isBoss && client.pricing && typeof client.pricing === 'object') {
        inMemoryState.pricing = { ...inMemoryState.pricing, ...client.pricing };
      }

      // 4. Shifts: merge all shifts by ID
      if (Array.isArray(client.shifts)) {
        const shiftMap = new Map<string, any>();
        inMemoryState.shifts.forEach((s: any) => shiftMap.set(s.id, s));
        client.shifts.forEach((s: any) => {
          if (s && s.id) shiftMap.set(s.id, s);
        });
        inMemoryState.shifts = Array.from(shiftMap.values());
      }

      // 5. Reports: merge all reports by ID
      if (Array.isArray(client.reports)) {
        const reportMap = new Map<string, any>();
        inMemoryState.reports.forEach((r: any) => reportMap.set(r.id, r));
        client.reports.forEach((r: any) => {
          if (r && r.id) reportMap.set(r.id, r);
        });
        inMemoryState.reports = Array.from(reportMap.values());
      }

      // 6. Inventories: latest timestamp wins
      if (client.inventories && typeof client.inventories === 'object') {
        Object.keys(client.inventories).forEach((vId) => {
          const clientInv = client.inventories[vId];
          const serverInv = inMemoryState.inventories?.[vId];
          if (!serverInv || (clientInv?.lastUpdated && clientInv.lastUpdated >= (serverInv.lastUpdated || 0))) {
            inMemoryState.inventories[vId] = clientInv;
          }
        });
      }

      // 7. Equipment inventories: latest timestamp wins
      if (client.equipmentInventories && typeof client.equipmentInventories === 'object') {
        Object.keys(client.equipmentInventories).forEach((vId) => {
          const clientEq = client.equipmentInventories[vId];
          const serverEq = inMemoryState.equipmentInventories?.[vId];
          if (!serverEq || (clientEq?.lastUpdated && clientEq.lastUpdated >= (serverEq.lastUpdated || 0))) {
            inMemoryState.equipmentInventories[vId] = clientEq;
          }
        });
      }

      // 8. Fines
      if (Array.isArray(client.fines)) {
        const fineMap = new Map<string, any>();
        inMemoryState.fines.forEach((f: any) => fineMap.set(f.id, f));
        client.fines.forEach((f: any) => {
          if (f && f.id) fineMap.set(f.id, f);
        });
        inMemoryState.fines = Array.from(fineMap.values());
      }

      // 9. Venues (Admin / Boss)
      if (Array.isArray(client.venues) && client.venues.length > 0) {
        inMemoryState.venues = client.venues;
      }

      // 10. Revisions
      if (Array.isArray(client.revisions)) {
        const revMap = new Map<string, any>();
        (inMemoryState.revisions || []).forEach((r: any) => revMap.set(r.id, r));
        client.revisions.forEach((r: any) => {
          if (r && r.id) revMap.set(r.id, r);
        });
        inMemoryState.revisions = Array.from(revMap.values());
      }

      // 11. Pending Approvals
      if (Array.isArray(client.pendingApprovals)) {
        const appMap = new Map<string, any>();
        (inMemoryState.pendingApprovals || []).forEach((a: any) => appMap.set(a.id, a));
        client.pendingApprovals.forEach((a: any) => {
          if (a && a.id) appMap.set(a.id, a);
        });
        inMemoryState.pendingApprovals = Array.from(appMap.values());
      }

      // 12. Tasks: merge by ID and preserve the newest task version.
      if (Array.isArray(client.tasks)) {
        const taskMap = new Map<string, any>();
        (inMemoryState.tasks || []).forEach((task: any) => taskMap.set(task.id, task));
        client.tasks.forEach((task: any) => {
          if (!task || !task.id) return;
          const previous = taskMap.get(task.id);
          if (!previous || (task.updatedAt || task.createdAt || 0) >= (previous.updatedAt || previous.createdAt || 0)) {
            taskMap.set(task.id, task);
          }
        });
        inMemoryState.tasks = Array.from(taskMap.values());
      }

      // 13. Clock-ins
      if (Array.isArray(client.clockIns)) {
        const clockMap = new Map<string, any>();
        (inMemoryState.clockIns || []).forEach((c: any) => clockMap.set(c.id, c));
        client.clockIns.forEach((c: any) => {
          if (c && c.id) clockMap.set(c.id, c);
        });
        inMemoryState.clockIns = Array.from(clockMap.values());
      }

      persistStateToDisk();
      return res.json({ success: true, state: inMemoryState });
    } catch (err: any) {
      console.error('Error in /api/sync:', err);
      return res.status(500).json({ error: 'Failed to sync state' });
    }
  });

  // POST /api/state: backwards compatibility with smart merge
  app.post('/api/state', (req: Request, res: Response) => {
    try {
      const incoming = req.body;
      if (!incoming || typeof incoming !== 'object') {
        return res.status(400).json({ error: 'Invalid state' });
      }

      const isBoss = (req.headers['x-user-role'] || incoming.requesterRole) === 'boss';

      if (isBoss && Array.isArray(incoming.users)) {
        const userMap = new Map<string, any>();
        inMemoryState.users.forEach((u: any) => userMap.set(u.id, u));
        incoming.users.forEach((u: any) => {
          if (u && u.id) userMap.set(u.id, u);
        });
        inMemoryState.users = Array.from(userMap.values());
      }

      if (Array.isArray(incoming.shifts)) inMemoryState.shifts = incoming.shifts;
      if (Array.isArray(incoming.reports)) inMemoryState.reports = incoming.reports;
      const isTaskManager = ['boss', 'admin'].includes(String(req.headers['x-user-role'] || incoming.requesterRole || ''));
      if (Array.isArray(incoming.tasks)) {
        if (isTaskManager) {
          inMemoryState.tasks = incoming.tasks.filter((task: any) => task && task.id);
        } else {
          const taskMap = new Map<string, any>();
          (inMemoryState.tasks || []).forEach((task: any) => taskMap.set(task.id, task));
          incoming.tasks.forEach((task: any) => {
            if (!task?.id) return;
            const previous = taskMap.get(task.id);
            if (!previous || (task.updatedAt || task.createdAt || 0) >= (previous.updatedAt || previous.createdAt || 0)) taskMap.set(task.id, task);
          });
          inMemoryState.tasks = Array.from(taskMap.values());
        }
      }
      if (Array.isArray(incoming.venues) && incoming.venues.length > 0) inMemoryState.venues = incoming.venues;
      if (incoming.inventories) inMemoryState.inventories = { ...inMemoryState.inventories, ...incoming.inventories };
      if (incoming.equipmentInventories) inMemoryState.equipmentInventories = { ...inMemoryState.equipmentInventories, ...incoming.equipmentInventories };
      if (isBoss && incoming.pricing) inMemoryState.pricing = incoming.pricing;
      if (isBoss && incoming.customLogo) inMemoryState.customLogo = incoming.customLogo;

      persistStateToDisk();
      return res.json({ success: true, state: inMemoryState });
    } catch (err: any) {
      console.error('Error in POST /api/state:', err);
      return res.status(500).json({ error: 'Failed to save state' });
    }
  });

  // POST reset state completely to blank - resets all data entered
  app.post('/api/reset', (_req: Request, res: Response) => {
    try {
      inMemoryState = JSON.parse(JSON.stringify(defaultInitialState));
      inMemoryState.lastModified = Date.now();
      persistStateToDisk();
      return res.json({ success: true, state: inMemoryState });
    } catch (err: any) {
      console.error('Error in POST /api/reset:', err);
      return res.status(500).json({ error: 'Failed to reset state' });
    }
  });

  // Health check endpoint
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', serverTime: new Date().toISOString() });
  });

  // Vite integration: middleware in development, static files in production
  const isProduction = process.env.NODE_ENV === 'production';
  const distPath = path.resolve(__dirname, 'dist');
  const distIndexHtml = path.resolve(distPath, 'index.html');

  if (isProduction) {
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
    }
    app.get('*', (_req, res) => {
      if (fs.existsSync(distIndexHtml)) {
        res.sendFile(distIndexHtml);
      } else {
        const rootHtml = path.resolve(__dirname, 'index.html');
        if (fs.existsSync(rootHtml)) {
          res.sendFile(rootHtml);
        } else {
          res.status(500).send('Application build not found.');
        }
      }
    });
  } else {
    // Development mode: mount Vite middleware for SPA rendering with HMR disabled (prevents preview WebSocket disconnection errors)
    const vite = await createViteServer({
      server: { 
        middlewareMode: true, 
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 
          'Content-Type': 'text/html',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }).end(template);
      } catch (e) {
        next(e);
      }
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Server started on http://0.0.0.0:${port}`);
  });
}

startServer();
