import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { 
  UserAccount, 
  VenueId, 
  Venue,
  VenueInventory, 
  VenueEquipmentInventory,
  Shift, 
  ShiftReport, 
  DailyRevision,
  PendingApproval,
  ClockInRecord,
  ViewTab, 
  ShiftConflict,
  VenuePricing,
  WageSettings,
  EmployeeFine,
  StaffTask,
  DEFAULT_VENUE_INVENTORY_CONFIG
} from './types';
import { 
  loadAppState, 
  saveAppState, 
  getSavedCurrentUser, 
  saveCurrentUser, 
  detectConflicts, 
  copyWeekShifts,
  resetAppStateToBlank,
  fetchServerState,
  saveStateToServer,
  apiSaveUser,
  apiDeleteUser,
  apiSyncState,
  apiSaveWageSettings,
  apiSaveFine,
  apiDeleteFine,
  apiSaveInventory,
  apiSaveEquipment,
  apiSaveShift,
  apiDeleteShift,
  apiSaveReport,
  apiDeleteReport,
  apiSavePricing,
  apiSaveVenues,
  apiSavePendingApproval,
  apiReviewPendingApproval,
  apiSaveRevision,
  apiSaveClockIn
} from './utils/storage';
import { 
  subscribeToFirestoreState, 
  saveStateToFirestore, 
  loadStateFromFirestore,
  savePendingApprovalToFirestore,
  saveClockInToFirestore,
  saveRevisionToFirestore,
  saveShiftToFirestore,
  deleteShiftFromFirestore,
  saveReportToFirestore,
  deleteReportFromFirestore,
  saveFineToFirestore,
  deleteFineFromFirestore
} from './firebase';
import { getMonday, getWeekDays, formatDate } from './utils/dateUtils';
import { VENUES, INITIAL_USERS, INITIAL_INVENTORIES, INITIAL_EQUIPMENT_INVENTORIES, DEFAULT_VENUE_PRICING, DEFAULT_WAGE_SETTINGS } from './data/initialData';

import { LoginScreen } from './components/LoginScreen';
import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { InventoryView } from './components/InventoryView';
import { EquipmentInventoryView } from './components/EquipmentInventoryView';
import { ReportsView } from './components/ReportsView';
import { ScheduleView } from './components/ScheduleView';
import { ProfileView } from './components/ProfileView';
import { FinesView } from './components/FinesView';
import { FinesModal } from './components/FinesModal';
import { ShiftModal } from './components/ShiftModal';
import { TeamManageModal } from './components/TeamManageModal';
import { InstallAppModal } from './components/InstallAppModal';
import { ManageVenuesModal } from './components/ManageVenuesModal';
import { ApprovalsModal } from './components/ApprovalsModal';
import { ShiftNotificationBanner } from './components/ShiftNotificationBanner';
import { PhonePushBanner } from './components/PhonePushBanner';
import { PushSettingsModal } from './components/PushSettingsModal';
import { TasksView } from './components/TasksView';

import { Check, AlertCircle } from 'lucide-react';

export default function App() {
  // App persistent state
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [venues, setVenues] = useState<Venue[]>(VENUES);
  const [inventories, setInventories] = useState<Record<string, VenueInventory>>({});
  const [equipmentInventories, setEquipmentInventories] = useState<Record<string, VenueEquipmentInventory>>(INITIAL_EQUIPMENT_INVENTORIES);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [reports, setReports] = useState<ShiftReport[]>([]);
  const [revisions, setRevisions] = useState<DailyRevision[]>([]);
  const [pendingApprovals, setPendingApprovals] = useState<PendingApproval[]>([]);
  const [clockIns, setClockIns] = useState<ClockInRecord[]>([]);
  const [fines, setFines] = useState<EmployeeFine[]>([]);
  const [tasks, setTasks] = useState<StaffTask[]>([]);
  const [pricing, setPricing] = useState<Record<VenueId, VenuePricing>>(DEFAULT_VENUE_PRICING);
  const [wageSettings, setWageSettings] = useState<WageSettings>(DEFAULT_WAGE_SETTINGS);
  const [isLoaded, setIsLoaded] = useState(false);

  // Authentication state
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);

  // Active view tab
  const [activeTab, setActiveTab] = useState<ViewTab>('inventory');

  // Selected schedule week
  const [selectedMonday, setSelectedMonday] = useState<Date>(() => getMonday(new Date()));

  // Modals state
  const [shiftModalOpen, setShiftModalOpen] = useState(false);
  const [editingShift, setEditingShift] = useState<Shift | null>(null);
  const [modalVenueId, setModalVenueId] = useState<VenueId | undefined>(undefined);
  const [modalDate, setModalDate] = useState<string | undefined>(undefined);
  const [modalStaffId, setModalStaffId] = useState<string | undefined>(undefined);

  const [teamModalOpen, setTeamModalOpen] = useState(false);
  const [finesModalOpen, setFinesModalOpen] = useState(false);
  const [installModalOpen, setInstallModalOpen] = useState(false);
  const [manageVenuesModalOpen, setManageVenuesModalOpen] = useState(false);
  const [approvalsModalOpen, setApprovalsModalOpen] = useState(false);
  const [pushModalOpen, setPushModalOpen] = useState(false);

  // Toast notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Sync with authoritative server state
  const syncWithServer = useCallback(async () => {
    try {
      const serverData = await fetchServerState();
      if (!serverData || !Array.isArray(serverData.users)) return;

      if (serverData.users && Array.isArray(serverData.users) && serverData.users.length > 0) {
        setUsers((prev) => (JSON.stringify(prev) !== JSON.stringify(serverData.users) ? serverData.users : prev));
      }
      if ((serverData as any).venues && Array.isArray((serverData as any).venues) && (serverData as any).venues.length > 0) {
        setVenues((prev) => (JSON.stringify(prev) !== JSON.stringify((serverData as any).venues) ? (serverData as any).venues : prev));
      }
      // Never wipe valid client/Firestore data if server returns empty array
      if (serverData.shifts && Array.isArray(serverData.shifts) && serverData.shifts.length > 0) {
        setShifts((prev) => {
          const map = new Map(prev.map((s) => [s.id, s]));
          serverData.shifts.forEach((s: Shift) => {
            if (s && s.id) map.set(s.id, { ...(map.get(s.id) || {}), ...s });
          });
          const merged = Array.from(map.values());
          return JSON.stringify(prev) !== JSON.stringify(merged) ? merged : prev;
        });
      }
      if (serverData.reports && Array.isArray(serverData.reports) && serverData.reports.length > 0) {
        setReports((prev) => {
          const map = new Map(prev.map((r) => [r.id, r]));
          serverData.reports.forEach((r: ShiftReport) => {
            if (r && r.id) map.set(r.id, { ...(map.get(r.id) || {}), ...r });
          });
          const merged = Array.from(map.values());
          return JSON.stringify(prev) !== JSON.stringify(merged) ? merged : prev;
        });
      }
      if ((serverData as any).revisions && Array.isArray((serverData as any).revisions) && (serverData as any).revisions.length > 0) {
        setRevisions((prev) => {
          const map = new Map(prev.map((r) => [r.id, r]));
          (serverData as any).revisions.forEach((r: DailyRevision) => {
            if (r && r.id) map.set(r.id, { ...(map.get(r.id) || {}), ...r });
          });
          const merged = Array.from(map.values());
          return JSON.stringify(prev) !== JSON.stringify(merged) ? merged : prev;
        });
      }
      if ((serverData as any).pendingApprovals && Array.isArray((serverData as any).pendingApprovals) && (serverData as any).pendingApprovals.length > 0) {
        setPendingApprovals((prev) => {
          const map = new Map(prev.map((a) => [a.id, a]));
          (serverData as any).pendingApprovals.forEach((a: PendingApproval) => {
            if (a && a.id) map.set(a.id, { ...(map.get(a.id) || {}), ...a });
          });
          const merged = Array.from(map.values());
          return JSON.stringify(prev) !== JSON.stringify(merged) ? merged : prev;
        });
      }
      if ((serverData as any).clockIns && Array.isArray((serverData as any).clockIns) && (serverData as any).clockIns.length > 0) {
        setClockIns((prev) => {
          const map = new Map(prev.map((c) => [c.id, c]));
          (serverData as any).clockIns.forEach((c: ClockInRecord) => {
            if (c && c.id) map.set(c.id, { ...(map.get(c.id) || {}), ...c });
          });
          const merged = Array.from(map.values());
          return JSON.stringify(prev) !== JSON.stringify(merged) ? merged : prev;
        });
      }
      if (serverData.inventories && typeof serverData.inventories === 'object') {
        setInventories((prev) => {
          let changed = false;
          const next = { ...prev };
          Object.keys(serverData.inventories).forEach((vId) => {
            const serverInv = serverData.inventories[vId];
            const prevInv = prev[vId];
            if (!prevInv || (serverInv?.lastUpdated && serverInv.lastUpdated > (prevInv.lastUpdated || 0))) {
              next[vId] = serverInv;
              changed = true;
            }
          });
          return changed ? next : prev;
        });
      }
      if ((serverData as any).equipmentInventories && typeof (serverData as any).equipmentInventories === 'object') {
        setEquipmentInventories((prev) => {
          let changed = false;
          const next = { ...prev };
          Object.keys((serverData as any).equipmentInventories).forEach((vId) => {
            const serverEq = (serverData as any).equipmentInventories[vId];
            const prevEq = prev[vId];
            if (!prevEq || (serverEq?.lastUpdated && serverEq.lastUpdated > (prevEq.lastUpdated || 0))) {
              next[vId] = serverEq;
              changed = true;
            }
          });
          return changed ? next : prev;
        });
      }
      if (serverData.pricing) {
        setPricing((prev) => (JSON.stringify(prev) !== JSON.stringify(serverData.pricing) ? serverData.pricing : prev));
      }
      if (serverData.wageSettings) {
        setWageSettings((prev) => (JSON.stringify(prev) !== JSON.stringify(serverData.wageSettings) ? serverData.wageSettings : prev));
      }
      if ((serverData as any).tasks && Array.isArray((serverData as any).tasks)) {
        setTasks((serverData as any).tasks);
      }
      if (serverData.fines && Array.isArray(serverData.fines) && serverData.fines.length > 0) {
        setFines((prev) => {
          const map = new Map(prev.map((f) => [f.id, f]));
          serverData.fines.forEach((f: EmployeeFine) => {
            if (f && f.id) map.set(f.id, { ...(map.get(f.id) || {}), ...f });
          });
          const merged = Array.from(map.values());
          return JSON.stringify(prev) !== JSON.stringify(merged) ? merged : prev;
        });
      }
      if ((serverData as any).customLogo) {
        try {
          const stored = localStorage.getItem('hookah_custom_logo');
          if (stored !== (serverData as any).customLogo) {
            localStorage.setItem('hookah_custom_logo', (serverData as any).customLogo);
            window.dispatchEvent(new Event('hookah_logo_updated'));
          }
        } catch {}
      }
    } catch (e) {
      console.warn('Background sync error:', e);
    }
  }, []);

  // 1. Initial Load (Fast local cache first, then immediate server fetch)
  useEffect(() => {
    const localData = loadAppState();
    setUsers(localData.users);
    if (localData.venues && Array.isArray(localData.venues) && localData.venues.length > 0) setVenues(localData.venues);
    setInventories(localData.inventories);
    setEquipmentInventories(localData.equipmentInventories || INITIAL_EQUIPMENT_INVENTORIES);
    setShifts(localData.shifts);
    setReports(localData.reports);
    if (localData.revisions) setRevisions(localData.revisions);
    if (localData.pendingApprovals) setPendingApprovals(localData.pendingApprovals);
    if (localData.clockIns) setClockIns(localData.clockIns);
    setFines(localData.fines || []);
    setTasks(localData.tasks || []);
    setPricing(localData.pricing || DEFAULT_VENUE_PRICING);
    setWageSettings(localData.wageSettings || DEFAULT_WAGE_SETTINGS);

    const savedUser = getSavedCurrentUser(localData.users);
    if (savedUser) {
      setCurrentUser(savedUser);
    }

    // Fetch authoritative state from Firestore cloud database, then server
    loadStateFromFirestore().then((cloudData) => {
      if (cloudData && Array.isArray(cloudData.users) && cloudData.users.length > 0) {
        setUsers(cloudData.users);
        if (cloudData.venues && Array.isArray(cloudData.venues) && cloudData.venues.length > 0) setVenues(cloudData.venues);
        if (cloudData.inventories) setInventories(cloudData.inventories);
        if (cloudData.equipmentInventories) setEquipmentInventories(cloudData.equipmentInventories);
        if (cloudData.shifts) setShifts(cloudData.shifts);
        if (cloudData.reports) setReports(cloudData.reports);
        if (cloudData.revisions) setRevisions(cloudData.revisions);
        if (cloudData.pendingApprovals) setPendingApprovals(cloudData.pendingApprovals);
        if (cloudData.clockIns) setClockIns(cloudData.clockIns);
        if (cloudData.fines && Array.isArray(cloudData.fines)) setFines(cloudData.fines);
        if (Array.isArray((cloudData as any).tasks)) setTasks((cloudData as any).tasks);
        if (cloudData.pricing) setPricing(cloudData.pricing);
        if (cloudData.wageSettings) setWageSettings(cloudData.wageSettings);
        saveAppState(cloudData);
        // Seed server memory with cloud data so newly deployed server containers have the full state
        saveStateToServer(cloudData).catch(() => {});

        const refreshed = getSavedCurrentUser(cloudData.users);
        if (refreshed) {
          setCurrentUser(refreshed);
        } else {
          setCurrentUser(cloudData.users[0]);
          saveCurrentUser(cloudData.users[0]);
        }
        setIsLoaded(true);
      } else {
        // Fallback to server state
        fetchServerState().then((serverData) => {
          if (serverData && Array.isArray(serverData.users) && serverData.users.length > 0) {
            setUsers(serverData.users);
            if ((serverData as any).venues && Array.isArray((serverData as any).venues) && (serverData as any).venues.length > 0) setVenues((serverData as any).venues);
            if (serverData.inventories) setInventories(serverData.inventories);
            if ((serverData as any).equipmentInventories) setEquipmentInventories((serverData as any).equipmentInventories);
            if (serverData.shifts) setShifts(serverData.shifts);
            if (serverData.reports) setReports(serverData.reports);
            if ((serverData as any).revisions) setRevisions((serverData as any).revisions);
            if ((serverData as any).pendingApprovals) setPendingApprovals((serverData as any).pendingApprovals);
            if ((serverData as any).clockIns) setClockIns((serverData as any).clockIns);
            if (serverData.fines && Array.isArray(serverData.fines)) setFines(serverData.fines);
            if (Array.isArray((serverData as any).tasks)) setTasks((serverData as any).tasks);
            if (serverData.pricing) setPricing(serverData.pricing);
            if (serverData.wageSettings) setWageSettings(serverData.wageSettings);

            const currentSnapshot = {
              users: serverData.users,
              venues: (serverData as any).venues || VENUES,
              inventories: serverData.inventories || INITIAL_INVENTORIES,
              equipmentInventories: (serverData as any).equipmentInventories || INITIAL_EQUIPMENT_INVENTORIES,
              shifts: serverData.shifts || [],
              reports: serverData.reports || [],
              revisions: (serverData as any).revisions || [],
              pendingApprovals: (serverData as any).pendingApprovals || [],
              clockIns: (serverData as any).clockIns || [],
              fines: serverData.fines || [],
              tasks: (serverData as any).tasks || [],
              pricing: serverData.pricing || DEFAULT_VENUE_PRICING,
              wageSettings: serverData.wageSettings || DEFAULT_WAGE_SETTINGS,
            };
            saveAppState(currentSnapshot);
            saveStateToFirestore(currentSnapshot);

            const refreshed = getSavedCurrentUser(serverData.users);
            if (refreshed) {
              setCurrentUser(refreshed);
            } else {
              setCurrentUser(serverData.users[0]);
              saveCurrentUser(serverData.users[0]);
            }
          } else {
            saveStateToServer(localData);
            saveStateToFirestore(localData);
          }
          setIsLoaded(true);
        });
      }
    }).catch(() => {
      setIsLoaded(true);
    });
  }, []);

  // 2. Real-time Firestore Cloud Database listener across all devices
  useEffect(() => {
    const unsubscribe = subscribeToFirestoreState((cloudState) => {
      if (!cloudState || !Array.isArray(cloudState.users) || cloudState.users.length === 0) return;
      setUsers((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.users) ? cloudState.users : prev));
      if (cloudState.venues && Array.isArray(cloudState.venues) && cloudState.venues.length > 0) {
        setVenues((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.venues) ? cloudState.venues : prev));
      }
      if (cloudState.inventories) {
        setInventories((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.inventories) ? cloudState.inventories : prev));
      }
      if (cloudState.equipmentInventories) {
        setEquipmentInventories((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.equipmentInventories) ? cloudState.equipmentInventories : prev));
      }
      if (cloudState.shifts && Array.isArray(cloudState.shifts)) {
        setShifts((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.shifts) ? cloudState.shifts : prev));
      }
      if (cloudState.reports && Array.isArray(cloudState.reports)) {
        setReports((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.reports) ? cloudState.reports : prev));
      }
      if (cloudState.revisions && Array.isArray(cloudState.revisions)) {
        setRevisions((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.revisions) ? cloudState.revisions : prev));
      }
      if (cloudState.pendingApprovals && Array.isArray(cloudState.pendingApprovals)) {
        setPendingApprovals((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.pendingApprovals) ? cloudState.pendingApprovals : prev));
      }
      if (cloudState.clockIns && Array.isArray(cloudState.clockIns)) {
        setClockIns((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.clockIns) ? cloudState.clockIns : prev));
      }
      if (Array.isArray((cloudState as any).tasks)) {
        setTasks((prev) => (JSON.stringify(prev) !== JSON.stringify((cloudState as any).tasks) ? (cloudState as any).tasks : prev));
      }
      if (cloudState.fines && Array.isArray(cloudState.fines)) {
        setFines((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.fines) ? cloudState.fines : prev));
      }
      if (cloudState.pricing) {
        setPricing((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.pricing) ? cloudState.pricing : prev));
      }
      if (cloudState.wageSettings) {
        setWageSettings((prev) => (JSON.stringify(prev) !== JSON.stringify(cloudState.wageSettings) ? cloudState.wageSettings : prev));
      }
      saveAppState(cloudState);
    });

    return () => unsubscribe();
  }, []);

  // 3. Fallback server polling across devices
  useEffect(() => {
    if (!isLoaded) return;
    const interval = setInterval(syncWithServer, 5000);
    const onFocus = () => syncWithServer();
    window.addEventListener('focus', onFocus);
    document.addEventListener('visibilitychange', onFocus);

    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', onFocus);
      document.removeEventListener('visibilitychange', onFocus);
    };
  }, [isLoaded, syncWithServer]);

  // Bug 2: Browser push notifications scheduled for 1 hour before and at shift start
  const notifiedShiftsRef = useRef<Set<string>>(new Set());

  // Request browser notification permissions
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'default') {
        Notification.requestPermission().catch(() => {});
      }
    }
  }, []);

  // Robust timer checking shift start times (1 hour before, and at shift start)
  useEffect(() => {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    if (!currentUser) return;

    const checkScheduledShiftNotifications = () => {
      if (Notification.permission !== 'granted') return;

      const now = new Date();
      const todayStr = formatDate(now);
      const nowTimeMs = now.getTime();

      // Find user's assigned shifts today
      const todayUserShifts = shifts.filter(
        (s) => s.staffId === currentUser.id && s.date === todayStr && !s.isCompleted
      );

      todayUserShifts.forEach((shift) => {
        const venueObj = venues.find((v) => v.id === shift.venueId);
        const venueName = venueObj?.name || shift.venueId;

        const [startH, startM] = (shift.startTime || '16:00').split(':').map(Number);
        const shiftStartDate = new Date(now);
        shiftStartDate.setHours(startH, startM, 0, 0);

        const diffMinutes = Math.round((shiftStartDate.getTime() - nowTimeMs) / (60 * 1000));

        // 1. One hour before shift start (50 to 65 minutes before, if not clocked in)
        const oneHourKey = `1h_${shift.id}_${shift.date}`;
        if (diffMinutes > 0 && diffMinutes <= 60 && !shift.isClockedIn && !notifiedShiftsRef.current.has(oneHourKey)) {
          notifiedShiftsRef.current.add(oneHourKey);
          try {
            new Notification(`Предстояща смяна: ${venueName}`, {
              body: `Смяната ви започва в ${shift.startTime} ч. (след ~${diffMinutes} мин.)`,
              icon: '/favicon.ico',
            });
          } catch (err) {
            console.warn('Native notification error:', err);
          }
        }

        // 2. At shift start (between 0 and 25 mins after start time, if not clocked in)
        const startKey = `start_${shift.id}_${shift.date}`;
        if (diffMinutes <= 0 && diffMinutes >= -25 && !shift.isClockedIn && !notifiedShiftsRef.current.has(startKey)) {
          notifiedShiftsRef.current.add(startKey);
          try {
            new Notification(`Смяната започна: ${venueName}!`, {
              body: `Време е за работа в ${venueName} (${shift.startTime} ч.). Моля отбележете се с "На работа съм"!`,
              icon: '/favicon.ico',
            });
          } catch (err) {
            console.warn('Native notification error:', err);
          }
        }
      });
    };

    checkScheduledShiftNotifications();
    const notificationInterval = setInterval(checkScheduledShiftNotifications, 30000);
    return () => clearInterval(notificationInterval);
  }, [currentUser, shifts, venues]);

  // 4. Persist state changes to local cache and Firestore cloud database permanently
  useEffect(() => {
    if (isLoaded) {
      const state = { users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks };
      saveAppState(state);
      saveStateToFirestore(state);
    }
  }, [users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks, isLoaded]);

  // Handle pricing update (boss only)
  const handleUpdatePricing = async (newPricing: Record<VenueId, VenuePricing>) => {
    if (currentUser?.role !== 'boss') {
      showToast('Грешка: Само шефът има право да променя цените!');
      return;
    }
    setPricing(newPricing);
    saveAppState({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing: newPricing, wageSettings, fines, tasks });
    await apiSavePricing(newPricing, currentUser.role);
    showToast('Цените са обновени на всички устройства.');
  };

  // Handle wage settings update (boss only - saves immediately across all devices)
  const handleUpdateWageSettings = async (newSettings: WageSettings, updatedUsers?: UserAccount[]) => {
    if (currentUser?.role !== 'boss') {
      showToast('Грешка: Само шефът има право да променя ставките!');
      return;
    }
    setWageSettings(newSettings);
    let finalUsers = users;
    if (updatedUsers && Array.isArray(updatedUsers)) {
      finalUsers = updatedUsers;
      setUsers(updatedUsers);
    }
    const currentSnapshot = { 
      users: finalUsers, 
      venues,
      inventories, 
      equipmentInventories, 
      shifts, 
      reports, 
      revisions,
      pendingApprovals,
      clockIns,
      pricing, 
      wageSettings: newSettings, 
      fines,
      tasks
    };
    saveAppState(currentSnapshot);
    const res = await apiSaveWageSettings(newSettings, 'boss', updatedUsers);
    if (res.success && res.users) {
      setUsers(res.users);
    }
    showToast(`Ставките са запазени веднага: ${newSettings.baseWageEur} ${newSettings.currency} надник + ${newSettings.hookahRateEur} ${newSettings.currency} на наргиле`);
  };

  const handleCreateTask = (taskData: Omit<StaffTask, 'id' | 'createdAt' | 'updatedAt'>) => {
    if (!currentUser || (currentUser.role !== 'boss' && currentUser.role !== 'admin')) {
      showToast('Само шеф или администратор може да възлага задачи.');
      return;
    }
    const now = Date.now();
    const task: StaffTask = { ...taskData, id: `task-${now}-${Math.random().toString(36).slice(2, 8)}`, createdAt: now, updatedAt: now };
    const nextTasks = [task, ...tasks];
    setTasks(nextTasks);
    saveAppState({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks: nextTasks });
    saveStateToServer({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks: nextTasks, requesterRole: currentUser.role } as any).catch(() => {});
    fetch('/api/tasks/notify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ task }) }).catch(() => {});
    showToast('Задачата е възложена.');
  };

  const handleUpdateTask = (updatedTask: StaffTask) => {
    if (!currentUser) return;
    const existing = tasks.find(task => task.id === updatedTask.id);
    if (!existing) return;
    const manager = currentUser.role === 'boss' || currentUser.role === 'admin';
    if (!manager && existing.assigneeId !== currentUser.id && existing.target !== 'venue') {
      showToast('Нямаш права да променяш тази задача.'); return;
    }
    const nextTasks = tasks.map(task => task.id === updatedTask.id ? { ...updatedTask, updatedAt: Date.now() } : task);
    setTasks(nextTasks);
    saveAppState({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks: nextTasks });
    saveStateToServer({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks: nextTasks, requesterRole: currentUser.role } as any).catch(() => {});
  };

  const handleDeleteTask = (taskId: string) => {
    if (!currentUser || (currentUser.role !== 'boss' && currentUser.role !== 'admin')) return;
    const nextTasks = tasks.filter(task => task.id !== taskId);
    setTasks(nextTasks);
    saveAppState({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks: nextTasks });
    saveStateToServer({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks: nextTasks, requesterRole: currentUser.role } as any).catch(() => {});
  };

  // Handle Login & Logout
  const handleLogin = (user: UserAccount) => {
    setCurrentUser(user);
    saveCurrentUser(user);
    showToast(`Добре дошъл, ${user.name}!`);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    saveCurrentUser(null);
    showToast('Успешен изход от системата.');
  };

  // Week computation
  const weekDays = useMemo(() => getWeekDays(selectedMonday), [selectedMonday]);
  const weekStartDate = weekDays[0]?.date;
  const weekEndDate = weekDays[6]?.date;

  const currentWeekShifts = useMemo(() => {
    if (!weekStartDate || !weekEndDate) return [];
    return shifts.filter((s) => s.date >= weekStartDate && s.date <= weekEndDate);
  }, [shifts, weekStartDate, weekEndDate]);

  const conflicts = useMemo(() => {
    return detectConflicts(currentWeekShifts);
  }, [currentWeekShifts]);

  // Inventory updates (direct server persistence across all devices & IPs)
  const handleUpdateInventory = async (venueId: VenueId, updated: VenueInventory) => {
    const cleanUpdated: VenueInventory = {
      ...updated,
      lastUpdated: Date.now(),
    };
    setInventories((prev) => ({
      ...prev,
      [venueId]: cleanUpdated,
    }));
    await apiSaveInventory(venueId, cleanUpdated);
  };

  // Equipment inventory updates (direct server persistence across all devices & IPs)
  const handleUpdateEquipment = async (venueId: VenueId, updated: VenueEquipmentInventory) => {
    const cleanUpdated: VenueEquipmentInventory = {
      ...updated,
      lastUpdated: Date.now(),
    };
    setEquipmentInventories((prev) => ({
      ...prev,
      [venueId]: cleanUpdated,
    }));
    await apiSaveEquipment(venueId, cleanUpdated);
  };

  // Shift Actions (Editable by authorized staff, persisted directly to server)
  const handleOpenAddShift = (venueId?: VenueId, date?: string, staffId?: string) => {
    setEditingShift(null);
    setModalVenueId(venueId || 'bar-hey');
    setModalDate(date || weekStartDate);
    setModalStaffId(staffId || currentUser?.id);
    setShiftModalOpen(true);
  };

  const handleOpenEditShift = (shift: Shift) => {
    setEditingShift(shift);
    setModalVenueId(shift.venueId);
    setModalDate(shift.date);
    setModalStaffId(shift.staffId);
    setShiftModalOpen(true);
  };

  const handleSaveShift = async (
    shiftData: Omit<Shift, 'id' | 'createdAt'>, 
    existingId?: string
  ) => {
    const cleanShift: Shift = existingId
      ? { ...shiftData, id: existingId, createdAt: Date.now() }
      : {
          ...shiftData,
          id: `sh-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
          createdAt: Date.now(),
        };

    if (existingId) {
      setShifts((prev) => prev.map((s) => (s.id === existingId ? cleanShift : s)));
      showToast('Смяната е обновена!');
    } else {
      setShifts((prev) => [...prev, cleanShift]);
      showToast('Новата смяна е добавена в графика!');
    }

    await apiSaveShift(cleanShift);
  };

  const handleDeleteShift = async (shiftId: string) => {
    setShifts((prev) => prev.filter((s) => s.id !== shiftId));
    await apiDeleteShift(shiftId);
    showToast('Смяната беше премахната.');
  };

  const handleCopyFromPreviousWeek = async () => {
    const previousMonday = new Date(selectedMonday);
    previousMonday.setDate(previousMonday.getDate() - 7);

    if (confirm('Искате ли да копирате смените от миналата седмица в текущата?')) {
      const updated = copyWeekShifts(shifts, previousMonday, selectedMonday, currentUser?.id || 'usr-1');
      setShifts(updated);
      for (const s of updated) {
        apiSaveShift(s);
      }
      showToast('Смените бяха копирани успешно в новата седмица!');
    }
  };

  // Venues Actions (Admin & Boss only)
  const handleSaveVenues = async (newVenues: Venue[]) => {
    if (currentUser?.role !== 'boss' && currentUser?.role !== 'admin') {
      showToast('Само шеф или администратор може да управлява заведенията!');
      return;
    }
    setVenues(newVenues);
    const updatedState = { users, venues: newVenues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks };
    saveAppState(updatedState);
    saveStateToFirestore(updatedState);
    await apiSaveVenues(newVenues);
    showToast('Списъкът със заведения е обновен!');
  };

  const handleUpdateVenueConfig = (updatedVenue: Venue) => {
    if (currentUser?.role !== 'boss' && currentUser?.role !== 'admin') {
      showToast('Само шеф или администратор може да настройва инвентара на обект.');
      return;
    }
    const nextVenues = venues.map(venue => venue.id === updatedVenue.id ? updatedVenue : venue);
    setVenues(nextVenues);
    const snapshot = { users, venues: nextVenues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks };
    saveAppState(snapshot);
    saveStateToFirestore(snapshot);
    apiSaveVenues(nextVenues).catch(() => {});
  };

  // Daily Revision Actions (Smart Inventory & Revision)
  const handleSaveRevision = async (revisionData: Omit<DailyRevision, 'id' | 'createdAt'>) => {
    const newRev: DailyRevision = {
      ...revisionData,
      id: `rev-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
    };
    const nextRevs = [newRev, ...revisions];
    setRevisions(nextRevs);
    const updatedState = { users, venues, inventories, equipmentInventories, shifts, reports, revisions: nextRevs, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks };
    saveAppState(updatedState);
    saveStateToFirestore(updatedState);
    await saveRevisionToFirestore(newRev);
    await apiSaveRevision(newRev);
    showToast('Ревизията е запазена успешно!');
  };

  // Inventory Approval Workflow (Брак и Липси)
  const handleRequestApproval = async (approvalData: Omit<PendingApproval, 'id' | 'createdAt' | 'status'>) => {
    const newApproval: PendingApproval = {
      ...approvalData,
      id: `appr-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      status: 'pending',
      createdAt: Date.now(),
    };
    const nextApprovals = [newApproval, ...pendingApprovals];
    setPendingApprovals(nextApprovals);
    const updatedState = { users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals: nextApprovals, clockIns, pricing, wageSettings, fines, tasks };
    saveAppState(updatedState);
    saveStateToFirestore(updatedState);
    await savePendingApprovalToFirestore(newApproval);
    await apiSavePendingApproval(newApproval);
    showToast('Заявката за брак е изпратена за одобрение от шеф/администратор!');
  };

  const handleApproveApproval = async (approvalId: string) => {
    if (currentUser?.role !== 'boss' && currentUser?.role !== 'admin') {
      showToast('Само шеф или администратор може да одобрява брак!');
      return;
    }
    const target = pendingApprovals.find((a) => a.id === approvalId);
    if (!target) return;

    // 1. Update main inventory count
    if (target.category === 'equipment') {
      const eqInv = equipmentInventories[target.venueId];
      if (eqInv) {
        let updatedEq = { ...eqInv };
        if (target.itemId.startsWith('bowl-')) {
          const bId = target.itemId.replace('bowl-', '');
          updatedEq.bowls = (eqInv.bowls || []).map((b) =>
            b.id === bId ? { ...b, count: Math.max(0, target.requestedCount) } : b
          );
        } else if (['hookahsCount', 'electricHookahsCount', 'vasesCount', 'hosesCount', 'hmsCount'].includes(target.itemId)) {
          (updatedEq as any)[target.itemId] = Math.max(0, target.requestedCount);
        }
        updatedEq.lastUpdated = Date.now();
        setEquipmentInventories((prev) => ({ ...prev, [target.venueId]: updatedEq }));
        apiSaveEquipment(target.venueId, updatedEq);
      }
    }

    // 2. Mark approval as approved
    const updatedApproval: PendingApproval = {
      ...target,
      status: 'approved',
      reviewedBy: currentUser.name,
      reviewedAt: Date.now(),
    };
    const nextApprovals = pendingApprovals.map((a) => (a.id === approvalId ? updatedApproval : a));
    setPendingApprovals(nextApprovals);

    const updatedState = { users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals: nextApprovals, clockIns, pricing, wageSettings, fines, tasks };
    saveAppState(updatedState);
    saveStateToFirestore(updatedState);
    await savePendingApprovalToFirestore(updatedApproval);
    await apiReviewPendingApproval(approvalId, 'approved', currentUser.name);
    showToast(`Заявката за ${target.itemName} е одобрена и наличността е обновена!`);
  };

  const handleRejectApproval = async (approvalId: string, reviewNote?: string) => {
    if (currentUser?.role !== 'boss' && currentUser?.role !== 'admin') {
      showToast('Само шеф или администратор може да преглежда брак!');
      return;
    }
    const target = pendingApprovals.find((a) => a.id === approvalId);
    if (!target) return;

    const updatedApproval: PendingApproval = {
      ...target,
      status: 'rejected',
      reviewedBy: currentUser.name,
      reviewedAt: Date.now(),
      reviewNote,
    };
    const nextApprovals = pendingApprovals.map((a) => (a.id === approvalId ? updatedApproval : a));
    setPendingApprovals(nextApprovals);

    const updatedState = { users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals: nextApprovals, clockIns, pricing, wageSettings, fines, tasks };
    saveAppState(updatedState);
    saveStateToFirestore(updatedState);
    await savePendingApprovalToFirestore(updatedApproval);
    await apiReviewPendingApproval(approvalId, 'rejected', currentUser.name, reviewNote);
    showToast(`Заявката за ${target.itemName} беше отхвърлена.`);
  };

  // Clock-in Action
  const handleClockIn = async (shiftId: string, venueId: string) => {
    if (!currentUser) return;
    const now = Date.now();
    const timeString = new Date(now).toLocaleTimeString('bg-BG', { hour: '2-digit', minute: '2-digit' });

    // 1. Update the shift in shifts
    const nextShifts = shifts.map((s) =>
      s.id === shiftId
        ? { ...s, clockInTimestamp: now, clockInTimeString: timeString }
        : s
    );
    setShifts(nextShifts);

    // 2. Create ClockInRecord
    const targetShift = shifts.find((s) => s.id === shiftId);
    const newClockIn: ClockInRecord = {
      id: `clock-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      shiftId,
      venueId,
      staffId: currentUser.id,
      staffName: currentUser.name,
      date: targetShift?.date || formatDate(new Date()),
      clockInTimestamp: now,
      clockInTimeString: timeString,
      createdAt: now,
    };
    const nextClockIns = [newClockIn, ...clockIns];
    setClockIns(nextClockIns);

    // 3. Persist to Firestore and server
    const updatedState = { users, venues, inventories, equipmentInventories, shifts: nextShifts, reports, revisions, pendingApprovals, clockIns: nextClockIns, pricing, wageSettings, fines, tasks };
    saveAppState(updatedState);
    saveStateToFirestore(updatedState);
    await saveClockInToFirestore(newClockIn);
    await apiSaveClockIn(newClockIn);
    if (targetShift) {
      await apiSaveShift({ ...targetShift, clockInTimestamp: now, clockInTimeString: timeString });
    }

    showToast(`Успешно се отбелязахте: "На работа съм" в ${timeString} ч.!`);
  };

  // Reports Actions (Persisted directly to server across all devices)
  const handleAddReport = async (
    reportData: Omit<ShiftReport, 'id' | 'createdAt' | 'baseWageEur' | 'hookahBonusEur' | 'totalEarnedEur'>
  ) => {
    const staffUser = users.find((u) => u.id === reportData.staffId);
    const baseWageEur = (typeof staffUser?.customBaseWageEur === 'number' && staffUser.customBaseWageEur >= 0)
      ? staffUser.customBaseWageEur
      : (wageSettings?.baseWageEur ?? 23);
    const hookahRate = (typeof staffUser?.customHookahRateEur === 'number' && staffUser.customHookahRateEur >= 0)
      ? staffUser.customHookahRateEur
      : (wageSettings?.hookahRateEur ?? 1);
    const hookahBonusEur = reportData.totalHookahs * hookahRate;
    const totalEarnedEur = baseWageEur + hookahBonusEur;

    const newReport: ShiftReport = {
      ...reportData,
      id: `rep-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      baseWageEur,
      hookahBonusEur,
      totalEarnedEur,
      createdAt: Date.now(),
    };

    setReports((prev) => [newReport, ...prev]);

    // Automatically deduct charcoals optionally based on report
    const inv = inventories[reportData.venueId];
    if (inv && ({ ...DEFAULT_VENUE_INVENTORY_CONFIG, ...(venues.find(v => v.id === reportData.venueId)?.inventoryConfig || {}) }).charcoals && !revisions.some(rev => rev.venueId === reportData.venueId && rev.date === reportData.date && typeof rev.charcoalsEndKg === 'number')) {
      const charcoalsKgUsed = Number((reportData.totalHookahs * 0.06).toFixed(2));
      const updatedInv = {
        ...inv,
        mouthpiecePacksCount: inv.mouthpiecePacksCount ?? 0,
        charcoalsKg: Math.max(0, Number((inv.charcoalsKg - charcoalsKgUsed).toFixed(1))),
        lastUpdated: Date.now(),
      };
      setInventories((prev) => ({
        ...prev,
        [reportData.venueId]: updatedInv,
      }));
      apiSaveInventory(reportData.venueId, updatedInv);
    }

    await apiSaveReport(newReport);
    showToast('Отчетът беше записан успешно на всички устройства!');
  };

  const handleDeleteReport = async (reportId: string) => {
    setReports((prev) => prev.filter((r) => r.id !== reportId));
    await apiDeleteReport(reportId);
    showToast('Отчетът беше изтрит.');
  };

  // Step 3 Final End Shift: Marks the employee's shift as officially completed
  const handleCompleteShift = async (shiftId: string) => {
    const now = Date.now();
    const nextShifts = shifts.map((s) =>
      s.id === shiftId
        ? { ...s, isCompleted: true, completedAt: now }
        : s
    );
    setShifts(nextShifts);

    const targetShift = shifts.find((s) => s.id === shiftId);
    const updatedState = { users, venues, inventories, equipmentInventories, shifts: nextShifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks };
    saveAppState(updatedState);
    saveStateToFirestore(updatedState);
    if (targetShift) {
      await apiSaveShift({ ...targetShift, isCompleted: true, completedAt: now });
    }
  };

  // Fines Actions
  const handleAddFine = async (fineData: Omit<EmployeeFine, 'id' | 'createdAt'>) => {
    const newFine: EmployeeFine = {
      ...fineData,
      id: `fine-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
    };
    setFines((prev) => [newFine, ...prev]);
    saveAppState({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines: [newFine, ...fines], tasks });
    await apiSaveFine(newFine);
    showToast(`Глоба от ${fineData.amountEur} € беше наложена на ${fineData.staffName} и се приспада от заплатата му.`);
  };

  const handleDeleteFine = async (fineId: string) => {
    const updated = fines.filter((f) => f.id !== fineId);
    setFines(updated);
    saveAppState({ users, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines: updated, tasks });
    await apiDeleteFine(fineId);
    showToast('Глобата беше отменена / изтрита.');
  };

  // Team Management Actions with Direct Server Persistence (CYBERSECURITY: BOSS ONLY)
  const handleAddUser = async (newUserData: Omit<UserAccount, 'id' | 'avatarColor'>) => {
    if (currentUser?.role !== 'boss') {
      showToast('Грешка: Само шефът има право да добавя служители!');
      return;
    }

    const colors = [
      'bg-cyan-500 text-slate-950',
      'bg-amber-500 text-slate-950',
      'bg-violet-500 text-white',
      'bg-rose-500 text-white',
      'bg-emerald-500 text-slate-950',
    ];
    const avatarColor = colors[users.length % colors.length];

    const newUser: UserAccount = {
      ...newUserData,
      id: `usr-${Date.now().toString(36)}`,
      avatarColor,
    };

    setUsers((prev) => [...prev, newUser]);
    const res = await apiSaveUser(newUser, 'boss');
    if (res.success && res.users) {
      setUsers(res.users);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (currentUser?.role !== 'boss') {
      showToast('Грешка: Само шефът има право да премахва служители!');
      return;
    }

    setUsers((prev) => prev.filter((u) => u.id !== userId));
    const res = await apiDeleteUser(userId, 'boss');
    if (res.success && res.users) {
      setUsers(res.users);
    }
    showToast('Потребителят беше премахнат.');
  };

  const handleUpdateUser = async (updated: UserAccount) => {
    if (currentUser?.role !== 'boss') {
      showToast('Грешка: Само шефът има право да редактира данни и ставки!');
      return;
    }

    const nextUsers = users.map((u) => (u.id === updated.id ? updated : u));
    setUsers(nextUsers);
    if (currentUser?.id === updated.id) {
      setCurrentUser(updated);
      saveCurrentUser(updated);
    }
    saveAppState({ users: nextUsers, venues, inventories, equipmentInventories, shifts, reports, revisions, pendingApprovals, clockIns, pricing, wageSettings, fines, tasks });
    const res = await apiSaveUser(updated, 'boss');
    if (res.success && res.users) {
      setUsers(res.users);
    }
    showToast(`Данните и ставките на ${updated.name} са запазени веднага.`);
  };

  // Reset to default blank state
  const handleResetData = () => {
    if (confirm('Изчистване на всички въведени данни към чисто начално състояние (blank)?')) {
      const fresh = resetAppStateToBlank();
      setUsers(fresh.users);
      setInventories(fresh.inventories);
      setEquipmentInventories(fresh.equipmentInventories);
      setShifts(fresh.shifts);
      setReports(fresh.reports);
      setRevisions(fresh.revisions);
      setPendingApprovals(fresh.pendingApprovals);
      setClockIns(fresh.clockIns);
      setFines(fresh.fines);
      setTasks(fresh.tasks);
      setVenues(fresh.venues);
      setWageSettings(fresh.wageSettings);
      setPricing(fresh.pricing);
      setCurrentUser(fresh.users[0]);
      showToast('Всички данни бяха изчистени към празно състояние.');
    }
  };

  // If not logged in, render LoginScreen with credentials & role selection
  if (!currentUser) {
    return (
      <>
        <LoginScreen
          users={users.length > 0 ? users : INITIAL_USERS}
          onLogin={handleLogin}
          onOpenInstallModal={() => setInstallModalOpen(true)}
        />
        <InstallAppModal
          isOpen={installModalOpen}
          onClose={() => setInstallModalOpen(false)}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 border border-amber-500/50 text-white text-xs sm:text-sm font-semibold px-4 py-3 rounded-2xl shadow-2xl flex items-center gap-2.5 animate-in fade-in slide-in-from-bottom-2 duration-200">
          <Check className="w-4 h-4 text-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main App Navigation Header */}
      <Header
        currentUser={currentUser}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onLogout={handleLogout}
        wageSettings={wageSettings}
        finesCount={currentUser.role === 'boss' ? fines.length : fines.filter((f) => f.staffId === currentUser.id).length}
        pendingApprovalsCount={pendingApprovals.filter((a) => a.status === 'pending').length}
        onOpenTeamManage={() => {
          syncWithServer();
          setTeamModalOpen(true);
        }}
        onOpenManageVenues={() => setManageVenuesModalOpen(true)}
        onOpenApprovals={() => setApprovalsModalOpen(true)}
        onOpenPushModal={() => setPushModalOpen(true)}
        onOpenFinesModal={() => setFinesModalOpen(true)}
        onOpenInstallModal={() => setInstallModalOpen(true)}
        onResetData={handleResetData}
        conflictsCount={conflicts.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-2.5 sm:px-6 lg:px-8 py-3.5 sm:py-6 pb-28 sm:pb-8 space-y-6">
        {/* PHONE PUSH NOTIFICATIONS BANNER (Direct notifications on lock screen even when app is closed) */}
        <PhonePushBanner
          currentUser={currentUser}
          onNotify={showToast}
        />

        {/* SHIFT NOTIFICATIONS & CLOCK-IN SYSTEM */}
        <ShiftNotificationBanner
          shifts={shifts}
          venues={venues}
          currentUser={currentUser}
          onClockIn={handleClockIn}
          onNavigateToRevision={() => setActiveTab('inventory')}
          onNavigateToReports={() => setActiveTab('reports')}
        />

        {/* TAB 1: Тютюни & Ревизия (Merged Accordion UI + Simple Запази ревизия) */}
        {activeTab === 'inventory' && (
          <InventoryView
            inventories={inventories}
            venues={venues}
            revisions={revisions}
            currentUser={currentUser}
            shifts={shifts}
            onUpdateInventory={handleUpdateInventory}
            onSaveRevision={handleSaveRevision}
            onNavigateToReports={() => setActiveTab('reports')}
            onNotify={showToast}
          />
        )}

        {/* TAB 2: Инвентар на Оборудването */}
        {activeTab === 'equipment' && (
          <EquipmentInventoryView
            equipmentInventories={equipmentInventories}
            venues={venues}
            currentUser={currentUser}
            pendingApprovals={pendingApprovals}
            onUpdateEquipment={handleUpdateEquipment}
            onUpdateVenue={handleUpdateVenueConfig}
            onRequestApproval={handleRequestApproval}
            onOpenApprovalsModal={() => setApprovalsModalOpen(true)}
            onNotify={showToast}
          />
        )}

        {/* TAB 3: Дневен отчет (Последователност: Ревизия -> Отчет -> Приключи смяна / Slack) */}
        {activeTab === 'reports' && (
          <ReportsView
            reports={reports}
            venues={venues}
            revisions={revisions}
            shifts={shifts}
            currentUser={currentUser}
            wageSettings={wageSettings}
            onAddReport={handleAddReport}
            onDeleteReport={handleDeleteReport}
            onCompleteShift={handleCompleteShift}
            onNavigateToRevision={() => setActiveTab('inventory')}
            onNotify={showToast}
          />
        )}

        {/* TAB 4: График на смените */}
        {activeTab === 'schedule' && (
          <ScheduleView
            days={weekDays}
            selectedMonday={selectedMonday}
            onSelectMonday={setSelectedMonday}
            shifts={currentWeekShifts}
            allUsers={users}
            currentUser={currentUser}
            venues={venues}
            conflicts={conflicts}
            onAddShift={handleOpenAddShift}
            onEditShift={handleOpenEditShift}
            onDeleteShift={handleDeleteShift}
            onCopyFromPreviousWeek={handleCopyFromPreviousWeek}
          />
        )}

        {activeTab === 'tasks' && (
          <TasksView tasks={tasks} users={users} venues={venues} shifts={shifts} currentUser={currentUser}
            onCreate={handleCreateTask} onUpdate={handleUpdateTask} onDelete={handleDeleteTask} />
        )}

        {/* TAB: Глоби & Удръжки */}
        {activeTab === 'fines' && (
          <FinesView
            fines={fines}
            users={users}
            currentUser={currentUser}
            onAddFine={handleAddFine}
            onDeleteFine={handleDeleteFine}
            onNotify={showToast}
          />
        )}

        {/* TAB 7: Личен профил & Автоматично пресмятане на заплата */}
        {activeTab === 'my_profile' && (
          <ProfileView
            currentUser={currentUser}
            allUsers={users}
            reports={reports}
            shifts={shifts}
            pricing={pricing}
            wageSettings={wageSettings}
            fines={fines}
            onUpdatePricing={handleUpdatePricing}
            onUpdateWageSettings={handleUpdateWageSettings}
            onUpdateUser={handleUpdateUser}
            onAddFine={handleAddFine}
            onDeleteFine={handleDeleteFine}
            onOpenInstallModal={() => setInstallModalOpen(true)}
            onOpenPushModal={() => setPushModalOpen(true)}
            onNotify={showToast}
          />
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation */}
      <MobileBottomNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        currentUser={currentUser}
        finesCount={currentUser.role === 'boss' ? fines.length : fines.filter((f) => f.staffId === currentUser.id).length}
      />

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 py-4 mt-auto text-xs text-slate-500 mb-16 sm:mb-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <div className="flex items-center gap-2 flex-wrap justify-center">
            <span className="text-amber-400 font-extrabold tracking-wider">CARGO HOOKAH:</span>
            {venues.filter((v) => v.isActive !== false).map((v, i) => (
              <React.Fragment key={v.id}>
                {i > 0 && <span>•</span>}
                <span>{v.name}</span>
              </React.Fragment>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleResetData}
              className="text-slate-500 hover:text-slate-300 transition-colors"
            >
              Възстанови начални данни
            </button>
            <span>•</span>
            <button
              onClick={() => setInstallModalOpen(true)}
              className="text-amber-400 hover:underline font-semibold"
            >
              Инсталирай на телефон
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <ShiftModal
        isOpen={shiftModalOpen}
        onClose={() => setShiftModalOpen(false)}
        onSave={handleSaveShift}
        onDelete={handleDeleteShift}
        initialShift={editingShift}
        defaultVenueId={modalVenueId}
        defaultDate={modalDate}
        defaultStaffId={modalStaffId}
        staffList={users}
        createdById={currentUser.id}
        venues={venues}
      />

      <TeamManageModal
        isOpen={teamModalOpen}
        onClose={() => setTeamModalOpen(false)}
        users={users}
        currentUser={currentUser}
        wageSettings={wageSettings}
        onAddUser={handleAddUser}
        onUpdateUser={handleUpdateUser}
        onDeleteUser={handleDeleteUser}
        onNotify={showToast}
        onOpenInviteQr={() => setInstallModalOpen(true)}
        onRefreshTeam={syncWithServer}
      />

      <FinesModal
        isOpen={finesModalOpen}
        onClose={() => setFinesModalOpen(false)}
        fines={fines}
        users={users}
        currentUser={currentUser}
        onAddFine={handleAddFine}
        onDeleteFine={handleDeleteFine}
        onNotify={showToast}
      />

      <InstallAppModal
        isOpen={installModalOpen}
        onClose={() => setInstallModalOpen(false)}
      />

      {/* Manage Venues Modal (Admin / Boss only) */}
      <ManageVenuesModal
        isOpen={manageVenuesModalOpen}
        onClose={() => setManageVenuesModalOpen(false)}
        venues={venues}
        onSaveVenues={handleSaveVenues}
        onNotify={showToast}
      />

      {/* Approvals Modal (Admin / Boss only) */}
      <ApprovalsModal
        isOpen={approvalsModalOpen}
        onClose={() => setApprovalsModalOpen(false)}
        approvals={pendingApprovals}
        venues={venues}
        onApprove={handleApproveApproval}
        onReject={handleRejectApproval}
      />

      {/* Push Notifications Settings Modal */}
      <PushSettingsModal
        isOpen={pushModalOpen}
        onClose={() => setPushModalOpen(false)}
        currentUser={currentUser}
        onUpdateUser={handleUpdateUser}
        onNotify={showToast}
      />
    </div>
  );
}
