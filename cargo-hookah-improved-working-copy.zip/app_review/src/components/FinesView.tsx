import React, { useState, useMemo } from 'react';
import { UserAccount, EmployeeFine, VenueId } from '../types';
import { VENUES } from '../data/initialData';
import { formatDate } from '../utils/dateUtils';
import { 
  AlertOctagon, 
  Plus, 
  Trash2, 
  Calendar, 
  User, 
  FileText, 
  Building2, 
  CheckCircle2,
  AlertTriangle,
  Receipt,
  X,
  TrendingDown,
  Info
} from 'lucide-react';

interface FinesViewProps {
  fines: EmployeeFine[];
  users: UserAccount[];
  currentUser: UserAccount;
  onAddFine: (fineData: Omit<EmployeeFine, 'id' | 'createdAt'>) => void;
  onDeleteFine: (fineId: string) => void;
  onNotify: (msg: string) => void;
}

const PRESET_REASONS = [
  'Закъснение за смяна (над 30 мин)',
  'Счупена ваза или чашка за наргиле',
  'Липса на оборот / несъответствие в касата',
  'Непочистени наргилета и шахти в края на смяната',
  'Неизвинено отсъствие / неявяване на смяна',
  'Забравен невключен или непочистен котлон за въглени',
  'Непопълнен или некоректен отчет в приложението',
  'Нарушение на стандартите за обслужване в заведението',
];

export const FinesView: React.FC<FinesViewProps> = ({
  fines,
  users,
  currentUser,
  onAddFine,
  onDeleteFine,
  onNotify,
}) => {
  const isBossOrAdmin = currentUser.role === 'boss' || currentUser.role === 'admin';

  // RBAC Access Control Check
  if (!isBossOrAdmin) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center max-w-lg mx-auto space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center justify-center mx-auto">
          <AlertOctagon className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-black text-white">Ограничен достъп</h3>
        <p className="text-xs text-slate-400 leading-relaxed">
          Модул „Глоби“ е достъпен само за Управител (Шеф) и Администратори.
        </p>
      </div>
    );
  }

  const isBoss = currentUser.role === 'boss';

  // Add fine form state
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedStaffId, setSelectedStaffId] = useState<string>(() => {
    const firstEmp = users.find((u) => u.role !== 'boss');
    return firstEmp ? firstEmp.id : (users[0]?.id || '');
  });
  const [fineAmount, setFineAmount] = useState<number>(10);
  const [fineDate, setFineDate] = useState<string>(() => formatDate(new Date()));
  const [fineVenueId, setFineVenueId] = useState<VenueId | ''>('bar-hey');
  const [fineReason, setFineReason] = useState<string>('');

  // Filters
  const [filterStaffId, setFilterStaffId] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<string>('');

  // Filtered fines
  const filteredFines = useMemo(() => {
    return fines.filter((f) => {
      if (filterStaffId !== 'all' && f.staffId !== filterStaffId) return false;
      if (filterMonth && !f.date.startsWith(filterMonth)) return false;
      return true;
    });
  }, [fines, filterStaffId, filterMonth]);

  const totalDeductedEur = useMemo(() => {
    return filteredFines.reduce((sum, f) => sum + (Number(f.amountEur) || 0), 0);
  }, [filteredFines]);

  const handleSubmitNewFine = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStaffId) {
      onNotify('Моля изберете служител!');
      return;
    }
    if (!fineReason.trim()) {
      onNotify('Моля въведете подробно описание / причина за глобата!');
      return;
    }
    if (fineAmount <= 0) {
      onNotify('Размерът на глобата трябва да бъде по-голям от 0!');
      return;
    }

    const staffObj = users.find((u) => u.id === selectedStaffId);
    const staffName = staffObj?.name || 'Служител';

    onAddFine({
      staffId: selectedStaffId,
      staffName,
      amountEur: Number(fineAmount),
      date: fineDate,
      venueId: fineVenueId ? (fineVenueId as VenueId) : undefined,
      reason: fineReason.trim(),
      issuedBy: currentUser.name,
    });

    setFineReason('');
    setFineAmount(10);
    setShowAddForm(false);
    onNotify(`Наложена е глоба от ${fineAmount} € на ${staffName}. Сумата директно ще се удържи от заплатата му.`);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center shrink-0 shadow-lg shadow-rose-500/10">
            <AlertOctagon className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-black text-white">
                {isBoss ? 'Глоби & Удръжки' : 'Моите Глоби & Удръжки'}
              </h2>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
                {filteredFines.length} {filteredFines.length === 1 ? 'глоба' : 'глоби'}
              </span>
            </div>
          </div>
        </div>

        {/* Action button */}
        {isBoss && (
          <button
            type="button"
            onClick={() => setShowAddForm(!showAddForm)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs transition-all shadow-lg active:scale-95 shrink-0 ${
              showAddForm
                ? 'bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700'
                : 'bg-gradient-to-r from-rose-600 via-rose-500 to-rose-600 hover:from-rose-500 hover:to-rose-500 text-white shadow-rose-500/25 border border-rose-400/30'
            }`}
          >
            {showAddForm ? (
              <>
                <X className="w-4 h-4" />
                <span>Затвори формата</span>
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                <span>+ Наложи глоба на служител</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Summary Box */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider">
            {isBoss ? 'Общо удържани глоби' : 'Мои удържани глоби'}
          </span>
          <div className="text-2xl font-black text-rose-400 mt-1 flex items-baseline gap-2">
            <span>-{totalDeductedEur.toFixed(2)} €</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider">
            Брой наложени глоби
          </span>
          <div className="text-2xl font-black text-white mt-1">
            {filteredFines.length} <span className="text-xs font-normal text-slate-400">бр.</span>
          </div>
        </div>
      </div>

      {/* Form to add fine (Boss only) */}
      {isBoss && showAddForm && (
        <form onSubmit={handleSubmitNewFine} className="bg-slate-900 border border-rose-500/40 rounded-3xl p-5 sm:p-6 space-y-4 shadow-2xl animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
              <AlertTriangle className="w-5 h-5" />
              <span>Налагане на глоба</span>
            </div>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              ✕ Отказ
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Employee Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Служител *
              </label>
              <select
                value={selectedStaffId}
                onChange={(e) => setSelectedStaffId(e.target.value)}
                required
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-rose-500"
              >
                {users.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role === 'boss' ? 'Шеф' : 'Служител'})
                  </option>
                ))}
              </select>
            </div>

            {/* Amount in EUR */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Сума (€) *
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="1"
                  step="1"
                  required
                  value={fineAmount}
                  onChange={(e) => setFineAmount(Math.max(1, parseFloat(e.target.value) || 0))}
                  className="w-full bg-slate-950 border border-slate-700 text-rose-400 font-black rounded-xl px-3 py-2 text-sm focus:outline-none focus:border-rose-500"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                  €
                </span>
              </div>
            </div>

            {/* Date */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Дата *
              </label>
              <input
                type="date"
                required
                value={fineDate}
                onChange={(e) => setFineDate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-rose-500"
              />
            </div>

            {/* Venue */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Заведение
              </label>
              <select
                value={fineVenueId}
                onChange={(e) => setFineVenueId(e.target.value as VenueId | '')}
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-rose-500"
              >
                <option value="">(Общо)</option>
                {VENUES.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Reason / Description */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Причина *
            </label>
            <textarea
              rows={2}
              required
              value={fineReason}
              onChange={(e) => setFineReason(e.target.value)}
              placeholder="Причина за глобата..."
              className="w-full bg-slate-950 border border-slate-700 text-white rounded-2xl p-3 text-xs focus:outline-none focus:border-rose-500 placeholder:text-slate-600"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold rounded-xl"
            >
              Отказ
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-bold text-xs rounded-xl shadow-lg shadow-rose-500/20 transition-all active:scale-95 flex items-center gap-2"
            >
              <TrendingDown className="w-4 h-4" />
              <span>Потвърди и удръж от заплатата</span>
            </button>
          </div>
        </form>
      )}

      {/* Filter Toolbar */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          {isBoss && (
            <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800">
              <User className="w-4 h-4 text-slate-400" />
              <select
                value={filterStaffId}
                onChange={(e) => setFilterStaffId(e.target.value)}
                className="bg-transparent text-white font-semibold text-xs focus:outline-none"
              >
                <option value="all" className="bg-slate-900 text-white">Всички служители</option>
                {users.map((u) => (
                  <option key={u.id} value={u.id} className="bg-slate-900 text-white">
                    {u.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="flex items-center gap-2 bg-slate-950 px-3 py-2 rounded-xl border border-slate-800">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input
              type="month"
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
              className="bg-transparent text-white font-semibold text-xs focus:outline-none"
            />
            {filterMonth && (
              <button
                type="button"
                onClick={() => setFilterMonth('')}
                className="text-xs text-slate-400 hover:text-white"
                title="Изчисти филтъра за месец"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        <div className="text-xs text-slate-400">
          Намерени: <span className="font-bold text-white">{filteredFines.length}</span> наложени глоби
        </div>
      </div>

      {/* Fines List with detailed description underneath */}
      <div className="space-y-3">
        {filteredFines.length === 0 ? (
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-white">Няма регистрирани глоби</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              {isBoss
                ? 'Няма наложени глоби за избрания период или служител.'
                : 'Нямате наложени глоби. Продължавайте добрата работа!'}
            </p>
          </div>
        ) : (
          filteredFines.map((fine) => {
            const venueObj = VENUES.find((v) => v.id === fine.venueId);
            const fineStaff = users.find((u) => u.id === fine.staffId);

            return (
              <div
                key={fine.id}
                className="bg-slate-900 border border-slate-800 hover:border-rose-500/40 rounded-3xl p-5 transition-all shadow-md space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  {/* Staff and meta */}
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${fineStaff?.avatarColor || 'bg-slate-800 text-white'} flex items-center justify-center font-bold text-sm shrink-0`}>
                      {fine.staffName.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-bold text-white">
                          {fine.staffName}
                        </span>
                        <span className="text-xs text-slate-400">
                          • Дата: {fine.date}
                        </span>
                        {venueObj && (
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${venueObj.themeColor.badgeBg}`}>
                            {venueObj.name}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500">
                        Наложена от: <span className="text-slate-300 font-semibold">{fine.issuedBy || 'Шеф'}</span>
                      </p>
                    </div>
                  </div>

                  {/* Fine Amount & Boss Actions */}
                  <div className="flex items-center justify-between sm:justify-end gap-4 shrink-0">
                    <div className="text-right">
                      <div className="text-xl font-black text-rose-400">
                        -{fine.amountEur.toFixed(2)} €
                      </div>
                    </div>

                    {isBoss && (
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Сигурни ли сте, че искате да отмените глобата от ${fine.amountEur} € за ${fine.staffName}?`)) {
                            onDeleteFine(fine.id);
                          }
                        }}
                        className="p-2 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors"
                        title="Отмени / Изтрий глобата"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Detailed Description Box Underneath */}
                <div className="bg-slate-950/80 border border-rose-500/20 rounded-2xl p-3.5 text-xs">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 block mb-1">
                    За какво бива глобен:
                  </span>
                  <p className="text-slate-200 font-medium leading-relaxed">
                    "{fine.reason}"
                  </p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
