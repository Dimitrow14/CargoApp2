import React, { useState, useEffect } from 'react';

interface CargoLogoProps {
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  rounded?: boolean;
  customLogo?: string | null;
}

export const CargoLogo: React.FC<CargoLogoProps> = ({
  className = '',
  size = 'md',
  rounded = false,
  customLogo,
}) => {
  const [cachedLogo, setCachedLogo] = useState<string | null>(() => {
    if (customLogo) return customLogo;
    if (typeof window !== 'undefined') {
      return localStorage.getItem('hookah_custom_logo');
    }
    return null;
  });

  useEffect(() => {
    if (customLogo) {
      setCachedLogo(customLogo);
    }
  }, [customLogo]);

  useEffect(() => {
    const handleLogoUpdate = () => {
      const stored = localStorage.getItem('hookah_custom_logo');
      if (stored) {
        setCachedLogo(stored);
      }
    };

    window.addEventListener('storage', handleLogoUpdate);
    window.addEventListener('hookah_logo_updated', handleLogoUpdate);

    return () => {
      window.removeEventListener('storage', handleLogoUpdate);
      window.removeEventListener('hookah_logo_updated', handleLogoUpdate);
    };
  }, []);

  const sizeClasses = {
    xs: 'w-6 h-6',
    sm: 'w-8 h-8',
    md: 'w-11 h-11',
    lg: 'w-16 h-16 sm:w-20 sm:h-20',
    xl: 'w-24 h-24 sm:w-28 sm:h-28',
    '2xl': 'w-32 h-32 sm:w-36 sm:h-36',
  };

  const roundedClass = rounded ? 'rounded-2xl' : 'rounded-none';
  const logoSrc = cachedLogo || customLogo || '/cargo-hookah-logo.svg';

  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 overflow-hidden mx-auto ${sizeClasses[size]} ${roundedClass} ${className}`}
    >
      <img
        src={logoSrc}
        alt="Cargo Hookah Logo"
        className="w-full h-full object-contain block mx-auto select-none"
        loading="eager"
        decoding="sync"
        onError={(e) => {
          // Fallback to high-res PNG if SVG encounters any browser issue
          const img = e.currentTarget as HTMLImageElement;
          if (img.src !== window.location.origin + '/pwa-512x512.png') {
            img.src = '/pwa-512x512.png';
          }
        }}
      />
    </div>
  );
};

