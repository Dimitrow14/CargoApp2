import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  deleteDoc,
  collection,
  query,
  where,
  orderBy,
  limit,
  getDocs,
  onSnapshot, 
  getDocFromServer,
  Firestore 
} from 'firebase/firestore';
import type { AppState } from './utils/storage';
import type { 
  PendingApproval, 
  DailyRevision, 
  ClockInRecord, 
  Venue, 
  Shift, 
  ShiftReport, 
  EmployeeFine, 
  VenueInventory 
} from './types';
import firebaseConfig from '../firebase-applet-config.json';

// Skill-mandated error handling types and helper
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const currentAuthUser = auth?.currentUser;
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: currentAuthUser?.uid,
      email: currentAuthUser?.email,
      emailVerified: currentAuthUser?.emailVerified,
      isAnonymous: currentAuthUser?.isAnonymous,
      tenantId: currentAuthUser?.tenantId,
      providerInfo: currentAuthUser?.providerData?.map((p) => ({
        providerId: p.providerId,
        email: p.email,
      })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Firestore with custom database ID if specified
export const db: Firestore = firebaseConfig.firestoreDatabaseId 
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

// Initialize Firebase Auth
export const auth: Auth = getAuth(app);

// Test Firestore connection on boot (as strictly required by Firebase integration guidelines)
export async function testConnection(): Promise<boolean> {
  const path = 'test/connection';
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('✅ Firebase Cloud Database (Firestore) connected successfully.');
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client appears offline, check network/configuration.');
      return false;
    }
    // Document not existing is completely normal and indicates a successful server response
    return true;
  }
}

// Run connection check immediately on module import
testConnection().catch((err) => console.warn('testConnection error:', err));

// Document reference for central persistent cloud state
const SYSTEM_STATE_DOC = doc(db, 'system_state', 'active');
const SYSTEM_STATE_PATH = 'system_state/active';

/**
 * Save complete application state to Firestore for permanent persistence.
 * Never resets on browser close, tab close, or device restart.
 */
export async function saveStateToFirestore(state: AppState): Promise<boolean> {
  try {
    await setDoc(SYSTEM_STATE_DOC, {
      ...state,
      lastModified: Date.now(),
      _cloudPersistent: true,
    }, { merge: true });
    return true;
  } catch (err) {
    console.error('Error saving state to Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, SYSTEM_STATE_PATH);
    } catch {}
    return false;
  }
}

/**
 * Load authoritative state from Firestore cloud database.
 */
export async function loadStateFromFirestore(): Promise<AppState | null> {
  try {
    const snap = await getDoc(SYSTEM_STATE_DOC);
    if (snap.exists()) {
      const data = snap.data();
      if (data && Array.isArray(data.users)) {
        return data as AppState;
      }
    }
  } catch (err) {
    console.error('Error loading state from Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.GET, SYSTEM_STATE_PATH);
    } catch {}
  }
  return null;
}

/**
 * Subscribe to real-time changes in Firestore across all devices and phones.
 * When any employee or boss makes an update, all other devices receive it instantly!
 */
export function subscribeToFirestoreState(
  onUpdate: (state: AppState) => void
): () => void {
  try {
    const unsubscribe = onSnapshot(
      SYSTEM_STATE_DOC,
      (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data && Array.isArray(data.users)) {
            onUpdate(data as AppState);
          }
        }
      },
      (error) => {
        console.warn('Firestore snapshot subscription warning:', error);
      }
    );
    return unsubscribe;
  } catch (err) {
    console.error('Failed to setup Firestore real-time listener:', err);
    return () => {};
  }
}

/**
 * Save a breakage/damage approval request directly to /pending_approvals/{id}
 */
export async function savePendingApprovalToFirestore(approval: PendingApproval): Promise<boolean> {
  const path = `pending_approvals/${approval.id}`;
  try {
    await setDoc(doc(db, 'pending_approvals', approval.id), {
      ...approval,
      _savedAt: Date.now(),
    });
    return true;
  } catch (err) {
    console.error('Error saving pending approval to Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, path);
    } catch {}
    return false;
  }
}

/**
 * Save an employee clock-in record directly to /clock_ins/{id}
 */
export async function saveClockInToFirestore(clockIn: ClockInRecord): Promise<boolean> {
  const path = `clock_ins/${clockIn.id}`;
  try {
    await setDoc(doc(db, 'clock_ins', clockIn.id), {
      ...clockIn,
      _savedAt: Date.now(),
    });
    return true;
  } catch (err) {
    console.error('Error saving clock in to Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, path);
    } catch {}
    return false;
  }
}

/**
 * Save a daily revision report directly to /revisions/{id}
 */
export async function saveRevisionToFirestore(revision: DailyRevision): Promise<boolean> {
  const path = `revisions/${revision.id}`;
  try {
    await setDoc(doc(db, 'revisions', revision.id), {
      ...revision,
      _savedAt: Date.now(),
    });
    return true;
  } catch (err) {
    console.error('Error saving revision to Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, path);
    } catch {}
    return false;
  }
}

/**
 * Save / Update an individual shift document in Firestore (e.g. clock-in status isClockedIn: true)
 */
export async function saveShiftToFirestore(shift: Shift): Promise<boolean> {
  const path = `shifts/${shift.id}`;
  try {
    await setDoc(doc(db, 'shifts', shift.id), {
      ...shift,
      _savedAt: Date.now(),
    }, { merge: true });
    return true;
  } catch (err) {
    console.error('Error saving shift to Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, path);
    } catch {}
    return false;
  }
}

/**
 * Delete a shift document directly from Firestore
 */
export async function deleteShiftFromFirestore(shiftId: string): Promise<boolean> {
  const path = `shifts/${shiftId}`;
  try {
    await deleteDoc(doc(db, 'shifts', shiftId));
    return true;
  } catch (err) {
    console.error('Error deleting shift from Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.DELETE, path);
    } catch {}
    return false;
  }
}

/**
 * Save a shift report document directly to /reports/{id}
 */
export async function saveReportToFirestore(report: ShiftReport): Promise<boolean> {
  const path = `reports/${report.id}`;
  try {
    await setDoc(doc(db, 'reports', report.id), {
      ...report,
      _savedAt: Date.now(),
    }, { merge: true });
    return true;
  } catch (err) {
    console.error('Error saving report to Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, path);
    } catch {}
    return false;
  }
}

/**
 * Delete a shift report document directly from Firestore
 */
export async function deleteReportFromFirestore(reportId: string): Promise<boolean> {
  const path = `reports/${reportId}`;
  try {
    await deleteDoc(doc(db, 'reports', reportId));
    return true;
  } catch (err) {
    console.error('Error deleting report from Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.DELETE, path);
    } catch {}
    return false;
  }
}

/**
 * Save an employee fine document directly to /fines/{id}
 */
export async function saveFineToFirestore(fine: EmployeeFine): Promise<boolean> {
  const path = `fines/${fine.id}`;
  try {
    await setDoc(doc(db, 'fines', fine.id), {
      ...fine,
      _savedAt: Date.now(),
    }, { merge: true });
    return true;
  } catch (err) {
    console.error('Error saving fine to Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, path);
    } catch {}
    return false;
  }
}

/**
 * Delete an employee fine document directly from Firestore
 */
export async function deleteFineFromFirestore(fineId: string): Promise<boolean> {
  const path = `fines/${fineId}`;
  try {
    await deleteDoc(doc(db, 'fines', fineId));
    return true;
  } catch (err) {
    console.error('Error deleting fine from Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.DELETE, path);
    } catch {}
    return false;
  }
}

/**
 * Save venue inventory directly to /inventories/{venueId}
 */
export async function saveInventoryToFirestore(venueId: string, inventory: VenueInventory): Promise<boolean> {
  const path = `inventories/${venueId}`;
  try {
    await setDoc(doc(db, 'inventories', venueId), {
      ...inventory,
      _savedAt: Date.now(),
    }, { merge: true });
    return true;
  } catch (err) {
    console.error('Error saving inventory to Firestore:', err);
    try {
      handleFirestoreError(err, OperationType.WRITE, path);
    } catch {}
    return false;
  }
}

/**
 * Fetch the most recent completed daily revision/shift report for an exact venue.
 * Runs a Firestore query ordered by timestamp descending, limit 1.
 * Returns the latest revision document, or null if none found.
 */
export async function fetchLatestCompletedRevisionForVenue(venueId: string): Promise<DailyRevision | null> {
  // 1. Query Firestore revisions collection (ordered by createdAt desc, limit 1)
  try {
    const q = query(
      collection(db, 'revisions'),
      where('venueId', '==', venueId),
      orderBy('createdAt', 'desc'),
      limit(1)
    );
    const snap = await getDocs(q);
    if (!snap.empty) {
      return snap.docs[0].data() as DailyRevision;
    }
  } catch (err) {
    console.warn('Composite query on revisions failed, attempting fallback query by venueId:', err);
    try {
      const qFallback = query(
        collection(db, 'revisions'),
        where('venueId', '==', venueId)
      );
      const snapFallback = await getDocs(qFallback);
      if (!snapFallback.empty) {
        const revs = snapFallback.docs.map((d) => d.data() as DailyRevision);
        revs.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        return revs[0];
      }
    } catch (fallbackErr) {
      console.warn('Fallback query on revisions collection failed:', fallbackErr);
    }
  }

  // 2. Query Firestore reports collection for any linked or embedded tobacco details
  try {
    const qReports = query(
      collection(db, 'reports'),
      where('venueId', '==', venueId)
    );
    const repSnap = await getDocs(qReports);
    if (!repSnap.empty) {
      const reps = repSnap.docs.map((d) => d.data() as any);
      reps.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      const latestRep = reps[0];
      if (latestRep?.revisionId) {
        // Fetch the linked revision
        const revDoc = await getDoc(doc(db, 'revisions', latestRep.revisionId));
        if (revDoc.exists()) {
          return revDoc.data() as DailyRevision;
        }
      }
    }
  } catch (repErr) {
    console.warn('Querying reports collection for linked revision failed:', repErr);
  }

  // 3. Fallback from system_state doc in Firestore
  try {
    const stateSnap = await getDoc(SYSTEM_STATE_DOC);
    if (stateSnap.exists()) {
      const data = stateSnap.data() as AppState;
      if (Array.isArray(data.revisions)) {
        const matching = data.revisions
          .filter((r) => r.venueId === venueId)
          .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        if (matching.length > 0) {
          return matching[0];
        }
      }
    }
  } catch (e) {
    console.warn('Fallback error fetching latest revision:', e);
  }

  return null;
}


