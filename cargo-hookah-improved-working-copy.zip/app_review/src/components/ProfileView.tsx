import React, { useState, useMemo, useCallback } from 'react';
import { 
  UserAccount, 
  UserPermissions,
  ShiftReport, 
  Shift, 
  VenueId, 
  VenuePricing,
  WageSettings,
  EmployeeFine
} from '../types';
import { VENUES, DEFAULT_VENUE_PRICING } from '../data/initialData';
import { PricingModal } from './PricingModal';
import { FinesModal } from './FinesModal';
import { 
  User, 
  Euro, 
  Calendar, 
  TrendingUp, 
  Flame, 
  Clock, 
  Filter, 
  QrCode, 
  Settings, 
  Copy, 
  Check, 
  Building2, 
  BarChart3, 
  PieChart, 
  DollarSign, 
  Percent, 
  Phone, 
  FileText, 
  ArrowUpRight, 
  ChevronRight, 
  Sparkles, 
  Award, 
  Wallet, 
  Edit2, 
  KeyRound, 
  X, 
  Coins, 
  AlertOctagon, 
  Trash2, 
  Users,
  ShieldCheck,
  Bell
} from 'lucide-react';

interface ProfileViewProps {
  currentUser: UserAccount;
  allUsers: UserAccount[];
  reports: ShiftReport[];
  shifts: Shift[];
  pricing: Record<VenueId, VenuePricing>;
  wageSettings?: WageSettings;
  fines?: EmployeeFine[];
  onUpdatePricing: (pricing: Record<VenueId, VenuePricing>) => void;
  onUpdateWageSettings?: (newSettings: WageSettings, updatedUsers?: UserAccount[]) => void;
  onUpdateUser?: (user: UserAccount) => void;
  onAddFine?: (fine: Omit<EmployeeFine, 'id' | 'createdAt'>) => void;
  onDeleteFine?: (fineId: string) => void;
  onOpenInstallModal?: () => void;
  onOpenPushModal?: () => void;
  onNotify: (msg: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  currentUser,
  allUsers,
  reports,
  shifts,
  pricing,
  wageSettings,
  fines = [],
  onUpdatePricing,
  onUpdateWageSettings,
  onUpdateUser,
  onAddFine,
  onDeleteFine,
  onOpenInstallModal,
  onOpenPushModal,
  onNotify,
}) => {
  const isBoss = currentUser.role === 'boss';

  // Active base rates (defaults: 23 € nadnik + 1 € hookah)
  const baseWageRate = wageSettings?.baseWageEur ?? 23;
  const hookahBonusRate = wageSettings?.hookahRateEur ?? 1;
  const currencySymbol = wageSettings?.currency || '€';

  // Wage Settings Modal state (boss only)
  const [wageModalOpen, setWageModalOpen] = useState(false);
  const [inputBaseWage, setInputBaseWage] = useState<number>(baseWageRate);
  const [inputHookahRate, setInputHookahRate] = useState<number>(hookahBonusRate);
  const [inputCurrency, setInputCurrency] = useState<string>(currencySymbol);
  // Personalized rates per employee in wage modal: userId -> { baseWage: string; hookahRate: string }
  const [employeeRatesMap, setEmployeeRatesMap] = useState<Record<string, { baseWage: string; hookahRate: string }>>({});

  // State
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    const now = new Date();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    return `${now.getFullYear()}-${m}`;
  });
  const [filterAllTime, setFilterAllTime] = useState(false);
  const [pricingModalOpen, setPricingModalOpen] = useState(false);
  const [selectedStaffId, setSelectedStaffId] = useState<string>(currentUser.id);
  const [copiedPayroll, setCopiedPayroll] = useState(false);
  const [analyticsVenueFilter, setAnalyticsVenueFilter] = useState<'all' | VenueId>('all');

  // Edit profile state (allows boss to rename 'boss' to anything, change PIN, etc.)
  const [editProfileOpen, setEditProfileOpen] = useState(false);
  const [editName, setEditName] = useState(currentUser.name);
  const [editPin, setEditPin] = useState(currentUser.pin);
  const [editPhone, setEditPhone] = useState(currentUser.phone || '');
  const [editAvatarColor, setEditAvatarColor] = useState(currentUser.avatarColor);

  const colorOptions = [
    'bg-amber-500 text-slate-950',
    'bg-cyan-500 text-slate-950',
    'bg-emerald-500 text-slate-950',
    'bg-violet-500 text-white',
    'bg-rose-500 text-white',
    'bg-blue-600 text-white',
    'bg-indigo-600 text-white',
    'bg-fuchsia-600 text-white',
  ];

  const handleOpenEditProfile = () => {
    setEditName(currentUser.name);
    setEditPin(currentUser.pin);
    setEditPhone(currentUser.phone || '');
    setEditAvatarColor(currentUser.avatarColor);
    setEditProfileOpen(true);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editName.trim() || !editPin.trim()) {
      onNotify('Моля въведете валидно име и парола / PIN!');
      return;
    }

    const updatedUser: UserAccount = {
      ...currentUser,
      name: editName.trim(),
      pin: editPin.trim(),
      phone: editPhone.trim() || undefined,
      avatarColor: editAvatarColor,
    };

    onUpdateUser?.(updatedUser);
    setEditProfileOpen(false);
    onNotify(`Профилът бе успешно обновен! Име: ${updatedUser.name}`);
  };

  const handleTogglePermission = (targetUser: UserAccount, permKey: keyof UserPermissions) => {
    const isUserBoss = targetUser.role === 'boss';
    const currentPerms = targetUser.permissions || {
      canManageSchedule: true,
      canManageInventory: true,
      canManageReports: true,
      canViewFinances: isUserBoss,
      canManageFines: isUserBoss,
    };
    const updatedUser: UserAccount = {
      ...targetUser,
      permissions: {
        ...currentPerms,
        [permKey]: !currentPerms[permKey],
      },
    };
    onUpdateUser?.(updatedUser);
    onNotify(`Обновени права за ${targetUser.name}`);
  };

  // Filtered reports by month/all-time
  const periodReports = useMemo(() => {
    if (filterAllTime) return reports;
    return reports.filter((r) => r.date.startsWith(selectedMonth));
  }, [reports, selectedMonth, filterAllTime]);

  // Filtered shifts by month/all-time
  const periodShifts = useMemo(() => {
    if (filterAllTime) return shifts;
    return shifts.filter((s) => s.date.startsWith(selectedMonth));
  }, [shifts, selectedMonth, filterAllTime]);

  // Filtered fines by month/all-time
  const periodFines = useMemo(() => {
    if (!fines) return [];
    if (filterAllTime) return fines;
    return fines.filter((f) => f.date.startsWith(selectedMonth));
  }, [fines, selectedMonth, filterAllTime]);

  // Helper to get pricing for venue
  const getVenuePrice = (vId: VenueId) => {
    return pricing[vId] || DEFAULT_VENUE_PRICING[vId] || {
      venueId: vId,
      yellowPriceEur: 15,
      blackPriceEur: 18,
      officialPriceEur: 0,
    };
  };

  // 1. Business Turnover & Venue Analytics Calculation
  const venueAnalytics = useMemo(() => {
    const stats: Record<VenueId, {
      venueId: VenueId;
      name: string;
      reportsCount: number;
      totalHookahs: number;
      yellowCount: number;
      blackCount: number;
      officialCount: number;
      revenueEur: number;
      staffCostEur: number;
      netProfitEur: number;
      marginPercent: number;
    }> = {
      'bar-hey': {
        venueId: 'bar-hey',
        name: 'Бар хей',
        reportsCount: 0,
        totalHookahs: 0,
        yellowCount: 0,
        blackCount: 0,
        officialCount: 0,
        revenueEur: 0,
        staffCostEur: 0,
        netProfitEur: 0,
        marginPercent: 0,
      },
      'zero-zero': {
        venueId: 'zero-zero',
        name: 'Зеро Зеро',
        reportsCount: 0,
        totalHookahs: 0,
        yellowCount: 0,
        blackCount: 0,
        officialCount: 0,
        revenueEur: 0,
        staffCostEur: 0,
        netProfitEur: 0,
        marginPercent: 0,
      },
      'de-rouge': {
        venueId: 'de-rouge',
        name: 'Бар Де Руж',
        reportsCount: 0,
        totalHookahs: 0,
        yellowCount: 0,
        blackCount: 0,
        officialCount: 0,
        revenueEur: 0,
        staffCostEur: 0,
        netProfitEur: 0,
        marginPercent: 0,
      },
    };

    periodReports.forEach((report) => {
      const vId = report.venueId;
      const vPrices = getVenuePrice(vId);

      const yellow = Number(report.yellowHookahs) || 0;
      const black = Number(report.blackHookahs) || 0;
      const official = report.isOfficialComplimentary
        ? Number(report.officialHookahsCount) || 1
        : 0;

      // Calculate Turnover for this report based on venue prices
      const reportTurnover =
        yellow * vPrices.yellowPriceEur +
        black * vPrices.blackPriceEur +
        official * vPrices.officialPriceEur;

      const reportStaffCost = Number(report.totalEarnedEur) || (baseWageRate + (yellow + black + official) * hookahBonusRate);

      if (stats[vId]) {
        stats[vId].reportsCount += 1;
        stats[vId].totalHookahs += report.totalHookahs;
        stats[vId].yellowCount += yellow;
        stats[vId].blackCount += black;
        stats[vId].officialCount += official;
        stats[vId].revenueEur += reportTurnover;
        stats[vId].staffCostEur += reportStaffCost;
      }
    });

    // Compute margins
    Object.keys(stats).forEach((vKey) => {
      const s = stats[vKey as VenueId];
      s.netProfitEur = s.revenueEur - s.staffCostEur;
      s.marginPercent = s.revenueEur > 0 ? (s.netProfitEur / s.revenueEur) * 100 : 0;
    });

    return stats;
  }, [periodReports, pricing, baseWageRate, hookahBonusRate]);

  // Overall Business Totals
  const businessTotals = useMemo(() => {
    let totalRevenueEur = 0;
    let totalStaffCostEur = 0;
    let totalHookahs = 0;
    let totalYellow = 0;
    let totalBlack = 0;
    let totalOfficial = 0;
    let totalReports = 0;

    Object.values(venueAnalytics).forEach((v) => {
      totalRevenueEur += v.revenueEur;
      totalStaffCostEur += v.staffCostEur;
      totalHookahs += v.totalHookahs;
      totalYellow += v.yellowCount;
      totalBlack += v.blackCount;
      totalOfficial += v.officialCount;
      totalReports += v.reportsCount;
    });

    const netProfitEur = totalRevenueEur - totalStaffCostEur;
    const marginPercent = totalRevenueEur > 0 ? (netProfitEur / totalRevenueEur) * 100 : 0;

    return {
      totalRevenueEur,
      totalStaffCostEur,
      netProfitEur,
      marginPercent,
      totalHookahs,
      totalYellow,
      totalBlack,
      totalOfficial,
      totalReports,
    };
  }, [venueAnalytics]);

  // 2. Staff Payroll Calculation (Готови заплати на всеки служител)
  const staffPayrollList = useMemo(() => {
    return allUsers.map((user) => {
      const userReps = periodReports.filter((r) => r.staffId === user.id);
      const shiftsCount = userReps.length;
      const totalHookahs = userReps.reduce((sum, r) => sum + (Number(r.totalHookahs) || 0), 0);
      const yellowHookahs = userReps.reduce((sum, r) => sum + (Number(r.yellowHookahs) || 0), 0);
      const blackHookahs = userReps.reduce((sum, r) => sum + (Number(r.blackHookahs) || 0), 0);
      const officialHookahs = userReps.reduce(
        (sum, r) => sum + (r.isOfficialComplimentary ? Number(r.officialHookahsCount) || 1 : 0),
        0
      );

      // Personalized rates per employee or fallback to company default
      const userBaseRate = (typeof user.customBaseWageEur === 'number' && user.customBaseWageEur >= 0)
        ? user.customBaseWageEur
        : baseWageRate;
      const userHookahRate = (typeof user.customHookahRateEur === 'number' && user.customHookahRateEur >= 0)
        ? user.customHookahRateEur
        : hookahBonusRate;
      const hasCustomRates = (typeof user.customBaseWageEur === 'number' && user.customBaseWageEur >= 0) ||
                             (typeof user.customHookahRateEur === 'number' && user.customHookahRateEur >= 0);

      const baseWageEur = shiftsCount * userBaseRate;
      const hookahBonusEur = totalHookahs * userHookahRate;
      const grossPayoutEur = baseWageEur + hookahBonusEur;

      // Fines for this user in selected period
      const userFines = periodFines.filter((f) => f.staffId === user.id);
      const totalFinesEur = userFines.reduce((sum, f) => sum + (Number(f.amountEur) || 0), 0);

      // Net salary directly reflects deducted fines
      const totalPayoutEur = Math.max(0, grossPayoutEur - totalFinesEur);

      return {
        user,
        shiftsCount,
        totalHookahs,
        yellowHookahs,
        blackHookahs,
        officialHookahs,
        userBaseRate,
        userHookahRate,
        hasCustomRates,
        baseWageEur,
        hookahBonusEur,
        grossPayoutEur,
        userFines,
        totalFinesEur,
        totalPayoutEur,
      };
    });
  }, [allUsers, periodReports, periodFines, baseWageRate, hookahBonusRate]);

  // Total payout to all staff
  const totalPayrollPayoutEur = useMemo(() => {
    return staffPayrollList.reduce((sum, p) => sum + p.totalPayoutEur, 0);
  }, [staffPayrollList]);

  // Open Wage Modal & populate employee custom rates
  const handleOpenWageModal = () => {
    setInputBaseWage(baseWageRate);
    setInputHookahRate(hookahBonusRate);
    setInputCurrency(currencySymbol);

    const initialRates: Record<string, { baseWage: string; hookahRate: string }> = {};
    allUsers.forEach((u) => {
      initialRates[u.id] = {
        baseWage: u.customBaseWageEur !== undefined ? String(u.customBaseWageEur) : '',
        hookahRate: u.customHookahRateEur !== undefined ? String(u.customHookahRateEur) : '',
      };
    });
    setEmployeeRatesMap(initialRates);
    setWageModalOpen(true);
  };

  // Helper to persist wage settings & personalized employee rates immediately across all devices
  const persistWageAndRates = useCallback((
    baseVal: number,
    rateVal: number,
    currVal: string,
    ratesMap: Record<string, { baseWage: string; hookahRate: string }>
  ) => {
    if (!onUpdateWageSettings) return;
    const base = Number(baseVal) >= 0 ? Number(baseVal) : 23;
    const rate = Number(rateVal) >= 0 ? Number(rateVal) : 1;

    const updatedUsers = allUsers.map((u) => {
      const empRates = ratesMap[u.id];
      if (!empRates) return u;
      const newBase = empRates.baseWage.trim() !== '' ? Math.max(0, Number(empRates.baseWage)) : undefined;
      const newHookah = empRates.hookahRate.trim() !== '' ? Math.max(0, Number(empRates.hookahRate)) : undefined;
      return {
        ...u,
        customBaseWageEur: newBase,
        customHookahRateEur: newHookah,
      };
    });

    onUpdateWageSettings({
      baseWageEur: base,
      hookahRateEur: rate,
      currency: currVal,
      updatedAt: Date.now(),
      updatedBy: currentUser.name,
    }, updatedUsers);
  }, [allUsers, currentUser.name, onUpdateWageSettings]);

  // Save updated wage settings & personalized employee rates immediately (boss only)
  const handleSaveWageSettings = () => {
    persistWageAndRates(inputBaseWage, inputHookahRate, inputCurrency, employeeRatesMap);
    setWageModalOpen(false);
    onNotify(`Ставките са запаметени веднага: ${inputBaseWage} ${inputCurrency} надник + ${inputHookahRate} ${inputCurrency}/наргиле`);
  };

  // Copy full payroll to clipboard with individual rates and fines details
  const handleCopyPayroll = () => {
    const periodLabel = filterAllTime ? 'Всички периоди' : `Месец: ${selectedMonth}`;
    let text = `💼 ВЕДОМОСТ ЗАПЛАТИ - CARGO HOOKAH\nПериод: ${periodLabel}\n`;
    text += `Общо за изплащане: ${totalPayrollPayoutEur.toFixed(2)} €\n\n`;

    staffPayrollList.forEach((p, idx) => {
      text += `${idx + 1}. ${p.user.name} (${p.user.role === 'boss' ? 'Шеф' : 'Служител'}):\n`;
      text += `   • Смени: ${p.shiftsCount} (${p.baseWageEur} € надник при ставка ${p.userBaseRate} €)\n`;
      text += `   • Наргилета: ${p.totalHookahs} бр. (+${p.hookahBonusEur} € бонус при ${p.userHookahRate} €/бр.)\n`;
      if (p.totalFinesEur > 0) {
        text += `   • Удръжки (Глоби): -${p.totalFinesEur.toFixed(2)} € (${p.userFines.length} бр.)\n`;
        p.userFines.forEach((f) => {
          text += `     - [${f.date}] -${f.amountEur} €: "${f.reason}"\n`;
        });
      }
      text += `   💰 ЧИСТО ЗА ИЗПЛАЩАНЕ: ${p.totalPayoutEur.toFixed(2)} €\n\n`;
    });

    navigator.clipboard.writeText(text);
    setCopiedPayroll(true);
    onNotify('Ведомостта за заплати с глоби и индивидуални ставки е копирана!');
    setTimeout(() => setCopiedPayroll(false), 3000);
  };

  // Currently viewed user stats (strictly currentUser if not boss; boss can inspect selected staff)
  const activeViewedUser = isBoss ? (allUsers.find((u) => u.id === selectedStaffId) || currentUser) : currentUser;
  const activeUserReports = periodReports.filter((r) => r.staffId === activeViewedUser.id);
  const activeUserShiftsCount = activeUserReports.length;
  const activeUserTotalHookahs = activeUserReports.reduce((sum, r) => sum + (Number(r.totalHookahs) || 0), 0);

  const activeUserBaseRate = (typeof activeViewedUser.customBaseWageEur === 'number' && activeViewedUser.customBaseWageEur >= 0)
    ? activeViewedUser.customBaseWageEur
    : baseWageRate;
  const activeUserHookahRate = (typeof activeViewedUser.customHookahRateEur === 'number' && activeViewedUser.customHookahRateEur >= 0)
    ? activeViewedUser.customHookahRateEur
    : hookahBonusRate;
  const activeUserHasCustom = (typeof activeViewedUser.customBaseWageEur === 'number' && activeViewedUser.customBaseWageEur >= 0) ||
                             (typeof activeViewedUser.customHookahRateEur === 'number' && activeViewedUser.customHookahRateEur >= 0);

  const activeUserBaseWages = activeUserShiftsCount * activeUserBaseRate;
  const activeUserHookahBonuses = activeUserTotalHookahs * activeUserHookahRate;
  const activeUserGrossSalaryEur = activeUserBaseWages + activeUserHookahBonuses;

  // Active user's fines in this period
  const activeUserFines = periodFines.filter((f) => f.staffId === activeViewedUser.id);
  const activeUserTotalFinesEur = activeUserFines.reduce((sum, f) => sum + (Number(f.amountEur) || 0), 0);
  const activeUserNetSalaryEur = Math.max(0, activeUserGrossSalaryEur - activeUserTotalFinesEur);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner / Role Status & Quick Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Left: User Identity */}
        <div className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-2xl ${currentUser.avatarColor} flex items-center justify-center font-black text-2xl shadow-lg shrink-0`}>
            {currentUser.name.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-black text-white">{currentUser.name}</h2>
              <span className={`text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 ${
                isBoss
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
              }`}>
                {isBoss ? '👑 Шеф / Мениджър' : 'Наргиле майстор'}
              </span>

              <button
                type="button"
                onClick={handleOpenEditProfile}
                className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-amber-500/50 rounded-xl text-xs font-bold text-amber-300 transition-all shadow-xs"
                title="Редактирай име, парола/PIN и данни на профила"
              >
                <Edit2 className="w-3.5 h-3.5 text-amber-400" />
                <span>Редактирай профила</span>
              </button>

              {onOpenPushModal && (
                <button
                  type="button"
                  onClick={onOpenPushModal}
                  className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-amber-500/50 rounded-xl text-xs font-bold text-emerald-300 transition-all shadow-xs"
                  title="Настройки на телефонните push известия"
                >
                  <Bell className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Известия на телефона</span>
                </button>
              )}
            </div>
            <div className="flex items-center gap-2 flex-wrap mt-1">
              <p className="text-xs text-slate-400">
                {isBoss ? 'Фирмена ставка: ' : 'Моята ставка: '}
                <span className="text-white font-semibold">{activeUserBaseRate} {currencySymbol} надник</span> +{' '}
                <span className="text-amber-400 font-semibold">{activeUserHookahRate} {currencySymbol} на наргиле</span>
              </p>
              {isBoss && (
                <button
                  type="button"
                  onClick={handleOpenWageModal}
                  className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-[10px] font-bold transition-all shadow-xs"
                  title="Промени надника и парите от наргиле"
                >
                  <Edit2 className="w-3 h-3 text-emerald-400" />
                  <span>Промени ставките</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Right: Period Filter & Boss Action Buttons */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Period selector */}
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800">
            <button
              onClick={() => setFilterAllTime(false)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                !filterAllTime
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Месец:
            </button>
            {!filterAllTime && (
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-transparent text-white font-bold text-xs px-2 py-1 focus:outline-none"
              />
            )}
            <button
              onClick={() => setFilterAllTime(true)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                filterAllTime
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Всички периоди
            </button>
          </div>

          {/* Boss Wage Settings Button */}
          {isBoss && (
            <button
              onClick={handleOpenWageModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-bold rounded-xl transition-all shadow-sm"
              title="Промени надника и парите от наргиле за екипа"
            >
              <Coins className="w-4 h-4 text-emerald-400" />
              <span>Ставки & Надник</span>
            </button>
          )}

          {/* Boss Pricing Config Button */}
          {isBoss && (
            <button
              onClick={() => setPricingModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-300 text-xs font-bold rounded-xl transition-all shadow-sm"
              title="Нагласи цените на наргилетата по заведения"
            >
              <Settings className="w-4 h-4 text-amber-400" />
              <span>Цени на наргилетата</span>
            </button>
          )}

          {/* QR Share Button */}
          {onOpenInstallModal && isBoss && (
            <button
              onClick={onOpenInstallModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 text-xs font-bold rounded-xl transition-all"
              title="Покани служител с QR код"
            >
              <QrCode className="w-4 h-4 text-amber-400" />
              <span>Покани (QR)</span>
            </button>
          )}
        </div>
      </div>

      {/* ============================================================== */}
      {/* 👑 BOSS EXCLUSIVE: FULL BUSINESS ANALYTICS & SCHEME PER VENUE  */}
      {/* ============================================================== */}
      {isBoss && (
        <div className="space-y-6">
          {/* Main KPI Highlights - 3 Core Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* 1. Общ Оборот */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-amber-500/30 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4" />
                  <span>Общ Оборот</span>
                </span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  {periodReports.length} смени
                </span>
              </div>
              <div className="my-3">
                <div className="text-3xl font-black text-white">
                  {businessTotals.totalRevenueEur.toFixed(2)}{' '}
                  <span className="text-xl text-amber-400 font-bold">€</span>
                </div>
              </div>
            </div>

            {/* 2. Разход за заплати */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                  <Wallet className="w-4 h-4" />
                  <span>Разход за заплати</span>
                </span>
                <span className="text-xs text-slate-300 font-bold">
                  {allUsers.length} служители
                </span>
              </div>
              <div className="my-3">
                <div className="text-3xl font-black text-white">
                  {businessTotals.totalStaffCostEur.toFixed(2)}{' '}
                  <span className="text-xl text-rose-400 font-bold">€</span>
                </div>
              </div>
            </div>

            {/* 3. Общо Наргилета */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <span className="text-xs font-extrabold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                  <Flame className="w-4 h-4" />
                  <span>Направени наргилета</span>
                </span>
              </div>
              <div className="my-3">
                <div className="text-3xl font-black text-white">
                  {businessTotals.totalHookahs}{' '}
                  <span className="text-sm font-normal text-slate-400">бр.</span>
                </div>
                <div className="flex items-center gap-2 mt-1 text-xs font-bold">
                  <span className="text-amber-400">🟡 {businessTotals.totalYellow}</span>
                  <span className="text-slate-400">•</span>
                  <span className="text-slate-200">⚫ {businessTotals.totalBlack}</span>
                  {businessTotals.totalOfficial > 0 && (
                    <>
                      <span className="text-slate-400">•</span>
                      <span className="text-cyan-400">⚪ {businessTotals.totalOfficial} служ.</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================= */}
          {/* СХЕМА ЗА ОБОРОТ НА ВСЯКО ЗАВЕДЕНИЕ С РАЗБИВКА ПО ЦЕНИ     */}
          {/* ========================================================= */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <Building2 className="w-5 h-5 text-amber-400" />
                  <span>Оборот и остатък по заведения</span>
                </h3>
              </div>

              <button
                onClick={() => setPricingModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-amber-300 rounded-xl border border-slate-700 self-start sm:self-auto transition-colors"
              >
                <Settings className="w-3.5 h-3.5 text-amber-400" />
                <span>Редактирай цени</span>
              </button>
            </div>

            {/* Scheme Cards: Бар хей, Зеро Зеро, Бар Де Руж */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {VENUES.map((venue) => {
                const stat = venueAnalytics[venue.id];
                const vPrices = getVenuePrice(venue.id);
                const revenueShare =
                  businessTotals.totalRevenueEur > 0
                    ? (stat.revenueEur / businessTotals.totalRevenueEur) * 100
                    : 0;

                return (
                  <div
                    key={venue.id}
                    className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-3xl p-5 shadow-xl space-y-4 transition-all"
                  >
                    {/* Header */}
                    <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                      <div className="flex items-center gap-2.5">
                        <span className={`w-3.5 h-3.5 rounded-full ${venue.themeColor.bg}`} />
                        <div>
                          <h4 className="text-base font-extrabold text-white">{venue.name}</h4>
                        </div>
                      </div>
                      <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-950 text-slate-300 border border-slate-800">
                        {stat.reportsCount} отчета
                      </span>
                    </div>

                    {/* Revenue Big Number */}
                    <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4">
                      <div className="text-[11px] uppercase font-bold text-slate-400 flex items-center justify-between">
                        <span>Оборот на обекта</span>
                        <span className="text-amber-400 font-bold">{revenueShare.toFixed(1)}% от общия</span>
                      </div>
                      <div className="text-2xl font-black text-white mt-1">
                        {stat.revenueEur.toFixed(2)}{' '}
                        <span className="text-base text-amber-400 font-bold">€</span>
                      </div>
                    </div>

                    {/* Hookah Sales & Pricing Breakdown - No multiplication clutter */}
                    <div className="space-y-2 text-xs">
                      <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                        Продажби по видове:
                      </div>

                      {/* Жълто */}
                      <div className="flex items-center justify-between bg-slate-950/40 px-3 py-2 rounded-xl border border-slate-800/50">
                        <div className="flex items-center gap-1.5">
                          <span>🟡</span>
                          <span className="text-slate-300 font-medium">Жълто:</span>
                        </div>
                        <div className="text-right flex items-center gap-2">
                          <span className="font-bold text-white">{stat.yellowCount} бр.</span>
                          <span className="text-xs font-bold text-amber-300">
                            {(stat.yellowCount * vPrices.yellowPriceEur).toFixed(2)} €
                          </span>
                        </div>
                      </div>

                      {/* Черно */}
                      <div className="flex items-center justify-between bg-slate-950/40 px-3 py-2 rounded-xl border border-slate-800/50">
                        <div className="flex items-center gap-1.5">
                          <span>⚫</span>
                          <span className="text-slate-300 font-medium">Черно:</span>
                        </div>
                        <div className="text-right flex items-center gap-2">
                          <span className="font-bold text-white">{stat.blackCount} бр.</span>
                          <span className="text-xs font-bold text-slate-200">
                            {(stat.blackCount * vPrices.blackPriceEur).toFixed(2)} €
                          </span>
                        </div>
                      </div>

                      {/* Служебни */}
                      {stat.officialCount > 0 && (
                        <div className="flex items-center justify-between bg-slate-950/40 px-3 py-1.5 rounded-xl border border-slate-800/50 text-[11px]">
                          <span className="text-slate-400">⚪ Служебни (дегустация):</span>
                          <span className="font-semibold text-slate-300">{stat.officialCount} бр.</span>
                        </div>
                      )}
                    </div>

                    {/* Financial Balance: Staff Cost */}
                    <div className="pt-2 border-t border-slate-800 space-y-2 text-xs">
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Разходи за наргилисти:</span>
                        <span className="font-bold text-rose-300">
                          - {stat.staffCostEur.toFixed(2)} €
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Relative Revenue Share Bar */}
            {businessTotals.totalRevenueEur > 0 && (
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-400">
                  <span>Дялово разпределение на оборота между заведенията:</span>
                  <span className="text-white">Общо: {businessTotals.totalRevenueEur.toFixed(2)} €</span>
                </div>
                <div className="w-full h-3 rounded-full bg-slate-950 overflow-hidden flex">
                  {VENUES.map((v) => {
                    const st = venueAnalytics[v.id];
                    const pct = (st.revenueEur / businessTotals.totalRevenueEur) * 100;
                    if (pct <= 0) return null;
                    return (
                      <div
                        key={v.id}
                        style={{ width: `${pct}%` }}
                        className={`${v.themeColor.bg} h-full transition-all`}
                        title={`${v.name}: ${pct.toFixed(1)}% (${st.revenueEur.toFixed(2)} €)`}
                      />
                    );
                  })}
                </div>
                <div className="flex items-center gap-4 flex-wrap text-xs pt-1">
                  {VENUES.map((v) => {
                    const st = venueAnalytics[v.id];
                    const pct = (st.revenueEur / businessTotals.totalRevenueEur) * 100;
                    return (
                      <div key={v.id} className="flex items-center gap-1.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${v.themeColor.bg}`} />
                        <span className="text-slate-300 font-semibold">{v.name}:</span>
                        <span className="text-white font-bold">{pct.toFixed(1)}%</span>
                        <span className="text-slate-400 text-[11px]">({st.revenueEur.toFixed(1)}€)</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* ========================================================= */}
          {/* ПРИВИЛЕГИИ ЗА ДОСТЪП НА ПЕРСОНАЛА (ШЕФ КОНТРОЛ)          */}
          {/* ========================================================= */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                <span>Привилегии за достъп на персонала</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Задайте какви модули и менюта могат да управляват избраните от вас служители
              </p>
            </div>

            <div className="space-y-3">
              {allUsers.map((u) => {
                const isUserBoss = u.role === 'boss';
                const perms = u.permissions || {
                  canManageSchedule: true,
                  canManageInventory: true,
                  canManageReports: true,
                  canViewFinances: isUserBoss,
                  canManageFines: isUserBoss,
                };

                return (
                  <div
                    key={u.id}
                    className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl ${u.avatarColor} flex items-center justify-center font-bold text-sm shrink-0`}>
                        {u.name.charAt(0)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white">{u.name}</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            isUserBoss ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-slate-800 text-slate-400'
                          }`}>
                            {isUserBoss ? '👑 Шеф' : '💨 Служител'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Permissions Toggle Buttons */}
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {/* 1. График */}
                      <button
                        type="button"
                        onClick={() => handleTogglePermission(u, 'canManageSchedule')}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                          perms.canManageSchedule
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-xs'
                            : 'bg-slate-900 text-slate-500 border-slate-800 opacity-60'
                        }`}
                        title="Право за управление на график"
                      >
                        <Calendar className="w-3.5 h-3.5" />
                        <span>График</span>
                        <span>{perms.canManageSchedule ? '✓' : '✗'}</span>
                      </button>

                      {/* 2. Склад и Тютюни */}
                      <button
                        type="button"
                        onClick={() => handleTogglePermission(u, 'canManageInventory')}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                          perms.canManageInventory
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-xs'
                            : 'bg-slate-900 text-slate-500 border-slate-800 opacity-60'
                        }`}
                        title="Право за тютюни и склад"
                      >
                        <Flame className="w-3.5 h-3.5" />
                        <span>Склад</span>
                        <span>{perms.canManageInventory ? '✓' : '✗'}</span>
                      </button>

                      {/* 3. Дневни отчети */}
                      <button
                        type="button"
                        onClick={() => handleTogglePermission(u, 'canManageReports')}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                          perms.canManageReports
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-xs'
                            : 'bg-slate-900 text-slate-500 border-slate-800 opacity-60'
                        }`}
                        title="Право за подаване на дневни отчети"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Отчети</span>
                        <span>{perms.canManageReports ? '✓' : '✗'}</span>
                      </button>

                      {/* 4. Шеф анализ & Финанси */}
                      <button
                        type="button"
                        onClick={() => handleTogglePermission(u, 'canViewFinances')}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                          perms.canViewFinances
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-xs'
                            : 'bg-slate-900 text-slate-500 border-slate-800 opacity-60'
                        }`}
                        title="Право за преглед на финанси и обороти"
                      >
                        <TrendingUp className="w-3.5 h-3.5" />
                        <span>Финанси</span>
                        <span>{perms.canViewFinances ? '✓' : '✗'}</span>
                      </button>

                      {/* 5. Глоби */}
                      <button
                        type="button"
                        onClick={() => handleTogglePermission(u, 'canManageFines')}
                        className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 ${
                          perms.canManageFines
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 shadow-xs'
                            : 'bg-slate-900 text-slate-500 border-slate-800 opacity-60'
                        }`}
                        title="Право за налагане на глоби"
                      >
                        <AlertOctagon className="w-3.5 h-3.5" />
                        <span>Глоби</span>
                        <span>{perms.canManageFines ? '✓' : '✗'}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ========================================================= */}
          {/* ГОТОВИ ЗАПЛАТИ НА ВСЕКИ СЛУЖИТЕЛ (ВЕДОМОСТ ЗА ИЗПЛАЩАНЕ)  */}
          {/* ========================================================= */}
          <div className="space-y-4 pt-4 border-t border-slate-800">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                  <Wallet className="w-5 h-5 text-emerald-400" />
                  <span>Готови заплати на всеки служител (Ведомост)</span>
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyPayroll}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 rounded-xl text-xs font-bold transition-all"
                  title="Копирай готов списък за изплащане за Viber/WhatsApp"
                >
                  {copiedPayroll ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-emerald-400" />}
                  <span>{copiedPayroll ? 'Копирано!' : 'Копирай ведомостта'}</span>
                </button>
              </div>
            </div>

            {/* Payroll Cards / Table */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {staffPayrollList.map((item) => {
                const isSelected = selectedStaffId === item.user.id;

                return (
                  <div
                    key={item.user.id}
                    className={`bg-slate-900 border rounded-3xl p-5 shadow-xl transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'border-amber-500 ring-2 ring-amber-500/20'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div>
                      {/* Top: Avatar, Name & Role */}
                      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-11 h-11 rounded-2xl ${item.user.avatarColor} flex items-center justify-center font-bold text-lg text-slate-950 shadow-md shrink-0`}>
                            {item.user.name.charAt(0)}
                          </div>
                          <div>
                            <h4 className="text-sm font-extrabold text-white">{item.user.name}</h4>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                                item.user.role === 'boss'
                                  ? 'bg-amber-500/20 text-amber-300'
                                  : 'bg-cyan-500/20 text-cyan-300'
                              }`}>
                                {item.user.role === 'boss' ? 'Шеф' : 'Наргилист'}
                              </span>
                              {item.user.phone && (
                                <span className="text-[10px] text-slate-400 flex items-center gap-1">
                                  <Phone className="w-2.5 h-2.5" />
                                  {item.user.phone}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => setSelectedStaffId(item.user.id)}
                          className={`text-xs px-2.5 py-1 rounded-xl font-bold transition-all ${
                            isSelected
                              ? 'bg-amber-500 text-slate-950'
                              : 'text-slate-400 hover:text-white bg-slate-950 border border-slate-800'
                          }`}
                        >
                          {isSelected ? 'Избран' : 'Преглед'}
                        </button>
                      </div>

                      {/* Work Output: Shifts & Hookahs */}
                      <div className="grid grid-cols-2 gap-2 my-3 text-xs">
                        <div className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-2xl">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] text-slate-400 uppercase font-bold block">Смени</span>
                            {item.hasCustomRates && (
                              <span className="text-[8px] bg-amber-500/20 text-amber-300 px-1 rounded font-bold">Персонална</span>
                            )}
                          </div>
                          <span className="text-base font-black text-white">{item.shiftsCount}</span>
                          <div className="text-[11px] text-slate-300 font-semibold mt-0.5">
                            {item.baseWageEur} €
                          </div>
                        </div>

                        <div className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-2xl">
                          <span className="text-[10px] text-slate-400 uppercase font-bold block">Наргилета</span>
                          <span className="text-base font-black text-amber-400">{item.totalHookahs}</span>
                          <div className="text-[11px] text-amber-300 font-semibold mt-0.5">
                            +{item.hookahBonusEur} €
                          </div>
                        </div>
                      </div>

                      {/* Hookah breakdown */}
                      <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 mb-2">
                        <span>Видове наргилета:</span>
                        <span className="font-semibold text-slate-300">
                          🟡 {item.yellowHookahs} • ⚫ {item.blackHookahs}
                          {item.officialHookahs > 0 ? ` • ⚪ ${item.officialHookahs} служ.` : ''}
                        </span>
                      </div>

                      {/* Fines Deduction (if any) */}
                      {item.totalFinesEur > 0 && (
                        <div className="bg-rose-950/30 border border-rose-500/40 rounded-xl px-2.5 py-1.5 flex items-center justify-between text-xs mb-2">
                          <span className="text-rose-300 font-bold flex items-center gap-1">
                            <AlertOctagon className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                            <span>Глоби ({item.userFines.length} бр.):</span>
                          </span>
                          <span className="text-rose-400 font-black">-{item.totalFinesEur.toFixed(2)} €</span>
                        </div>
                      )}
                    </div>

                    {/* Total Salary Payout Box */}
                    <div className="bg-gradient-to-r from-emerald-950/60 to-slate-950 border-2 border-emerald-500/50 rounded-2xl p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-black uppercase tracking-wider text-emerald-400 block">
                          Заплата:
                        </span>
                      </div>
                      <div className="flex items-baseline justify-between mt-1">
                        <div className="text-2xl font-black text-white">
                          {item.totalPayoutEur.toFixed(2)}{' '}
                          <span className="text-base text-emerald-400">€</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Total Payroll Bar */}
            <div className="bg-slate-950 border border-emerald-500/30 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Общо фонд работна заплата</h4>
                  <p className="text-xs text-slate-400">
                    Сумарно за всички {staffPayrollList.length} служители за избрания период
                  </p>
                </div>
              </div>

              <div className="text-right">
                <div className="text-2xl font-black text-emerald-400">
                  {totalPayrollPayoutEur.toFixed(2)} €
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* 👤 EMPLOYEE VIEW (Or Detailed Inspection for Boss of selected staff) */}
      {/* ============================================================== */}
      <div className="space-y-4 pt-4 border-t border-slate-800">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <h3 className="text-base font-extrabold text-white flex items-center gap-2">
              <Calendar className="w-5 h-5 text-amber-400" />
              <span>
                {isBoss ? `Детайлни отчети на: ${activeViewedUser.name}` : 'Моите смени и изработена заплата'}
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Хронология на подадените дневни отчети и направените наргилета
            </p>
          </div>

          {/* If boss, employee dropdown selector */}
          {isBoss && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 font-semibold">Избор:</span>
              <select
                value={selectedStaffId}
                onChange={(e) => setSelectedStaffId(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-amber-400 font-bold text-xs rounded-xl px-3 py-1.5 focus:outline-none focus:border-amber-500"
              >
                {allUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role === 'boss' ? 'Шеф' : 'Служител'})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Highlight Stats for this user with Personalized Rates & Fines */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5">
                <p className="text-xs text-slate-400 font-medium">Отработени смени</p>
                {activeUserHasCustom && (
                  <span className="text-[9px] bg-amber-500/20 text-amber-300 font-bold px-1 rounded">Персонална</span>
                )}
              </div>
              <h4 className="text-xl font-black text-white mt-0.5">{activeUserShiftsCount}</h4>
              <p className="text-[11px] text-slate-500">{activeUserShiftsCount} × {activeUserBaseRate}€ = {activeUserBaseWages}€</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold">
              <Calendar className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <p className="text-xs text-slate-400 font-medium">Направени наргилета</p>
              <h4 className="text-xl font-black text-amber-400 mt-0.5">{activeUserTotalHookahs} бр.</h4>
              <p className="text-[11px] text-amber-400/80">+{activeUserHookahBonuses}€ ({activeUserHookahRate}€/бр.)</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center font-bold">
              <Flame className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-slate-900 border border-rose-500/30 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <p className="text-xs text-rose-400 font-bold uppercase tracking-wider">Удръжки (Глоби)</p>
              <h4 className="text-xl font-black text-rose-400 mt-0.5">
                {activeUserTotalFinesEur > 0 ? `-${activeUserTotalFinesEur.toFixed(2)} €` : '0.00 €'}
              </h4>
              <p className="text-[11px] text-slate-400">
                {activeUserFines.length} {activeUserFines.length === 1 ? 'наложена глоба' : 'наложени глоби'}
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center font-bold">
              <AlertOctagon className="w-5 h-5" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-emerald-950/40 to-slate-900 border border-emerald-500/30 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <p className="text-xs text-emerald-400 font-bold uppercase tracking-wider">Заплата</p>
              <h4 className="text-xl font-black text-white mt-0.5">{activeUserNetSalaryEur.toFixed(2)} €</h4>
            </div>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <Euro className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Detailed Fines List for this Employee */}
        {activeUserFines.length > 0 && (
          <div className="bg-slate-900 border border-rose-500/40 rounded-3xl p-5 shadow-xl space-y-3 animate-in fade-in duration-150">
            <div className="flex items-center justify-between flex-wrap gap-2 pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />
                <h4 className="text-sm font-bold text-white">
                  Наложени глоби на {activeViewedUser.name} ({activeUserFines.length} бр.)
                </h4>
              </div>
              <span className="text-xs font-black text-rose-400 bg-rose-500/10 border border-rose-500/30 px-3 py-1 rounded-xl">
                Общо удържани: -{activeUserTotalFinesEur.toFixed(2)} €
              </span>
            </div>

            <p className="text-xs text-slate-400">
              Списък на нарушенията и причините, за които служителят бива глобен (директно приспаднати от заплатата):
            </p>

            <div className="space-y-2.5">
              {activeUserFines.map((fine) => {
                const venueObj = VENUES.find((v) => v.id === fine.venueId);

                return (
                  <div
                    key={fine.id}
                    className="bg-slate-950 border border-rose-500/20 hover:border-rose-500/40 rounded-2xl p-3.5 space-y-2 transition-all"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold text-slate-300">📅 Дата: {fine.date}</span>
                        {venueObj && (
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${venueObj.themeColor.badgeBg}`}>
                            {venueObj.name}
                          </span>
                        )}
                        <span className="text-[11px] text-slate-500">• Наложена от: {fine.issuedBy || 'Шеф'}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-base font-black text-rose-400">-{fine.amountEur.toFixed(2)} €</span>
                      </div>
                    </div>

                    <div className="bg-rose-500/10 border border-rose-500/20 rounded-xl p-2.5 text-xs text-rose-200">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400 block mb-0.5">
                        Причина / За какво е глобен:
                      </span>
                      <p className="font-medium leading-relaxed">"{fine.reason}"</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Detailed Reports List */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Списък с подадени смени за {activeViewedUser.name}:
          </h4>

          {activeUserReports.length === 0 ? (
            <div className="text-center py-8 text-slate-500 space-y-1">
              <FileText className="w-8 h-8 text-slate-600 mx-auto" />
              <p className="text-sm font-semibold text-slate-400">Няма въведени дневни отчети за този период.</p>
              <p className="text-xs text-slate-500">След всяка приключена смяна служителят подава отчет от таб „Дневни отчети“.</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {activeUserReports.map((report) => {
                const venue = VENUES.find((v) => v.id === report.venueId);
                const vPrices = getVenuePrice(report.venueId);
                const reportTurnover =
                  (report.yellowHookahs * vPrices.yellowPriceEur) +
                  (report.blackHookahs * vPrices.blackPriceEur);

                return (
                  <div
                    key={report.id}
                    className="bg-slate-950 border border-slate-800/80 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-xs font-bold text-white px-2.5 py-1 rounded-xl bg-slate-900 border border-slate-700">
                        {report.date}
                      </span>
                      {venue && (
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-lg border ${venue.themeColor.badgeBg}`}>
                          {venue.name}
                        </span>
                      )}
                      <div className="text-xs text-slate-300">
                        <span className="font-bold text-amber-400">{report.totalHookahs} наргилета</span>
                        <span className="text-slate-500 ml-1.5">
                          (🟡 {report.yellowHookahs} • ⚫ {report.blackHookahs})
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 text-xs font-bold">
                      {isBoss && (
                        <div className="text-right">
                          <span className="text-[10px] text-slate-500 uppercase block">Оборот обект</span>
                          <span className="text-amber-300 font-bold">{reportTurnover.toFixed(1)} €</span>
                        </div>
                      )}
                      <div className="text-right bg-emerald-950/40 border border-emerald-500/30 px-3 py-1 rounded-xl">
                        <span className="text-[10px] text-emerald-400 uppercase block">Заплата за смяната</span>
                        <span className="text-white font-extrabold">{report.totalEarnedEur} €</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Pricing Modal */}
      {isBoss && (
        <PricingModal
          isOpen={pricingModalOpen}
          onClose={() => setPricingModalOpen(false)}
          pricing={pricing}
          onSavePricing={onUpdatePricing}
          onNotify={onNotify}
        />
      )}

      {/* Edit Profile Modal */}
      {editProfileOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-4 my-8 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Edit2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Редакция на профил</h3>
                  <p className="text-xs text-slate-400">
                    {isBoss ? '👑 Шефски профил (може да промените името boss)' : 'Профил на служител'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditProfileOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Име на профила *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    placeholder="напр. boss или вашето име"
                    className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl pl-9 pr-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-amber-500"
                  />
                </div>
                <p className="text-[10px] text-slate-500 mt-1">
                  Може да смените името по всяко време (напр. от „boss“ на вашето собствено име).
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Парола / PIN код *
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={editPin}
                    onChange={(e) => setEditPin(e.target.value)}
                    placeholder="напр. 1234 или нова парола"
                    className="w-full bg-slate-950 border border-slate-700 text-amber-400 font-mono rounded-xl pl-9 pr-3 py-2.5 text-xs font-bold tracking-widest focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Телефонен номер (по избор)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={editPhone}
                    onChange={(e) => setEditPhone(e.target.value)}
                    placeholder="0888..."
                    className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl pl-9 pr-3 py-2.5 text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Цвят на аватара
                </label>
                <div className="flex items-center gap-2 flex-wrap">
                  {colorOptions.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setEditAvatarColor(c)}
                      className={`w-7 h-7 rounded-xl ${c} flex items-center justify-center font-bold text-[10px] transition-all ${
                        editAvatarColor === c ? 'ring-2 ring-white scale-110 shadow-md' : 'opacity-80 hover:opacity-100'
                      }`}
                    >
                      {editAvatarColor === c && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditProfileOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold rounded-xl"
                >
                  Отказ
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
                >
                  Запази промените
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Boss Wage Settings Modal */}
      {wageModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 w-full max-w-xl max-h-[92vh] flex flex-col shadow-2xl relative overflow-hidden">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
                  <Coins className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base">Ставки за заплащане</h3>
                  <p className="text-xs text-slate-400">Общи и персонални ставки за надник и наргилета</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setWageModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSaveWageSettings();
              }}
              className="space-y-4 overflow-y-auto flex-1 pr-1 py-3"
            >
              {/* General Company Base Wage */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Общ базов надник за 1 смяна ({inputCurrency})
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    min="0"
                    required
                    value={inputBaseWage}
                    onChange={(e) => setInputBaseWage(parseFloat(e.target.value) || 0)}
                    onBlur={() => persistWageAndRates(inputBaseWage, inputHookahRate, inputCurrency, employeeRatesMap)}
                    className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-sm font-bold focus:outline-none focus:border-emerald-500"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                    {inputCurrency} / смяна
                  </span>
                </div>
                <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                  <span className="text-[10px] text-slate-500">Бърз избор:</span>
                  {[20, 23, 25, 30, 35, 40].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => {
                        setInputBaseWage(val);
                        persistWageAndRates(val, inputHookahRate, inputCurrency, employeeRatesMap);
                      }}
                      className={`text-[10px] px-2 py-0.5 rounded-lg border font-semibold transition-all ${
                        inputBaseWage === val
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {val} {inputCurrency}
                    </button>
                  ))}
                </div>
              </div>

              {/* General Hookah Rate */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Общо заплащане за всяко направено наргиле ({inputCurrency})
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    required
                    value={inputHookahRate}
                    onChange={(e) => setInputHookahRate(parseFloat(e.target.value) || 0)}
                    onBlur={() => persistWageAndRates(inputBaseWage, inputHookahRate, inputCurrency, employeeRatesMap)}
                    className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-sm font-bold focus:outline-none focus:border-amber-500"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-amber-400">
                    {inputCurrency} / наргиле
                  </span>
                </div>
                <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                  <span className="text-[10px] text-slate-500">Бърз избор:</span>
                  {[0.5, 1, 1.5, 2, 2.5].map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => {
                        setInputHookahRate(val);
                        persistWageAndRates(inputBaseWage, val, inputCurrency, employeeRatesMap);
                      }}
                      className={`text-[10px] px-2 py-0.5 rounded-lg border font-semibold transition-all ${
                        inputHookahRate === val
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {val.toFixed(val % 1 === 0 ? 0 : 1)} {inputCurrency}
                    </button>
                  ))}
                </div>
              </div>

              {/* Currency selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Валута за заплащане
                </label>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-2 rounded-xl text-xs font-bold border bg-emerald-500/20 border-emerald-500 text-emerald-300">
                    Евро (€) - Официална валута
                  </span>
                </div>
              </div>

              {/* Personalized Rates Per Employee */}
              <div className="pt-3 border-t border-slate-800 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Users className="w-3.5 h-3.5 text-amber-400" />
                      <span>Персонализирани ставки за служители</span>
                    </h4>
                  </div>
                </div>

                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {allUsers.map((u) => {
                    const uRates = employeeRatesMap[u.id] || { baseWage: '', hookahRate: '' };

                    return (
                      <div
                        key={u.id}
                        className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-2xl p-2.5 flex items-center justify-between gap-3 transition-colors"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className={`w-8 h-8 rounded-xl ${u.avatarColor} flex items-center justify-center font-bold text-xs shrink-0`}>
                            {u.name.charAt(0)}
                          </div>
                          <div className="truncate">
                            <span className="text-xs font-bold text-white truncate block">{u.name}</span>
                            <span className="text-[10px] text-slate-400">
                              {u.role === 'boss' ? '👑 Шеф' : '💨 Служител'}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <div>
                            <span className="text-[9px] text-slate-500 font-bold block">Надник ({inputCurrency})</span>
                            <input
                              type="number"
                              min="0"
                              step="0.5"
                              placeholder={String(inputBaseWage)}
                              value={uRates.baseWage}
                              onChange={(e) => {
                                const val = e.target.value;
                                setEmployeeRatesMap((prev) => ({
                                  ...prev,
                                  [u.id]: { ...(prev[u.id] || { hookahRate: '' }), baseWage: val },
                                }));
                              }}
                              onBlur={() => persistWageAndRates(inputBaseWage, inputHookahRate, inputCurrency, employeeRatesMap)}
                              className="w-16 bg-slate-900 border border-slate-700 text-amber-300 font-bold rounded-xl px-2 py-1 text-xs focus:outline-none focus:border-amber-500 text-center"
                            />
                          </div>

                          <div>
                            <span className="text-[9px] text-slate-500 font-bold block">Наргиле ({inputCurrency})</span>
                            <input
                              type="number"
                              min="0"
                              step="0.1"
                              placeholder={String(inputHookahRate)}
                              value={uRates.hookahRate}
                              onChange={(e) => {
                                const val = e.target.value;
                                setEmployeeRatesMap((prev) => ({
                                  ...prev,
                                  [u.id]: { ...(prev[u.id] || { baseWage: '' }), hookahRate: val },
                                }));
                              }}
                              onBlur={() => persistWageAndRates(inputBaseWage, inputHookahRate, inputCurrency, employeeRatesMap)}
                              className="w-16 bg-slate-900 border border-slate-700 text-amber-300 font-bold rounded-xl px-2 py-1 text-xs focus:outline-none focus:border-amber-500 text-center"
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Live Preview */}
              <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-1">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                  Примерно изчисление (за 1 смяна с 10 наргилета):
                </span>
                <p className="text-xs text-white font-medium">
                  {inputBaseWage} € надник + (10 × {inputHookahRate} €) ={' '}
                  <span className="text-emerald-400 font-extrabold text-sm">
                    {(inputBaseWage + 10 * inputHookahRate).toFixed(2)} €
                  </span>
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-slate-800 shrink-0">
                <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1.5 self-start sm:self-auto">
                  <Check className="w-3.5 h-3.5 shrink-0" />
                  <span>Промените се запаметяват веднага на всички устройства</span>
                </span>
                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    type="button"
                    onClick={() => setWageModalOpen(false)}
                    className="px-4 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold rounded-xl"
                  >
                    Отказ
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4" />
                    <span>Запази ставките веднага</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
