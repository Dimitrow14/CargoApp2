import React, { useRef, useState } from 'react';
import { 
  UserAccount, 
  ViewTab, 
  ShiftConflict,
  WageSettings
} from '../types';
import { VENUES } from '../data/initialData';
import { CargoLogo } from './CargoLogo';
import { apiUploadLogo } from '../utils/storage';
import { 
  Package, 
  Boxes,
  Calendar, 
  FileText,
  User, 
  Users, 
  LogOut, 
  Download, 
  QrCode,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  TrendingUp,
  AlertOctagon,
  Upload,
  Check,
  Building2,
  ShieldAlert,
  Bell,
  ClipboardList
} from 'lucide-react';

interface HeaderProps {
  currentUser: UserAccount;
  activeTab: ViewTab;
  wageSettings?: WageSettings;
  finesCount?: number;
  pendingApprovalsCount?: number;
  onSelectTab: (tab: ViewTab) => void;
  onLogout: () => void;
  onOpenTeamManage: () => void;
  onOpenManageVenues?: () => void;
  onOpenApprovals?: () => void;
  onOpenPushModal?: () => void;
  onOpenFinesModal?: () => void;
  onOpenInstallModal: () => void;
  onResetData: () => void;
  conflictsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  activeTab,
  wageSettings,
  finesCount,
  pendingApprovalsCount = 0,
  onSelectTab,
  onLogout,
  onOpenTeamManage,
  onOpenManageVenues,
  onOpenApprovals,
  onOpenPushModal,
  onOpenFinesModal,
  onOpenInstallModal,
  onResetData,
  conflictsCount,
}) => {
  const isBossOrAdmin = currentUser.role === 'boss' || currentUser.role === 'admin';
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleHeaderLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUrl = reader.result as string;
      try {
        localStorage.setItem('hookah_custom_logo', dataUrl);
        window.dispatchEvent(new Event('hookah_logo_updated'));
        await apiUploadLogo(dataUrl);
        setUploadSuccess(true);
        setTimeout(() => setUploadSuccess(false), 4000);
      } catch (err) {
        console.error('Error saving logo from header:', err);
      } finally {
        setIsUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-30 shadow-md font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        {/* Top bar: Brand + User Profile + Quick Action Buttons */}
        <div className="flex items-center justify-between gap-2 sm:gap-4">
          {/* Logo & Tagline */}
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/png,image/jpeg,image/svg+xml,image/webp,image/*"
              className="hidden"
              onChange={handleHeaderLogoUpload}
            />
            <div
              onClick={() => currentUser.role === 'boss' && fileInputRef.current?.click()}
              className={`relative shrink-0 ${currentUser.role === 'boss' ? 'cursor-pointer group' : ''}`}
              title={currentUser.role === 'boss' ? 'Шеф: Кликнете, за да смените логото с качено от вас' : 'Cargo Hookah'}
            >
              <CargoLogo size="sm" className="sm:hidden" />
              <CargoLogo size="md" className="hidden sm:inline-flex" />
              {currentUser.role === 'boss' && (
                <span className="absolute -bottom-1 -right-1 bg-slate-800 text-amber-400 p-0.5 rounded-full border border-slate-700 opacity-80 group-hover:opacity-100 transition-opacity">
                  <Upload className="w-2.5 h-2.5" />
                </span>
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
                <h1 className="text-sm sm:text-lg font-black text-white tracking-wider flex items-center gap-1.5 truncate">
                  <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 bg-clip-text text-transparent">
                    CARGO HOOKAH
                  </span>
                </h1>
                {uploadSuccess && (
                  <span className="text-[9px] sm:text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-1.5 py-0.2 rounded-full font-bold animate-in fade-in">
                    ✓ Логото е обновено!
                  </span>
                )}
                <div className="hidden md:flex items-center gap-1">
                  {VENUES.map((v) => (
                    <span
                      key={v.id}
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${v.themeColor.badgeBg}`}
                    >
                      {v.name}
                    </span>
                  ))}
                </div>
              </div>
              <p className="text-[10px] sm:text-[11px] text-slate-400 truncate hidden xs:block">
                Бар хей • Зеро Зеро • Бар Де Руж
              </p>
            </div>
          </div>

          {/* Right: Actions + User Profile + Logout */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Top Action Buttons: ONLY Team and Venues for Boss/Admin */}
            {isBossOrAdmin ? (
              <>
                <button
                  onClick={onOpenTeamManage}
                  id="team-btn"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 rounded-xl text-xs font-bold border border-amber-500/30 transition-all shadow-xs cursor-pointer"
                  title="Управление на екипа"
                >
                  <Users className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">Управление Екип</span>
                  <span className="sm:hidden">Екип</span>
                </button>

                {onOpenManageVenues && (
                  <button
                    onClick={onOpenManageVenues}
                    id="venues-btn"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 rounded-xl text-xs font-bold border border-amber-500/30 transition-all shadow-xs cursor-pointer"
                    title="Управление на заведения"
                  >
                    <Building2 className="w-3.5 h-3.5 text-amber-400" />
                    <span>Обекти</span>
                  </button>
                )}
              </>
            ) : (
              <button
                onClick={onOpenTeamManage}
                id="team-btn"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-slate-700 transition-colors cursor-pointer"
                title="Контакти на колегите"
              >
                <Users className="w-3.5 h-3.5 text-slate-400" />
                <span>Колеги</span>
              </button>
            )}

            {/* Current user badge */}
            <div className="flex items-center gap-1.5 sm:gap-2 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1">
              <div className={`w-6 h-6 rounded-lg ${currentUser.avatarColor} flex items-center justify-center font-bold text-[10px]`}>
                {currentUser.name.charAt(0)}
              </div>
              <div className="text-left hidden xs:block">
                <span className="text-xs font-bold text-white block leading-tight truncate max-w-[90px] sm:max-w-none">
                  {currentUser.name}
                </span>
                <span className="text-[9px] font-bold text-amber-400 block leading-none">
                  {currentUser.role === 'boss' ? 'ШЕФ' : currentUser.role === 'admin' ? 'АДМИН' : 'СЛУЖИТЕЛ'}
                </span>
              </div>
            </div>

            {/* Logout */}
            <button
              onClick={onLogout}
              className="p-1.5 sm:p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors cursor-pointer"
              title="Изход от профила"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Navigation - Hidden on mobile where Bottom Navigation is used */}
        <div className="hidden sm:flex mt-3 pt-3 border-t border-slate-800/80 items-center justify-between gap-2 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-2xl border border-slate-800 text-xs font-bold">
            {/* 1. Тютюни & Ревизия */}
            <button
              onClick={() => onSelectTab('inventory')}
              id="tab-inventory"
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'inventory'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-black'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Тютюни</span>
            </button>

            {/* 2. Инвентар */}
            <button
              onClick={() => onSelectTab('equipment')}
              id="tab-equipment"
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'equipment'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-black'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Boxes className="w-4 h-4 text-cyan-400" />
              <span>Инвентар</span>
            </button>

            {/* 3. Дневен отчет */}
            <button
              onClick={() => onSelectTab('reports')}
              id="tab-reports"
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'reports'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-black'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <FileText className="w-4 h-4 text-amber-400" />
              <span>Дневен отчет</span>
            </button>

            {/* Задачи */}
            <button
              onClick={() => onSelectTab('tasks')}
              id="tab-tasks"
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${activeTab === 'tasks' ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-black' : 'text-slate-400 hover:text-white hover:bg-slate-800/60'}`}
            >
              <ClipboardList className="w-4 h-4" />
              <span>Задачи</span>
            </button>

            {/* 4. График */}
            <button
              onClick={() => onSelectTab('schedule')}
              id="tab-schedule"
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'schedule'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-black'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>График</span>
            </button>

            {/* 5. Глоби (RBAC: ONLY Visible to Admin / Boss) */}
            {isBossOrAdmin && (
              <button
                onClick={() => onSelectTab('fines')}
                id="tab-fines"
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                  activeTab === 'fines'
                    ? 'bg-rose-500 text-white shadow-md shadow-rose-500/25 font-black'
                    : 'text-slate-400 hover:text-rose-300 hover:bg-slate-800/60'
                }`}
              >
                <AlertOctagon className="w-4 h-4 text-rose-400" />
                <span>Глоби</span>
                {finesCount !== undefined && finesCount > 0 && (
                  <span className={`text-[10px] font-black px-1.5 py-0.2 rounded-full ${
                    activeTab === 'fines' ? 'bg-white text-rose-600' : 'bg-rose-500 text-white'
                  }`}>
                    {finesCount}
                  </span>
                )}
              </button>
            )}

            {/* 6. Личен профил & Заплата / Шеф Анализ & Заплати */}
            <button
              onClick={() => onSelectTab('my_profile')}
              id="tab-profile"
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl transition-all whitespace-nowrap cursor-pointer ${
                activeTab === 'my_profile'
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20 font-black'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              {currentUser.role === 'boss' ? (
                <>
                  <TrendingUp className="w-4 h-4" />
                  <span>Шеф Анализ & Заплати</span>
                </>
              ) : (
                <>
                  <User className="w-4 h-4" />
                  <span>Моят профил & Заплата</span>
                </>
              )}
            </button>
          </div>

          {/* Conflict indicator (if any) */}
          {conflictsCount > 0 && (
            <div className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-semibold shrink-0">
              <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
              <span>{conflictsCount} застъпвания в графика</span>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
