import React, { useState, useEffect } from 'react';
import { UserAccount } from '../types';
import { 
  checkPushSupportStatus, 
  subscribeToPushNotifications, 
  unsubscribeFromPushNotifications,
  triggerTestPushNotification, 
  PushSupportStatus 
} from '../utils/pushManager';
import { 
  Bell, 
  BellRing, 
  BellOff,
  Send, 
  CheckCircle2, 
  X, 
  Smartphone, 
  Clock, 
  ShieldAlert, 
  Loader2,
  Sparkles
} from 'lucide-react';

interface PushSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserAccount;
  onUpdateUser?: (user: UserAccount) => void;
  onNotify: (msg: string) => void;
}

export const PushSettingsModal: React.FC<PushSettingsModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onNotify,
}) => {
  const [status, setStatus] = useState<PushSupportStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [testing, setTesting] = useState(false);

  const refreshStatus = async () => {
    try {
      const s = await checkPushSupportStatus();
      setStatus(s);
    } catch (e) {
      console.warn('Error checking push status:', e);
    }
  };

  useEffect(() => {
    if (isOpen) {
      refreshStatus();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleEnable = async () => {
    setLoading(true);
    try {
      const res = await subscribeToPushNotifications(currentUser);
      if (res.success) {
        onNotify('🔔 Системните известия на телефона са активирани!');
        await refreshStatus();
      } else {
        onNotify(res.error || 'Неуспешно активиране на известията.');
      }
    } catch (e: any) {
      onNotify('Грешка: ' + (e.message || e));
    } finally {
      setLoading(false);
    }
  };

  const handleDisable = async () => {
    setLoading(true);
    try {
      await unsubscribeFromPushNotifications(currentUser);
      onNotify('Телефонните известия бяха изключени.');
      await refreshStatus();
    } catch (e: any) {
      onNotify('Грешка при спиране на известията: ' + e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleTest = async () => {
    setTesting(true);
    try {
      const res = await triggerTestPushNotification(currentUser);
      onNotify(res.message);
    } catch (e: any) {
      onNotify('Грешка: ' + (e.message || e));
    } finally {
      setTesting(false);
    }
  };

  const isGranted = status?.permission === 'granted';

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-white">
                Известия на телефона
              </h3>
              <p className="text-xs text-slate-400">
                Директни известия на заключен екран (iOS & Android)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STATUS & 1-CLICK TOGGLE */}
        <div className={`p-4 rounded-2xl border ${
          isGranted
            ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
            : 'bg-slate-950 border-slate-800 text-slate-300'
        } space-y-3`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Статус:
            </span>
            <span className={`text-xs font-black px-2.5 py-0.5 rounded-full ${
              isGranted
                ? 'bg-emerald-500 text-slate-950 shadow-xs'
                : 'bg-slate-800 text-slate-300'
            }`}>
              {isGranted ? '✓ ВКЛЮЧЕНИ' : 'ИЗКЛЮЧЕНИ'}
            </span>
          </div>

          <p className="text-xs text-slate-300">
            {isGranted
              ? 'Известията на телефона са активни. Можете да изпратите пробно известие, за да тествате как излиза.'
              : 'Включете системните известия с 1 клик, за да получавате напомняния за смени и ревизии.'}
          </p>

          <div className="flex items-center gap-2 flex-wrap pt-1">
            {isGranted ? (
              <>
                <button
                  type="button"
                  onClick={handleTest}
                  disabled={testing}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-md active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
                >
                  {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  <span>{testing ? 'Изпращане...' : 'Пробно известие'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleDisable}
                  disabled={loading}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-slate-400 hover:text-rose-400 text-xs font-semibold rounded-xl hover:bg-slate-800 transition-colors"
                >
                  <BellOff className="w-3.5 h-3.5" />
                  <span>Изключи</span>
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={handleEnable}
                disabled={loading}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black text-xs sm:text-sm rounded-xl shadow-lg shadow-amber-500/25 active:scale-95 transition-all disabled:opacity-50 cursor-pointer"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <BellRing className="w-4 h-4" />}
                <span>Включи известия на телефона</span>
              </button>
            )}
          </div>
        </div>

        {/* ALERTS SUMMARY */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-2">
            <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block text-[11px]">1 ч. преди смяна:</strong>
              <span className="text-slate-400 text-[10px]">Напомняне за обекта.</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block text-[11px]">Старт на смяна:</strong>
              <span className="text-slate-400 text-[10px]">Подкана за чекиране.</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block text-[11px]">Край на смяна:</strong>
              <span className="text-slate-400 text-[10px]">Напомняне за ревизия.</span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-2">
            <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block text-[11px]">Брак и липси:</strong>
              <span className="text-slate-400 text-[10px]">Известие до шефа.</span>
            </div>
          </div>
        </div>

        {/* iPhone Safari Guidance */}
        {status?.isIOS && !status?.isStandalone && (
          <div className="bg-amber-950/30 border border-amber-500/30 rounded-2xl p-3 space-y-1.5 text-xs">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold">
              <Smartphone className="w-4 h-4" />
              <span>За Apple iPhone:</span>
            </div>
            <p className="text-slate-300 text-[11px]">
              Натиснете <strong>Сподели (Share)</strong> в Safari → <strong>„Добави към началния екран“</strong>, за да излизат външни известия.
            </p>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-bold rounded-xl"
          >
            Затвори
          </button>
        </div>
      </div>
    </div>
  );
};
