import React from 'react';
import { PendingApproval, Venue } from '../types';
import { AlertOctagon, Check, X, ShieldAlert, Clock, User, Building2 } from 'lucide-react';

interface ApprovalsModalProps {
  isOpen: boolean;
  onClose: () => void;
  approvals: PendingApproval[];
  venues: Venue[];
  onApprove: (approvalId: string) => void;
  onReject: (approvalId: string, reviewNote?: string) => void;
}

export const ApprovalsModal: React.FC<ApprovalsModalProps> = ({
  isOpen,
  onClose,
  approvals,
  venues,
  onApprove,
  onReject,
}) => {
  if (!isOpen) return null;

  const pendingList = approvals.filter((a) => a.status === 'pending');
  const pastList = approvals.filter((a) => a.status !== 'pending').slice(0, 10);

  const getVenueName = (vId: string) => {
    return venues.find((v) => v.id === vId)?.name || vId;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                <span>Заявки за брак и липси</span>
                {pendingList.length > 0 && (
                  <span className="bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                    {pendingList.length} чакащи
                  </span>
                )}
              </h3>
              <p className="text-xs text-slate-400">Шеф контрол над отписването на счупен инвентар</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="space-y-4 overflow-y-auto flex-1 pr-1">
          {pendingList.length === 0 ? (
            <div className="p-8 text-center text-slate-400 space-y-2 bg-slate-950/60 rounded-2xl border border-slate-800">
              <Check className="w-8 h-8 text-emerald-400 mx-auto" />
              <p className="text-sm font-bold text-white">Няма чакащи заявки за брак</p>
              <p className="text-xs">Всички отписвания на инвентар са прегледани.</p>
            </div>
          ) : (
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                Чакащи одобрение ({pendingList.length})
              </h4>
              {pendingList.map((req) => (
                <div
                  key={req.id}
                  className="bg-slate-950 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-4 space-y-3 transition-colors shadow-md"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-extrabold text-white">{req.itemName}</span>
                      <span className="text-xs font-bold px-2 py-0.5 rounded-lg bg-slate-800 text-slate-300 flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-amber-400" />
                        {getVenueName(req.venueId)}
                      </span>
                      <span className="text-xs font-bold px-2 py-0.5 rounded-lg bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        -{req.quantityReduced} бр.
                      </span>
                    </div>

                    <div className="text-right text-[11px] text-slate-400 flex items-center gap-1.5 sm:self-center">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>{new Date(req.createdAt).toLocaleString('bg-BG', { dateStyle: 'short', timeStyle: 'short' })}</span>
                    </div>
                  </div>

                  {/* Reason & Staff */}
                  <div className="space-y-1.5 text-xs">
                    <div className="flex items-center gap-1.5 text-slate-400">
                      <User className="w-3.5 h-3.5 text-slate-500" />
                      <span>Заявено от: <strong className="text-slate-200">{req.staffName}</strong></span>
                    </div>
                    <div className="p-3 bg-rose-950/20 border border-rose-500/30 rounded-xl text-rose-200 text-xs font-medium">
                      <strong>Причина:</strong> {req.reason}
                    </div>
                  </div>

                  {/* Action buttons */}
                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      onClick={() => onReject(req.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-rose-950/60 hover:text-rose-300 text-slate-300 text-xs font-bold rounded-xl border border-slate-700 transition-colors"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Отхвърли</span>
                    </button>
                    <button
                      onClick={() => onApprove(req.id)}
                      className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow-md transition-all active:scale-95"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Одобри и обнови наличността</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Past History */}
          {pastList.length > 0 && (
            <div className="space-y-2 pt-4 border-t border-slate-800">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                История на предходни заявки
              </h4>
              <div className="space-y-1.5">
                {pastList.map((hist) => (
                  <div
                    key={hist.id}
                    className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-xl flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white">{hist.itemName}</span>
                        <span className="text-slate-400">({getVenueName(hist.venueId)})</span>
                        <span className="text-slate-400">-{hist.quantityReduced} бр.</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5 truncate max-w-sm">
                        Причина: {hist.reason}
                      </p>
                    </div>

                    <div className="shrink-0 text-right">
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${
                        hist.status === 'approved'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      }`}>
                        {hist.status === 'approved' ? '✓ Одобрена' : '✗ Отхвърлена'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
