import React, { useState } from 'react';
import { Venue } from '../types';
import { Building2, Plus, Power, PowerOff, X, Check, Edit2 } from 'lucide-react';

interface ManageVenuesModalProps {
  isOpen: boolean;
  onClose: () => void;
  venues: Venue[];
  onSaveVenues: (venues: Venue[]) => void;
  onNotify: (msg: string) => void;
}

export const ManageVenuesModal: React.FC<ManageVenuesModalProps> = ({
  isOpen,
  onClose,
  venues,
  onSaveVenues,
  onNotify,
}) => {
  const [showAddForm, setShowAddForm] = useState(false);
  const [name, setName] = useState('');
  const [tagline, setTagline] = useState('');
  const [shortCode, setShortCode] = useState('');
  const [colorScheme, setColorScheme] = useState<'amber' | 'emerald' | 'rose' | 'purple' | 'cyan'>('purple');

  if (!isOpen) return null;

  const handleToggleActive = (venueId: string) => {
    const updated = venues.map((v) => {
      if (v.id === venueId) {
        const nextActive = v.isActive === false ? true : false;
        return { ...v, isActive: nextActive };
      }
      return v;
    });
    onSaveVenues(updated);
    const target = updated.find((v) => v.id === venueId);
    onNotify(target?.isActive ? `Заведението "${target.name}" е активирано!` : `Заведението "${target?.name}" е деактивирано и скрито от графика.`);
  };

  const handleCreateVenue = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || `venue-${Date.now().toString(36)}`;
    
    // Check if slug exists
    if (venues.some((v) => v.id === slug)) {
      alert('Заведение с такова име или идентификатор вече съществува!');
      return;
    }

    const themeColors = {
      amber: {
        bg: 'bg-amber-600',
        text: 'text-amber-700',
        border: 'border-amber-500',
        badgeBg: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
        badgeText: 'text-amber-400',
        accent: '#d97706',
        lightBg: 'bg-amber-950/20',
      },
      emerald: {
        bg: 'bg-emerald-600',
        text: 'text-emerald-700',
        border: 'border-emerald-500',
        badgeBg: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
        badgeText: 'text-emerald-400',
        accent: '#059669',
        lightBg: 'bg-emerald-950/20',
      },
      rose: {
        bg: 'bg-rose-700',
        text: 'text-rose-700',
        border: 'border-rose-500',
        badgeBg: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
        badgeText: 'text-rose-400',
        accent: '#be123c',
        lightBg: 'bg-rose-950/20',
      },
      purple: {
        bg: 'bg-purple-600',
        text: 'text-purple-700',
        border: 'border-purple-500',
        badgeBg: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
        badgeText: 'text-purple-400',
        accent: '#9333ea',
        lightBg: 'bg-purple-950/20',
      },
      cyan: {
        bg: 'bg-cyan-600',
        text: 'text-cyan-700',
        border: 'border-cyan-500',
        badgeBg: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
        badgeText: 'text-cyan-400',
        accent: '#0891b2',
        lightBg: 'bg-cyan-950/20',
      },
    };

    const newVenue: Venue = {
      id: slug,
      name: name.trim(),
      tagline: tagline.trim() || 'Бар & Наргилета',
      shortCode: shortCode.trim().toUpperCase() || name.substring(0, 2).toUpperCase(),
      isActive: true,
      themeColor: themeColors[colorScheme],
    };

    const updated = [...venues, newVenue];
    onSaveVenues(updated);
    setShowAddForm(false);
    setName('');
    setTagline('');
    setShortCode('');
    onNotify(`Добавено е ново заведение: "${newVenue.name}"!`);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">Управление на заведения (Обекти)</h3>
              <p className="text-xs text-slate-400">Шеф панел: активиране, деактивиране и добавяне</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="space-y-4 overflow-y-auto flex-1 pr-1">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Списък обекти ({venues.length})
            </span>
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all active:scale-95"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{showAddForm ? 'Скрий формата' : 'Добави ново заведение'}</span>
            </button>
          </div>

          {/* Add form */}
          {showAddForm && (
            <form onSubmit={handleCreateVenue} className="bg-slate-950 p-4 rounded-2xl border border-amber-500/40 space-y-3">
              <h4 className="text-xs font-bold text-white">Ново заведение</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Име на заведението *</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="напр. Ресторант Панорама"
                    required
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-2.5 font-bold focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-300 mb-1">Кратък код (2 букви)</label>
                  <input
                    type="text"
                    value={shortCode}
                    onChange={(e) => setShortCode(e.target.value)}
                    placeholder="RP"
                    maxLength={3}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-2.5 font-bold uppercase focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
              <div className="text-xs">
                <label className="block font-semibold text-slate-300 mb-1">Слоган / Описание</label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  placeholder="напр. Луксозен лаундж бар"
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl p-2.5 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Color Scheme Picker */}
              <div className="text-xs">
                <label className="block font-semibold text-slate-300 mb-1.5">Цветова тема</label>
                <div className="flex items-center gap-2">
                  {(['amber', 'emerald', 'rose', 'purple', 'cyan'] as const).map((col) => (
                    <button
                      key={col}
                      type="button"
                      onClick={() => setColorScheme(col)}
                      className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all ${
                        colorScheme === col ? 'ring-2 ring-white scale-110' : 'opacity-70 hover:opacity-100'
                      } ${
                        col === 'amber' ? 'bg-amber-600' :
                        col === 'emerald' ? 'bg-emerald-600' :
                        col === 'rose' ? 'bg-rose-700' :
                        col === 'purple' ? 'bg-purple-600' : 'bg-cyan-600'
                      }`}
                    >
                      {colorScheme === col && <Check className="w-3.5 h-3.5 text-white" />}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-3 py-1.5 bg-slate-800 text-slate-300 text-xs font-bold rounded-xl"
                >
                  Отказ
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-amber-500 text-slate-950 text-xs font-black rounded-xl hover:bg-amber-400"
                >
                  Запази заведението
                </button>
              </div>
            </form>
          )}

          {/* Venues List */}
          <div className="space-y-2.5">
            {venues.map((venue) => {
              const isActive = venue.isActive !== false;

              return (
                <div
                  key={venue.id}
                  className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-3 ${
                    isActive
                      ? 'bg-slate-950 border-slate-800 hover:border-slate-700'
                      : 'bg-slate-950/40 border-slate-900 opacity-60'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={`w-4 h-4 rounded-full shrink-0 ${venue.themeColor.bg}`} />
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-extrabold text-white">{venue.name}</h4>
                        <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-800 text-slate-400">
                          {venue.shortCode}
                        </span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          isActive
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                        }`}>
                          {isActive ? 'Активно' : 'Деактивирано'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{venue.tagline}</p>
                    </div>
                  </div>

                  {/* Toggle Active Switch */}
                  <button
                    onClick={() => handleToggleActive(venue.id)}
                    className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                      isActive
                        ? 'bg-slate-800 hover:bg-rose-950/60 hover:text-rose-300 text-slate-300 border border-slate-700'
                        : 'bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/40'
                    }`}
                    title={isActive ? 'Деактивирай (няма да се вижда в графика)' : 'Активирай за графика'}
                  >
                    {isActive ? (
                      <>
                        <PowerOff className="w-3.5 h-3.5 text-rose-400" />
                        <span>Деактивирай</span>
                      </>
                    ) : (
                      <>
                        <Power className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Активирай</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
