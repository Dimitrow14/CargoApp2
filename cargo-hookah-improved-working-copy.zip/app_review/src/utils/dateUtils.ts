export const BG_DAYS = [
  'Понеделник',
  'Вторник',
  'Сряда',
  'Четвъртък',
  'Петък',
  'Събота',
  'Неделя',
];

export const BG_DAYS_SHORT = [
  'Пон',
  'Вто',
  'Сря',
  'Чет',
  'Пет',
  'Съб',
  'Нед',
];

export const BG_MONTHS = [
  'Януари',
  'Февруари',
  'Март',
  'Април',
  'Май',
  'Юни',
  'Юли',
  'Август',
  'Септември',
  'Октомври',
  'Ноември',
  'Декември',
];

export interface DayInfo {
  date: string; // YYYY-MM-DD
  dayName: string;
  dayShort: string;
  dayNumber: number;
  monthName: string;
  isToday: boolean;
  isWeekend: boolean;
}

// Format Date object to YYYY-MM-DD
export function formatDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Parse YYYY-MM-DD safely into Date (local time)
export function parseDate(dateStr: string): Date {
  const [y, m, d] = dateStr.split('-').map(Number);
  return new Date(y, m - 1, d);
}

// Get the Monday of the week for a given date
export function getMonday(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay();
  // In JS getDay(): 0 is Sunday, 1 is Monday ... 6 is Saturday
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

// Generate the 7 days of the week starting from Monday
export function getWeekDays(monday: Date): DayInfo[] {
  const todayStr = formatDate(new Date());
  const days: DayInfo[] = [];

  for (let i = 0; i < 7; i++) {
    const current = new Date(monday);
    current.setDate(monday.getDate() + i);
    const dateStr = formatDate(current);

    days.push({
      date: dateStr,
      dayName: BG_DAYS[i],
      dayShort: BG_DAYS_SHORT[i],
      dayNumber: current.getDate(),
      monthName: BG_MONTHS[current.getMonth()],
      isToday: dateStr === todayStr,
      isWeekend: i === 5 || i === 6,
    });
  }

  return days;
}

// Format week range label e.g. "28 Септември - 4 Октомври 2026"
export function formatWeekRange(monday: Date): string {
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  const startDay = monday.getDate();
  const startMonth = BG_MONTHS[monday.getMonth()];
  const endDay = sunday.getDate();
  const endMonth = BG_MONTHS[sunday.getMonth()];
  const year = sunday.getFullYear();

  if (monday.getMonth() === sunday.getMonth()) {
    return `${startDay} - ${endDay} ${startMonth} ${year}`;
  }
  return `${startDay} ${startMonth} - ${endDay} ${endMonth} ${year}`;
}

// Shift duration calculation in hours
export function calculateHours(start: string, end: string): number {
  if (!start || !end) return 8;
  const [sh, sm] = start.split(':').map(Number);
  const [eh, em] = end.split(':').map(Number);
  let startMinutes = sh * 60 + sm;
  let endMinutes = eh * 60 + em;
  if (endMinutes <= startMinutes) {
    // Crosses midnight
    endMinutes += 24 * 60;
  }
  const diff = (endMinutes - startMinutes) / 60;
  return Math.round(diff * 10) / 10;
}

// Generate selectable recent date options for dropdown select menus
export function getRecentDateOptions(count = 14): Array<{ value: string; label: string; isToday: boolean }> {
  const options: Array<{ value: string; label: string; isToday: boolean }> = [];
  const today = new Date();
  const todayStr = formatDate(today);

  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const yesterdayStr = formatDate(yesterday);

  const dayBeforeYesterday = new Date(today);
  dayBeforeYesterday.setDate(today.getDate() - 2);
  const dayBeforeYesterdayStr = formatDate(dayBeforeYesterday);

  for (let i = 0; i < count; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    const dateStr = formatDate(d);
    // In JS getDay(): 0 is Sunday, 1 is Monday ... 6 is Saturday
    const dayOfWeek = BG_DAYS[d.getDay() === 0 ? 6 : d.getDay() - 1];
    const dayNum = d.getDate();
    const month = BG_MONTHS[d.getMonth()];

    let prefix = '';
    if (dateStr === todayStr) {
      prefix = '🟢 ДНЕС — ';
    } else if (dateStr === yesterdayStr) {
      prefix = 'ВЧЕРА — ';
    } else if (dateStr === dayBeforeYesterdayStr) {
      prefix = 'ЗАВЧЕРА — ';
    }

    options.push({
      value: dateStr,
      label: `${prefix}${dayOfWeek}, ${dayNum} ${month} (${dateStr})`,
      isToday: dateStr === todayStr,
    });
  }

  return options;
}
