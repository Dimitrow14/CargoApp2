import React, { useState } from 'react';
import { VenueId, VenuePricing } from '../types';
import { VENUES } from '../data/initialData';
import { Settings, Euro, Check, RefreshCw, X, ShieldAlert } from 'lucide-react';

interface PricingModalProps {
  isOpen: boolean;
  onClose: () => void;
  pricing: Record<VenueId, VenuePricing>;
  onSavePricing: (pricing: Record<VenueId, VenuePricing>) => void;
  onNotify: (msg: string) => void;
}

export const PricingModal: React.FC<PricingModalProps> = ({
  isOpen,
  onClose,
  pricing,
  onSavePricing,
  onNotify,
}) => {
  const [currentPricing, setCurrentPricing] = useState<Record<VenueId, VenuePricing>>(pricing);

  if (!isOpen) return null;

  const handleChange = (
    venueId: VenueId,
    field: 'yellowPriceEur' | 'blackPriceEur' | 'officialPriceEur',
    val: number
  ) => {
    const updated = {
      ...currentPricing,
      [venueId]: {
        ...currentPricing[venueId],
        [field]: Math.max(0, val),
      },
    };
    setCurrentPricing(updated);
    // Auto-save immediately upon any price change
    onSavePricing(updated);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSavePricing(currentPricing);
    onNotify('Цените са запазени!');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl space-y-6 my-8">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Euro className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Ценообразуване на наргилета</h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Pricing Form by Venue */}
        <form onSubmit={handleSave} className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {VENUES.map((venue) => {
              const vp = currentPricing[venue.id] || {
                venueId: venue.id,
                yellowPriceEur: 15,
                blackPriceEur: 18,
                officialPriceEur: 0,
              };

              return (
                <div
                  key={venue.id}
                  className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-4 shadow-md"
                >
                  <div className="flex items-center gap-2 border-b border-slate-800 pb-2.5">
                    <span className={`w-3 h-3 rounded-full ${venue.themeColor.bg}`} />
                    <h4 className="text-sm font-bold text-white">{venue.name}</h4>
                  </div>

                  {/* Жълто */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-semibold text-amber-300">
                      <span>🟡 Жълто:</span>
                    </div>
                    <div className="relative">
                      <input
                        type="number"
                        min="0"
                        step="0.5"
                        value={vp.yellowPriceEur}
                        onChange={(e) =>
                          handleChange(venue.id, 'yellowPriceEur', parseFloat(e.target.value) || 0)
                        }
                        className="w-full bg-slate-900 border border-slate-700 text-white font-bold text-base rounded-xl px-3 py-2 pr-8 focus:outline-none focus:border-amber-500"
                        required
                      />
                      <span className="absolute right-3 top-2.5 text-xs font-bold text-slate-400">€</span>
                    </div>
                  </div>

                  {/* Черно */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
                      <span>⚫ Черно:</span>
                    </div>
                    <div className="relative">
                      <input
                        type="number"
                        min="0"
                        step="0.5"
                        value={vp.blackPriceEur}
                        onChange={(e) =>
                          handleChange(venue.id, 'blackPriceEur', parseFloat(e.target.value) || 0)
                        }
                        className="w-full bg-slate-900 border border-slate-700 text-white font-bold text-base rounded-xl px-3 py-2 pr-8 focus:outline-none focus:border-amber-500"
                        required
                      />
                      <span className="absolute right-3 top-2.5 text-xs font-bold text-slate-400">€</span>
                    </div>
                  </div>

                  {/* Служебно */}
                  <div className="space-y-1 pt-1 border-t border-slate-900">
                    <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium">
                      <span>Служебно:</span>
                    </div>
                    <div className="relative">
                      <input
                        type="number"
                        min="0"
                        step="0.5"
                        value={vp.officialPriceEur}
                        onChange={(e) =>
                          handleChange(venue.id, 'officialPriceEur', parseFloat(e.target.value) || 0)
                        }
                        className="w-full bg-slate-900 border border-slate-800 text-slate-300 text-xs rounded-xl px-3 py-1.5 pr-8 focus:outline-none focus:border-amber-500"
                      />
                      <span className="absolute right-3 top-2 text-[11px] font-bold text-slate-500">€</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl transition-colors"
            >
              Затвори
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-extrabold rounded-xl shadow-lg transition-all flex items-center gap-2"
            >
              <Check className="w-4 h-4" />
              <span>Запази</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
