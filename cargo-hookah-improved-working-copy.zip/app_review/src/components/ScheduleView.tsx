import React, { useState, useMemo } from 'react';
import { 
  Shift, 
  VenueId, 
  Venue,
  UserAccount, 
  ShiftConflict 
} from '../types';
import { VENUES } from '../data/initialData';
import { DayInfo, formatWeekRange } from '../utils/dateUtils';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Copy, 
  Trash2, 
  AlertTriangle,
  Clock,
  ShieldCheck
} from 'lucide-react';

interface ScheduleViewProps {
  days: DayInfo[];
  selectedMonday: Date;
  onSelectMonday: (date: Date) => void;
  shifts: Shift[];
  allUsers: UserAccount[];
  currentUser: UserAccount;
  venues?: Venue[];
  conflicts: ShiftConflict[];
  onAddShift: (venueId: VenueId, date: string, staffId?: string) => void;
  onEditShift: (shift: Shift) => void;
  onDeleteShift: (shiftId: string) => void;
  onCopyFromPreviousWeek: () => void;
}

export const ScheduleView: React.FC<ScheduleViewProps> = ({
  days,
  selectedMonday,
  onSelectMonday,
  shifts,
  allUsers,
  currentUser,
  venues = [],
  conflicts,
  onAddShift,
  onEditShift,
  onDeleteShift,
  onCopyFromPreviousWeek,
}) => {
  const isBossOrAdmin = currentUser.role === 'boss' || currentUser.role === 'admin';
  // Strictly boss or admin only can manage (add, edit, delete) schedule
  const canManageSchedule = isBossOrAdmin;

  const [selectedVenueFilter, setSelectedVenueFilter] = useState<VenueId | 'all'>('all');
  // For standard employees, schedule is strictly locked to personal view ('my')
  const [scheduleScope, setScheduleScope] = useState<'my' | 'all'>(isBossOrAdmin ? 'all' : 'my');

  // Ensure employees cannot view all schedules
  const effectiveScope = isBossOrAdmin ? scheduleScope : 'my';

  const handlePrevWeek = () => {
    const prev = new Date(selectedMonday);
    prev.setDate(prev.getDate() - 7);
    onSelectMonday(prev);
  };

  const handleNextWeek = () => {
    const next = new Date(selectedMonday);
    next.setDate(next.getDate() + 7);
    onSelectMonday(next);
  };

  // Deactivated venues should not appear in the daily schedule selection
  const activeVenues = (venues && venues.length > 0 ? venues : VENUES).filter((v) => v.isActive !== false);

  const venuesToShow = selectedVenueFilter === 'all'
    ? activeVenues
    : activeVenues.filter((v) => v.id === selectedVenueFilter);

  // Filter shifts based on scope: if 'my', only show shifts for currentUser
  const getFilteredShiftsForVenueAndDay = (venueId: string, date: string) => {
    return shifts.filter((s) => {
      if (s.venueId !== venueId || s.date !== date) return false;
      if (effectiveScope === 'my') {
        return s.staffId === currentUser.id;
      }
      return true;
    });
  };

  // Count my shifts this week
  const myShiftsThisWeekCount = useMemo(() => {
    const weekDates = new Set(days.map((d) => d.date));
    return shifts.filter((s) => s.staffId === currentUser.id && weekDates.has(s.date)).length;
  }, [shifts, currentUser.id, days]);

  return (
    <div className="space-y-6">
      {/* Week Navigation & Controls */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        {/* Left: Week navigation + Scope toggle */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
          <div className="flex items-center justify-between bg-slate-950 p-1 rounded-xl border border-slate-800 w-full sm:w-auto">
            <button
              onClick={handlePrevWeek}
              className="p-2 sm:p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Предишна седмица"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <div className="px-3 py-1 text-xs sm:text-sm font-bold text-white flex items-center justify-center gap-2">
              <CalendarIcon className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{formatWeekRange(selectedMonday)}</span>
            </div>
            <button
              onClick={handleNextWeek}
              className="p-2 sm:p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              title="Следваща седмица"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Scope Controls: Boss/Admin get toggle; Standard Employees strictly see read-only personal schedule */}
          {isBossOrAdmin ? (
            <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => setScheduleScope('my')}
                className={`py-1.5 px-3 rounded-lg font-bold transition-all cursor-pointer ${
                  scheduleScope === 'my'
                    ? 'bg-amber-500 text-slate-950 shadow-sm shadow-amber-500/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Личен график ({myShiftsThisWeekCount})
              </button>
              <button
                type="button"
                onClick={() => setScheduleScope('all')}
                className={`py-1.5 px-3 rounded-lg font-bold transition-all cursor-pointer ${
                  scheduleScope === 'all'
                    ? 'bg-slate-800 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Общ график
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 px-3 py-2 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300 font-bold">
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Личен график ({myShiftsThisWeekCount} смени) • Само за четене</span>
            </div>
          )}

          {canManageSchedule && (
            <button
              onClick={onCopyFromPreviousWeek}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors w-full sm:w-auto cursor-pointer"
              title="Копирай смените от предишната седмица"
            >
              <Copy className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Копирай от минала седмица</span>
              <span className="sm:hidden">Копирай</span>
            </button>
          )}
        </div>

        {/* Venue filter */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
          <div className="grid grid-cols-4 sm:flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs w-full sm:w-auto gap-0.5">
            <button
              onClick={() => setSelectedVenueFilter('all')}
              className={`py-1.5 px-1 sm:px-3 rounded-lg font-bold text-center transition-all truncate text-xs cursor-pointer ${
                selectedVenueFilter === 'all'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Всички
            </button>
            {activeVenues.map((v) => (
              <button
                key={v.id}
                onClick={() => setSelectedVenueFilter(v.id)}
                className={`py-1.5 px-1 sm:px-2.5 rounded-lg font-bold text-center transition-all truncate text-xs cursor-pointer ${
                  selectedVenueFilter === v.id
                    ? `${v.themeColor.bg} text-white`
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {v.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Conflict banner */}
      {conflicts.length > 0 && (
        <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-2xl flex items-center justify-between text-xs text-rose-300">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="font-bold">
              Внимание: Засечено е застъпване на служител в 2 заведения на една и съща дата!
            </span>
          </div>
        </div>
      )}

      {/* Schedule Grid by Venue & Days */}
      <div className="space-y-6">
        {venuesToShow.map((venue) => {
          const venueShifts = shifts.filter((s) => s.venueId === venue.id);

          return (
            <div
              key={venue.id}
              className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl"
            >
              {/* Ultra-Clean Venue Header */}
              <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
                <div className="flex items-center gap-3">
                  <div className={`w-3.5 h-3.5 rounded-full ${venue.themeColor.bg}`} />
                  <h3 className="text-base sm:text-lg font-extrabold text-white">{venue.name}</h3>
                </div>
              </div>

              {/* 7 Days Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-7 divide-y md:divide-y-0 md:divide-x divide-slate-800">
                {days.map((day) => {
                  const dayShifts = getFilteredShiftsForVenueAndDay(venue.id, day.date);

                  return (
                    <div
                      key={day.date}
                      className={`p-3 min-h-[170px] flex flex-col justify-between ${
                        day.isToday ? 'bg-amber-500/5' : ''
                      }`}
                    >
                      {/* Day Header */}
                      <div className="mb-2.5">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                          {day.dayName}
                        </span>
                        <p className={`text-sm font-black ${day.isToday ? 'text-amber-400 font-bold' : 'text-slate-200'}`}>
                          {day.dayNumber} {day.monthName.substring(0, 3)}
                        </p>
                      </div>

                      {/* Shifts list + Manager "+ Смяна" button */}
                      <div className="space-y-2 flex-1 flex flex-col justify-between">
                        <div className="space-y-1.5">
                          {dayShifts.length === 0 && effectiveScope === 'my' && (
                            <span className="text-[10px] text-slate-600 block italic py-1">
                              Нямате смяна
                            </span>
                          )}

                          {dayShifts.map((shift) => {
                            const isMyShift = shift.staffId === currentUser.id;

                            return (
                              <div
                                key={shift.id}
                                onClick={() => canManageSchedule && onEditShift(shift)}
                                className={`group relative rounded-xl p-2.5 transition-all shadow-xs space-y-1 select-none ${
                                  isMyShift
                                    ? 'bg-amber-500/10 border-2 border-amber-400/80 shadow-amber-500/10'
                                    : 'bg-slate-950 border border-slate-800'
                                } ${canManageSchedule ? 'hover:border-amber-500/60 cursor-pointer' : ''}`}
                              >
                                <div className="flex items-center justify-between gap-1">
                                  <div className="flex items-center gap-1.5 min-w-0">
                                    <span className={`text-xs sm:text-sm font-bold truncate ${isMyShift ? 'text-amber-300' : 'text-white'}`}>
                                      {shift.staffName}
                                    </span>
                                    {isMyShift && (
                                      <span className="text-[9px] bg-amber-400 text-slate-950 px-1 py-0.2 rounded font-black shrink-0">
                                        Аз
                                      </span>
                                    )}
                                  </div>
                                  
                                  {canManageSchedule && (
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        if (confirm(`Премахване на смяната на ${shift.staffName}?`)) {
                                          onDeleteShift(shift.id);
                                        }
                                      }}
                                      className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/20 rounded-lg transition-colors shrink-0 cursor-pointer"
                                      title="Премахни смяната"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </div>

                                <div className="flex items-center justify-between gap-1 text-[11px] text-slate-400">
                                  <span>{shift.startTime} - {shift.endTime}</span>
                                  {shift.clockInTimeString && (
                                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded font-bold border border-emerald-500/30 flex items-center gap-1 shrink-0">
                                      <ShieldCheck className="w-3 h-3 text-emerald-400" />
                                      <span>От {shift.clockInTimeString}</span>
                                    </span>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {/* Large "+ Смяна" button - Manager only */}
                        {canManageSchedule && (
                          <button
                            type="button"
                            onClick={() => onAddShift(venue.id, day.date)}
                            className="w-full mt-2 py-2 px-2 border-2 border-dashed border-slate-800 hover:border-amber-500/60 bg-slate-950/40 hover:bg-amber-500/10 rounded-xl text-center cursor-pointer group text-slate-400 hover:text-amber-300 text-xs font-bold transition-all active:scale-98"
                          >
                            + Смяна
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
