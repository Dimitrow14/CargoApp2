import React, { useState, useMemo, useRef } from 'react';
import { 
  ShiftReport, 
  Venue, 
  Shift, 
  UserAccount, 
  WageSettings, 
  DailyRevision,
  TobaccoRevisionDetail
} from '../types';
import { formatDate } from '../utils/dateUtils';
import { 
  FileText, 
  Camera, 
  Upload, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  Lock, 
  Check, 
  Trash2, 
  Image as ImageIcon, 
  Clock, 
  ShieldCheck,
  Send,
  Loader2,
  AlertOctagon,
  Award
} from 'lucide-react';

const SLACK_WEBHOOK_URL = 'https://hooks.slack.com/services/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';

interface ReportsViewProps {
  reports: ShiftReport[];
  venues: Venue[];
  revisions: DailyRevision[];
  shifts: Shift[];
  currentUser: UserAccount;
  wageSettings?: WageSettings;
  onAddReport: (report: Omit<ShiftReport, 'id' | 'createdAt' | 'baseWageEur' | 'hookahBonusEur' | 'totalEarnedEur'>) => Promise<void> | void;
  onDeleteReport: (id: string) => void;
  onCompleteShift?: (shiftId: string) => Promise<void> | void;
  onNavigateToRevision: () => void;
  onNotify: (msg: string) => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  reports,
  venues,
  revisions,
  shifts,
  currentUser,
  wageSettings,
  onAddReport,
  onDeleteReport,
  onCompleteShift,
  onNavigateToRevision,
  onNotify,
}) => {
  const activeVenues = venues.filter((v) => v.isActive !== false);
  const isBossOrAdmin = currentUser.role === 'boss' || currentUser.role === 'admin';
  const todayStr = formatDate(new Date());

  // Find user's assigned venue today or default to first
  const todayShift = shifts.find(
    (s) => s.staffId === currentUser.id && s.date === todayStr
  );
  const defaultVenueId = todayShift?.venueId || activeVenues[0]?.id || 'bar-hey';

  const [selectedVenueId, setSelectedVenueId] = useState<string>(defaultVenueId);
  const [totalHookahs, setTotalHookahs] = useState<string>('');
  const [yellowHookahs, setYellowHookahs] = useState<string>('0');
  const [blackHookahs, setBlackHookahs] = useState<string>('0');
  const [isOfficial, setIsOfficial] = useState(false);
  const [officialCount, setOfficialCount] = useState<string>('0');
  const [notes, setNotes] = useState('');

  // Cash Register / Receipt Photo ONLY (Tax stamps completely removed)
  const [receiptPhotoUrl, setReceiptPhotoUrl] = useState<string>('');
  const [isUploadingReceipt, setIsUploadingReceipt] = useState(false);
  const receiptInputRef = useRef<HTMLInputElement>(null);

  // Separate states for Step 2 (Save Report) and Step 3 (Final End Shift)
  const [isSavingReport, setIsSavingReport] = useState(false);
  const [justSavedReport, setJustSavedReport] = useState(false);
  const [isEndingShift, setIsEndingShift] = useState(false);
  const [shiftJustCompleted, setShiftJustCompleted] = useState(false);

  // Shift Verification: Employee MUST have an active shift today at this venue
  const activeShiftForVenue = shifts.find(
    (s) => s.staffId === currentUser.id && s.venueId === selectedVenueId && s.date === todayStr
  );
  const isOnShift = isBossOrAdmin || Boolean(activeShiftForVenue);
  const isShiftOfficiallyCompleted = Boolean(activeShiftForVenue?.isCompleted) || shiftJustCompleted;

  // STEP 1 CHECK: Tobacco revision for this venue today
  const todayRevision = useMemo(() => {
    return revisions.find(
      (r) => r.venueId === selectedVenueId && r.date === todayStr
    );
  }, [revisions, selectedVenueId, todayStr]);

  const isRevisionDone = Boolean(todayRevision);

  // STEP 2 CHECK: Saved report for this venue today
  const todaySavedReport = useMemo(() => {
    return reports.find(
      (r) => r.venueId === selectedVenueId && r.date === todayStr && (isBossOrAdmin ? true : r.staffId === currentUser.id)
    );
  }, [reports, selectedVenueId, todayStr, currentUser.id, isBossOrAdmin]);

  const isReportDone = Boolean(todaySavedReport) || justSavedReport;

  // Numbers breakdown
  const numTotal = parseInt(totalHookahs, 10) || 0;
  const numYellow = parseInt(yellowHookahs, 10) || 0;
  const numBlack = parseInt(blackHookahs, 10) || 0;
  const numOfficial = isOfficial ? (parseInt(officialCount, 10) || 0) : 0;

  // Earnings calculation preview
  const baseRate = currentUser.customBaseWageEur ?? (wageSettings?.baseWageEur ?? 23);
  const hookahRate = currentUser.customHookahRateEur ?? (wageSettings?.hookahRateEur ?? 1);
  const earnedTotal = baseRate + (numTotal * hookahRate);

  // Receipt Photo Handler
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingReceipt(true);
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setReceiptPhotoUrl(dataUrl);
      setIsUploadingReceipt(false);
      onNotify('Снимката на отчета/бона е качена успешно!');
    };
    reader.onerror = () => {
      onNotify('Грешка при четене на снимката.');
      setIsUploadingReceipt(false);
    };
    reader.readAsDataURL(file);
  };

  // STEP 2: Save Report Button (ONLY saves report data to Firebase; does NOT fire Slack)
  const handleSaveReport = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!isOnShift) {
      onNotify('Нямате активна смяна за този обект днес.');
      return;
    }

    if (numTotal <= 0) {
      onNotify('Грешка: Въведете брой направени наргилета!');
      return;
    }

    if (numYellow + numBlack > numTotal) {
      onNotify('Грешка: Сборът на жълти и черни наргилета не може да надвишава общия брой!');
      return;
    }

    setIsSavingReport(true);
    try {
      await onAddReport({
        date: todayStr,
        venueId: selectedVenueId,
        staffId: currentUser.id,
        staffName: currentUser.name,
        totalHookahs: numTotal,
        yellowHookahs: numYellow,
        blackHookahs: numBlack,
        isOfficialComplimentary: isOfficial,
        officialHookahsCount: numOfficial,
        photoUrl: receiptPhotoUrl || '',
        revisionId: todayRevision?.id,
        notes: notes.trim() || undefined,
      });

      setJustSavedReport(true);
      const currentVenue = activeVenues.find((v) => v.id === selectedVenueId);
      const venueName = currentVenue?.name || selectedVenueId;
      onNotify(`✓ Отчетът за ${venueName} е запазен успешно в базата данни!`);
    } catch (err: any) {
      console.error('Error saving daily report to Firebase:', err);
      onNotify('Възникна грешка при запис на отчета.');
    } finally {
      setIsSavingReport(false);
    }
  };

  // STEP 3: Final End Shift Handler (Fires Slack Webhook & marks shift as officially completed)
  const handleFinalEndShift = async () => {
    if (!isOnShift) {
      onNotify('Нямате активна смяна за този обект днес.');
      return;
    }

    if (!isRevisionDone) {
      onNotify('Грешка: Първо трябва да попълните Ревизията на тютюните (Стъпка 1)!');
      return;
    }

    if (!isReportDone) {
      onNotify('Грешка: Първо трябва да запазите Дневния отчет (Стъпка 2)!');
      return;
    }

    setIsEndingShift(true);
    try {
      const currentVenue = activeVenues.find((v) => v.id === selectedVenueId);
      const venueName = currentVenue?.name || selectedVenueId;

      // Extract details from saved revision and report
      const repData = todaySavedReport || {
        totalHookahs: numTotal,
        yellowHookahs: numYellow,
        blackHookahs: numBlack,
        isOfficialComplimentary: isOfficial,
        officialHookahsCount: numOfficial,
        photoUrl: receiptPhotoUrl,
        notes: notes.trim(),
      };

      // Format Date in DD.MM.YYYY
      const formatDDMMYYYY = (dateStr: string) => {
        const parts = dateStr.split('-');
        if (parts.length === 3) {
          const [y, m, d] = parts;
          return `${d.padStart(2, '0')}.${m.padStart(2, '0')}.${y}`;
        }
        const d = new Date();
        const day = String(d.getDate()).padStart(2, '0');
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const year = d.getFullYear();
        return `${day}.${month}.${year}`;
      };

      const formattedDate = formatDDMMYYYY(todayStr);
      const serviceHookahs = repData.isOfficialComplimentary ? (repData.officialHookahsCount ?? 0) : 0;
      const averageTobacco = repData.totalHookahs > 0
        ? (((todayRevision?.usedTobaccoGrams ?? 0) / repData.totalHookahs).toFixed(1))
        : '0';

      // 2. Compact Layout: only list tobaccos with data for this shift (End > 0, Loaded > 0, or Used > 0)
      const hasShiftData = (item: TobaccoRevisionDetail) => {
        const end = typeof item.endGrams === 'number' ? item.endGrams : 0;
        const loaded = typeof item.loadedGrams === 'number' ? item.loadedGrams : 0;
        const used = typeof item.usedGrams === 'number' ? item.usedGrams : 0;
        return end > 0 || loaded > 0 || used > 0;
      };

      const formatTobaccoLine = (item: TobaccoRevisionDetail) => {
        const name = `${item.brand} ${item.flavor}`.trim();
        const start = typeof item.startGrams === 'number' ? item.startGrams : 0;
        const loaded = typeof item.loadedGrams === 'number' ? item.loadedGrams : 0;
        const end = typeof item.endGrams === 'number' ? item.endGrams : 0;
        const used = typeof item.usedGrams === 'number' ? item.usedGrams : 0;
        return `- ${name}: Нач: ${start}g | Зар: ${loaded}g | Край: ${end}g | Изх: ${used}g`;
      };

      const revisionItems = todayRevision?.items || [];
      const yellowList = revisionItems.filter((i) => i.lineType === 'yellow' && hasShiftData(i)).map(formatTobaccoLine);
      const blackList = revisionItems.filter((i) => i.lineType !== 'yellow' && hasShiftData(i)).map(formatTobaccoLine);

      const yellowSection = yellowList.length > 0 ? yellowList.join('\n') : '- Няма';
      const blackSection = blackList.length > 0 ? blackList.join('\n') : '- Няма';

      // 3. Exact Markdown Structure (100% Emoji-Free and Compact)
      const slackMarkdown = `${venueName} | ${formattedDate}
Служител: ${currentUser.name}
ОТЧЕТ НАРГИЛЕТА:
Общо: ${repData.totalHookahs} (Жълто: ${repData.yellowHookahs}, Черно: ${repData.blackHookahs}, Служебни: ${serviceHookahs})
Средно на чашка: ${averageTobacco} гр.
РЕВИЗИЯ ЖЪЛТО:
${yellowSection}
РЕВИЗИЯ ЧЕРНО:
${blackSection}`;

      // 1. Send to Slack Webhook (with server fallback)
      try {
        await fetch(SLACK_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: slackMarkdown }),
        });
      } catch (slackErr) {
        console.warn('Direct Slack fetch failed, attempting server relay:', slackErr);
        try {
          await fetch('/api/slack-webhook', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              webhookUrl: SLACK_WEBHOOK_URL,
              payload: { text: slackMarkdown },
            }),
          });
        } catch (serverErr) {
          console.error('Server Slack relay error:', serverErr);
        }
      }

      // 2. Mark the shift as officially completed in Firebase/Server
      if (activeShiftForVenue) {
        await onCompleteShift?.(activeShiftForVenue.id);
      }

      setShiftJustCompleted(true);
      onNotify(`🎉 Смяната за ${venueName} е успешно приключена и изпратена в Slack!`);
    } catch (err: any) {
      console.error('Error finalizing shift:', err);
      onNotify('Възникна грешка при приключване на смяната.');
    } finally {
      setIsEndingShift(false);
    }
  };

  // Filtered reports for this venue
  const venueReports = useMemo(() => {
    return reports
      .filter((r) => r.venueId === selectedVenueId)
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [reports, selectedVenueId]);

  // Can final button be clicked?
  const canEndShift = isOnShift && isRevisionDone && isReportDone && !isShiftOfficiallyCompleted && !isEndingShift;

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Shift Lock Warning for Employees */}
      {!isOnShift && (
        <div className="bg-rose-500/10 border-2 border-rose-500/40 rounded-2xl p-4 flex items-center gap-3 text-xs text-rose-300">
          <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />
          <div>
            <strong className="block text-white text-xs font-bold">Нямате активна смяна за този обект днес.</strong>
            <span className="text-[11px] text-rose-300/80">
              По график днес ({todayStr}) нямате разпределена смяна за този обект. Подаването на отчет е заключено.
            </span>
          </div>
        </div>
      )}

      {/* 1. Venue Switcher */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-2xl overflow-x-auto scrollbar-none">
        {activeVenues.map((v) => {
          const isSelected = v.id === selectedVenueId;
          return (
            <button
              key={v.id}
              onClick={() => {
                setSelectedVenueId(v.id);
                setJustSavedReport(false);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                isSelected
                  ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {v.name}
            </button>
          );
        })}
      </div>

      {/* 2. THREE-STEP SEQUENCE PROGRESS INDICATOR */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 sm:p-4 space-y-3 shadow-md">
        <div className="flex items-center justify-between">
          <span className="text-xs font-extrabold text-white flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Последователност за приключване на смяна</span>
          </span>
          <span className="text-[10px] text-slate-400 font-bold">
            {todayStr}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
          {/* STEP 1 Status: Revision */}
          <div className={`p-3 rounded-xl border flex items-center justify-between gap-2.5 transition-all ${
            isRevisionDone
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/20 border-rose-500/40 text-rose-300'
          }`}>
            <div className="flex items-center gap-2 min-w-0">
              {isRevisionDone ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 animate-pulse" />
              )}
              <div className="truncate">
                <strong className="block text-white text-xs truncate">
                  Стъпка 1: Ревизия
                </strong>
                <span className="text-[11px] block truncate">
                  {isRevisionDone && todayRevision
                    ? `Завършена (${todayRevision.usedTobaccoGrams}г)`
                    : 'Не е попълнена'}
                </span>
              </div>
            </div>

            {!isRevisionDone && (
              <button
                type="button"
                onClick={onNavigateToRevision}
                className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-500 hover:bg-rose-400 text-slate-950 font-black text-[11px] rounded-lg shadow-sm shrink-0 cursor-pointer"
              >
                <span>Към Тютюни</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* STEP 2 Status: Report */}
          <div className={`p-3 rounded-xl border flex items-center justify-between gap-2.5 transition-all ${
            isReportDone
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
              : 'bg-slate-950 border-slate-800 text-slate-400'
          }`}>
            <div className="flex items-center gap-2 min-w-0">
              {isReportDone ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <div className="w-5 h-5 rounded-full border border-slate-600 flex items-center justify-center text-[10px] font-bold text-slate-400 shrink-0">
                  2
                </div>
              )}
              <div className="truncate">
                <strong className="block text-white text-xs truncate">
                  Стъпка 2: Дневен отчет
                </strong>
                <span className="text-[11px] block truncate">
                  {isReportDone ? 'Запазен в базата ✓' : 'Очаква запазване'}
                </span>
              </div>
            </div>

            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
              isReportDone ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-slate-800 text-slate-400'
            }`}>
              {isReportDone ? 'Готово' : 'Стъпка 2'}
            </span>
          </div>

          {/* STEP 3 Status: Final Slack & End Shift */}
          <div className={`p-3 rounded-xl border flex items-center justify-between gap-2.5 transition-all ${
            isShiftOfficiallyCompleted
              ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
              : canEndShift
              ? 'bg-amber-950/20 border-amber-500/40 text-amber-300'
              : 'bg-slate-950 border-slate-800 text-slate-500'
          }`}>
            <div className="flex items-center gap-2 min-w-0">
              {isShiftOfficiallyCompleted ? (
                <Award className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <div className="w-5 h-5 rounded-full border border-slate-600 flex items-center justify-center text-[10px] font-bold text-slate-400 shrink-0">
                  3
                </div>
              )}
              <div className="truncate">
                <strong className="block text-white text-xs truncate">
                  Стъпка 3: Приключване
                </strong>
                <span className="text-[11px] block truncate">
                  {isShiftOfficiallyCompleted ? 'Смяната е приключена' : canEndShift ? 'Готово за финализиране' : 'Заключено'}
                </span>
              </div>
            </div>

            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
              isShiftOfficiallyCompleted
                ? 'bg-emerald-500 text-slate-950 font-black'
                : canEndShift
                ? 'bg-amber-500 text-slate-950 font-black animate-pulse'
                : 'bg-slate-800 text-slate-500'
            }`}>
              {isShiftOfficiallyCompleted ? '✓ Край' : canEndShift ? 'Финал' : '3'}
            </span>
          </div>
        </div>

        {!isRevisionDone && (
          <div className="bg-rose-500/10 border border-rose-500/25 rounded-xl p-2.5 text-xs text-rose-300 flex items-center gap-2">
            <Lock className="w-4 h-4 text-rose-400 shrink-0" />
            <span>
              <strong>Внимание:</strong> Завършете първо крайната ревизия на тютюните в таб „Тютюни“ (Стъпка 1)!
            </span>
          </div>
        )}
      </div>

      {/* 3. DAILY REPORT FORM (STEP 2: Запази отчет) */}
      <form onSubmit={handleSaveReport} className="bg-slate-900 border border-slate-800 rounded-3xl p-4 sm:p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-sm sm:text-base font-extrabold text-white">
                Дневен отчет (Стъпка 2 от 3)
              </h3>
              <p className="text-[11px] text-slate-400">
                Въведете направените наргилета и запазете отчета в базата.
              </p>
            </div>
          </div>
          <span className="text-xs text-slate-400">
            Дежурен: <strong className="text-white">{currentUser.name}</strong>
          </span>
        </div>

        {/* Hookah breakdown inputs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
          <div className="bg-slate-950 p-3 rounded-2xl border border-amber-500/40">
            <label className="text-[10px] font-bold text-amber-400 uppercase tracking-wider block mb-1">
              Общо наргилета *
            </label>
            <input
              type="number"
              min="0"
              required
              disabled={!isOnShift}
              value={totalHookahs}
              onChange={(e) => setTotalHookahs(e.target.value)}
              placeholder="0"
              className="w-full bg-slate-900 border border-amber-500 text-white font-black text-base rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-amber-400 disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              🟡 Жълти наргилета
            </label>
            <input
              type="number"
              min="0"
              disabled={!isOnShift}
              value={yellowHookahs}
              onChange={(e) => setYellowHookahs(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-white font-bold text-base rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              ⚫ Черни наргилета
            </label>
            <input
              type="number"
              min="0"
              disabled={!isOnShift}
              value={blackHookahs}
              onChange={(e) => setBlackHookahs(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-white font-bold text-base rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex flex-col justify-between">
            <div className="flex items-center justify-between mb-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Служебни
              </label>
              <input
                type="checkbox"
                disabled={!isOnShift}
                checked={isOfficial}
                onChange={(e) => setIsOfficial(e.target.checked)}
                className="w-4 h-4 accent-amber-500 rounded cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>
            {isOfficial ? (
              <input
                type="number"
                min="1"
                disabled={!isOnShift}
                value={officialCount}
                onChange={(e) => setOfficialCount(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 text-white font-bold text-base rounded-xl px-2.5 py-1.5 focus:outline-none focus:border-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
              />
            ) : (
              <span className="text-xs text-slate-500 py-2">Няма</span>
            )}
          </div>
        </div>

        {/* Photo Upload: ONLY Receipt / Bon Photo (Tax Stamps Photo Completely Removed) */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-300 flex items-center gap-1.5 text-xs">
              <Camera className="w-4 h-4 text-amber-400" />
              <span>Снимка на касов бон / дневен отчет (по избор)</span>
            </span>
            {receiptPhotoUrl && (
              <span className="text-[10px] bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full font-black">
                ✓ Прикачена
              </span>
            )}
          </div>

          <input
            ref={receiptInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={handlePhotoUpload}
          />

          {receiptPhotoUrl ? (
            <div className="relative rounded-xl overflow-hidden border border-slate-700 aspect-video max-h-36 bg-black flex items-center justify-center">
              <img src={receiptPhotoUrl} alt="Касов бон" className="object-contain w-full h-full" />
              <button
                type="button"
                onClick={() => receiptInputRef.current?.click()}
                className="absolute bottom-2 right-2 px-2.5 py-1 bg-black/80 hover:bg-black text-white text-[11px] font-bold rounded-lg border border-slate-600 transition-colors cursor-pointer"
              >
                Смени снимката
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => receiptInputRef.current?.click()}
              disabled={!isOnShift || isUploadingReceipt}
              className="w-full py-3.5 border-2 border-dashed border-slate-700 hover:border-amber-500/80 rounded-xl bg-slate-900/60 flex items-center justify-center gap-2 text-slate-400 hover:text-white transition-all cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isUploadingReceipt ? (
                <Loader2 className="w-5 h-5 animate-spin text-amber-400" />
              ) : (
                <Upload className="w-5 h-5 text-amber-400" />
              )}
              <span className="text-xs font-bold text-slate-300">
                {isUploadingReceipt ? 'Качване...' : 'Натиснете за прикачване на снимка на бона'}
              </span>
            </button>
          )}
        </div>

        {/* Optional Notes */}
        <div>
          <label className="text-[11px] font-bold text-slate-400 block mb-1">
            Бележки / Коментар за смяната (по избор)
          </label>
          <input
            type="text"
            disabled={!isOnShift}
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="напр. Натоварена вечер, гости за рожден ден..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 disabled:opacity-50 disabled:cursor-not-allowed"
          />
        </div>

        {/* Live Earnings Summary Card */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3 flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
              Изчислена надница за тази смяна:
            </span>
            <div className="text-lg font-black text-white mt-0.5">
              {earnedTotal} <span className="text-amber-400 font-bold">€</span>
            </div>
          </div>
          <div className="text-right text-[11px] text-slate-400">
            <span>Базов надник: <strong>{baseRate} €</strong></span><br />
            <span>Бонус наргилета: <strong>{numTotal * hookahRate} €</strong> ({numTotal} × {hookahRate}€)</span>
          </div>
        </div>

        {/* STEP 2: "Запази отчет" BUTTON (Strictly saves report data to Firebase; do NOT fire Slack here) */}
        <button
          type="submit"
          disabled={!isOnShift || isSavingReport || numTotal <= 0}
          className={`w-full py-3.5 rounded-2xl font-black text-xs sm:text-sm shadow-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
            !isOnShift
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
              : isReportDone
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20 active:scale-98'
              : numTotal > 0
              ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 shadow-amber-500/20 active:scale-98'
              : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
          }`}
        >
          {isSavingReport ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
              <span>Запазване на отчета в базата...</span>
            </>
          ) : !isOnShift ? (
            <>
              <Lock className="w-4 h-4 text-rose-400" />
              <span>Нямате активна смяна за този обект днес.</span>
            </>
          ) : isReportDone ? (
            <>
              <Check className="w-4 h-4" />
              <span>✓ Отчетът е запазен в базата (Запази отново)</span>
            </>
          ) : (
            <>
              <FileText className="w-4 h-4" />
              <span>Запази отчет (Стъпка 2)</span>
            </>
          )}
        </button>
      </form>

      {/* 4. STEP 3: FINAL "ПРИКЛЮЧИ СМЯНА" BUTTON (At the very bottom of screen) */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-950 border-2 border-slate-800 rounded-3xl p-4 sm:p-5 shadow-2xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-amber-400 animate-pulse" />
            <h3 className="text-sm sm:text-base font-black text-white uppercase tracking-wider">
              Стъпка 3: Официално приключване на смяна
            </h3>
          </div>
          {isShiftOfficiallyCompleted && (
            <span className="text-xs bg-emerald-500 text-slate-950 px-2.5 py-0.5 rounded-full font-black flex items-center gap-1">
              <Check className="w-3.5 h-3.5" />
              <span>Приключена</span>
            </span>
          )}
        </div>

        <p className="text-xs text-slate-400">
          Този бутон финализира смяната, компилира данните от Ревизията (Стъпка 1) и Отчета (Стъпка 2), и изпраща обобщението към Slack.
        </p>

        {/* Validation requirement messages */}
        {!canEndShift && !isShiftOfficiallyCompleted && (
          <div className="space-y-1.5 text-xs">
            {!isRevisionDone && (
              <div className="flex items-center gap-2 text-rose-400 bg-rose-500/10 border border-rose-500/20 px-3 py-1.5 rounded-xl">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>Стъпка 1 не е готова: Запазете ревизията на тютюните в таб „Тютюни“.</span>
              </div>
            )}
            {!isReportDone && (
              <div className="flex items-center gap-2 text-amber-400 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-xl">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>Стъпка 2 не е готова: Въведете наргилета и натиснете „Запази отчет“ по-горе.</span>
              </div>
            )}
          </div>
        )}

        {isShiftOfficiallyCompleted ? (
          <div className="bg-emerald-950/40 border border-emerald-500/50 rounded-2xl p-4 text-center space-y-1 text-emerald-300">
            <div className="flex items-center justify-center gap-2 font-black text-base text-white">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span>Смяната е официално приключена!</span>
            </div>
            <p className="text-xs text-emerald-300/80">
              Всички данни от ревизията и отчета бяха изпратени към Slack канала.
            </p>
          </div>
        ) : (
          <button
            type="button"
            onClick={handleFinalEndShift}
            disabled={!canEndShift}
            className={`w-full py-4 rounded-2xl font-black text-sm sm:text-base shadow-2xl flex items-center justify-center gap-2.5 transition-all cursor-pointer ${
              canEndShift
                ? 'bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 text-slate-950 shadow-amber-500/30 active:scale-98 border-2 border-amber-300'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700/50'
            }`}
          >
            {isEndingShift ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Изпращане към Slack и приключване на смяна...</span>
              </>
            ) : !isOnShift ? (
              <>
                <Lock className="w-5 h-5 text-rose-400" />
                <span>Нямате активна смяна за този обект днес.</span>
              </>
            ) : !isRevisionDone ? (
              <>
                <Lock className="w-5 h-5" />
                <span>Заключено: Завършете първо Ревизията (Стъпка 1)</span>
              </>
            ) : !isReportDone ? (
              <>
                <Lock className="w-5 h-5" />
                <span>Заключено: Запазете отчета (Стъпка 2)</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                <span>Приключи смяна (Изпрати към Slack)</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* 5. HISTORY OF SUBMITTED REPORTS FOR THIS VENUE */}
      <div className="space-y-3 pt-2">
        <h4 className="text-xs font-extrabold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-400" />
          <span>Предишни отчети за избрания обект ({venueReports.length})</span>
        </h4>

        {venueReports.length === 0 ? (
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 text-center text-xs text-slate-500">
            Няма подадени отчети за този обект.
          </div>
        ) : (
          <div className="space-y-2">
            {venueReports.map((rep) => (
              <div
                key={rep.id}
                className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs shadow-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-black shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-white text-xs">{rep.date}</span>
                      <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.2 rounded-full font-bold">
                        {rep.staffName}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2 flex-wrap">
                      <span>Направени: <strong className="text-amber-300">{rep.totalHookahs} наргилета</strong></span>
                      <span>•</span>
                      <span>Жълти: {rep.yellowHookahs}</span>
                      <span>•</span>
                      <span>Черни: {rep.blackHookahs}</span>
                      <span>•</span>
                      <span className="text-emerald-400 font-bold">{rep.totalEarnedEur} €</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  {rep.photoUrl && (
                    <a
                      href={rep.photoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[11px] font-bold inline-flex items-center gap-1"
                    >
                      <ImageIcon className="w-3 h-3 text-amber-400" />
                      <span>Бон</span>
                    </a>
                  )}
                  {isBossOrAdmin && (
                    <button
                      type="button"
                      onClick={() => {
                        if (confirm('Сигурни ли сте, че искате да изтриете този отчет?')) {
                          onDeleteReport(rep.id);
                        }
                      }}
                      className="p-1 text-slate-500 hover:text-rose-400 rounded-lg cursor-pointer"
                      title="Изтрий отчет"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
