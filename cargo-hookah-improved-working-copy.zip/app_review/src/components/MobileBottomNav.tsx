import React from 'react';
import { ViewTab, UserAccount } from '../types';
import { 
  Package, 
  Boxes, 
  FileText,
  Calendar, 
  AlertOctagon,
  User,
  ClipboardList 
} from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: ViewTab;
  onSelectTab: (tab: ViewTab) => void;
  currentUser: UserAccount;
  finesCount?: number;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onSelectTab,
  currentUser,
  finesCount = 0,
}) => {
  const isBossOrAdmin = currentUser.role === 'boss' || currentUser.role === 'admin';

  const navItems = [
    {
      tab: 'inventory' as ViewTab,
      label: 'Тютюни',
      icon: Package,
    },
    {
      tab: 'equipment' as ViewTab,
      label: 'Инвентар',
      icon: Boxes,
    },
    {
      tab: 'reports' as ViewTab,
      label: 'Отчет',
      icon: FileText,
    },
    {
      tab: 'schedule' as ViewTab,
      label: 'График',
      icon: Calendar,
    },
    {
      tab: 'tasks' as ViewTab,
      label: 'Задачи',
      icon: ClipboardList,
    },
    ...(isBossOrAdmin ? [
      {
        tab: 'fines' as ViewTab,
        label: 'Глоби',
        icon: AlertOctagon,
        badge: finesCount > 0 ? finesCount : undefined,
      },
    ] : []),
    {
      tab: 'my_profile' as ViewTab,
      label: currentUser.role === 'boss' ? 'Шеф' : 'Профил',
      icon: User,
    },
  ];

  return (
    <nav 
      aria-label="Мобилна навигация" 
      className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/90 shadow-2xl px-1 pt-1.5 pb-[max(0.5rem,env(safe-area-inset-bottom))]"
    >
      <div className={`grid ${navItems.length >= 7 ? 'grid-cols-7' : navItems.length === 6 ? 'grid-cols-6' : 'grid-cols-5'} gap-0.5 items-center max-w-lg mx-auto`}>
        {navItems.map((item) => {
          const isActive = activeTab === item.tab;
          const Icon = item.icon;

          return (
            <button
              key={item.tab}
              type="button"
              onClick={() => onSelectTab(item.tab)}
              className={`relative flex flex-col items-center justify-center py-1.5 px-0.5 rounded-xl transition-all select-none min-h-[50px] cursor-pointer ${
                isActive 
                  ? 'text-amber-400 font-extrabold' 
                  : 'text-slate-400 hover:text-slate-200 active:scale-95'
              }`}
            >
              {isActive && (
                <span className="absolute top-0 w-7 h-1 bg-gradient-to-r from-amber-500 to-amber-400 rounded-full shadow-xs shadow-amber-500/50" />
              )}
              
              <div className="relative mt-0.5">
                <Icon className={`w-4 h-4 transition-transform ${isActive ? 'scale-110 text-amber-400' : 'text-slate-400'}`} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="absolute -top-1.5 -right-2 bg-rose-500 text-white text-[8px] font-black w-3.5 h-3.5 rounded-full flex items-center justify-center ring-2 ring-slate-950">
                    {item.badge}
                  </span>
                )}
              </div>

              <span className={`text-[9px] mt-1 tracking-tight truncate max-w-full leading-none ${isActive ? 'font-black text-amber-400' : 'font-medium'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
