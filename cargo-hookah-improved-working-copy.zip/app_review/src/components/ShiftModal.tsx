import React, { useState, useEffect } from 'react';
import { Shift, VenueId, Venue, UserAccount } from '../types';
import { VENUES } from '../data/initialData';
import { Calendar, User, Trash2 } from 'lucide-react';

interface ShiftModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (shiftData: Omit<Shift, 'id' | 'createdAt'>, existingId?: string) => void;
  onDelete?: (shiftId: string) => void;
  initialShift: Shift | null;
  defaultVenueId?: VenueId;
  defaultDate?: string;
  defaultStaffId?: string;
  staffList: UserAccount[];
  createdById: string;
  venues?: Venue[];
}

// Standard shifts per venue (saved automatically behind the scenes):
export function getStandardVenueHours(vId: VenueId): { startTime: string; endTime: string } {
  if (vId === 'de-rouge') {
    return { startTime: '16:00', endTime: '01:00' };
  }
  return { startTime: '16:00', endTime: '00:00' };
}

export const ShiftModal: React.FC<ShiftModalProps> = ({
  isOpen,
  onClose,
  onSave,
  onDelete,
  initialShift,
  defaultVenueId,
  defaultDate,
  defaultStaffId,
  staffList,
  createdById,
  venues = [],
}) => {
  const activeVenues = (venues && venues.length > 0 ? venues : VENUES).filter((v) => v.isActive !== false);
  const [venueId, setVenueId] = useState<VenueId>(() => activeVenues[0]?.id || 'bar-hey');
  const [date, setDate] = useState<string>('');
  const [staffId, setStaffId] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      if (initialShift) {
        setVenueId(initialShift.venueId);
        setDate(initialShift.date);
        setStaffId(initialShift.staffId);
      } else {
        const v = defaultVenueId && activeVenues.some((av) => av.id === defaultVenueId)
          ? defaultVenueId
          : (activeVenues[0]?.id || 'bar-hey');
        setVenueId(v);
        setDate(defaultDate || new Date().toISOString().split('T')[0]);
        setStaffId(defaultStaffId || staffList[0]?.id || '');
      }
    }
  }, [isOpen, initialShift, defaultVenueId, defaultDate, defaultStaffId, staffList, activeVenues]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const assignedStaff = staffList.find((s) => s.id === staffId);
    if (!assignedStaff) return;

    const stdHours = getStandardVenueHours(venueId);

    onSave(
      {
        venueId,
        date,
        staffId,
        staffName: assignedStaff.name,
        shiftType: 'standard',
        startTime: initialShift?.startTime || stdHours.startTime,
        endTime: initialShift?.endTime || stdHours.endTime,
        notes: undefined,
        createdById,
      },
      initialShift?.id
    );

    onClose();
  };

  const handleDelete = () => {
    if (initialShift && onDelete) {
      if (confirm(`Сигурни ли сте, че искате да изтриете смяната на ${initialShift.staffName} на ${initialShift.date}?`)) {
        onDelete(initialShift.id);
        onClose();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 my-auto animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Calendar className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white">
                {initialShift ? 'Редактиране на смяна' : 'Нова смяна в графика'}
              </h3>
            </div>
          </div>
          <button 
            type="button"
            onClick={onClose} 
            className="w-7 h-7 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors text-xs"
          >
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Venue Selection */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Заведение *
            </label>
            <select
              value={venueId}
              onChange={(e) => setVenueId(e.target.value as VenueId)}
              className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-xs font-bold focus:outline-none focus:border-amber-500"
            >
              {activeVenues.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name}
                </option>
              ))}
            </select>
          </div>

          {/* Date */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Дата *
            </label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500 font-bold"
              required
            />
          </div>

          {/* Staff */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Служител (Наргилист) *
            </label>
            <select
              value={staffId}
              onChange={(e) => setStaffId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2.5 text-xs font-bold focus:outline-none focus:border-amber-500"
              required
            >
              {staffList.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.role === 'boss' ? 'Шеф' : 'Служител'})
                </option>
              ))}
            </select>
          </div>

          {/* Action Buttons: Delete + Cancel + Save */}
          <div className="flex items-center justify-between pt-3 border-t border-slate-800 gap-2">
            {initialShift && onDelete ? (
              <button
                type="button"
                onClick={handleDelete}
                className="px-3.5 py-2 bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 hover:text-rose-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
                title="Премахни смяната"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                <span>Премахни</span>
              </button>
            ) : (
              <div />
            )}

            <div className="flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-xl transition-colors"
              >
                Отказ
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow-md shadow-amber-500/20 transition-all active:scale-95"
              >
                Запази смяна
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
